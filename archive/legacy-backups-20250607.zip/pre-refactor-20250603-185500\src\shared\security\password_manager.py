"""
Secure Password Manager
Handles password hashing, validation, and security best practices
"""
import bcrypt
import re
from typing import Optional, Dict, Any

class PasswordManager:
    """Secure password hashing and validation manager"""
    
    def __init__(self):
        self.min_length = 8
        self.max_length = 128
        self.bcrypt_rounds = 12  # Good balance of security and performance
    
    def hash_password(self, password: str) -> str:
        """
        Hash a password using bcrypt with secure salt
        
        Args:
            password: Plain text password to hash
            
        Returns:
            Hashed password string
            
        Raises:
            ValueError: If password doesn't meet security requirements
        """
        # Validate password strength
        validation_result = self.validate_password_strength(password)
        if not validation_result["is_valid"]:
            raise ValueError(f"Password validation failed: {', '.join(validation_result['errors'])}")
        
        # Generate salt and hash password
        salt = bcrypt.gensalt(rounds=self.bcrypt_rounds)
        hashed = bcrypt.hashpw(password.encode('utf-8'), salt)
        return hashed.decode('utf-8')
    
    def verify_password(self, password: str, hashed_password: str) -> bool:
        """
        Verify a password against its hash
        
        Args:
            password: Plain text password to verify
            hashed_password: Stored hashed password
            
        Returns:
            True if password matches, False otherwise
        """
        try:
            return bcrypt.checkpw(
                password.encode('utf-8'), 
                hashed_password.encode('utf-8')
            )
        except Exception:
            return False
    
    def validate_password_strength(self, password: str) -> Dict[str, Any]:
        """
        Validate password meets security requirements
        
        Args:
            password: Password to validate
            
        Returns:
            Dict with validation results and any errors
        """
        errors = []
        
        # Length validation
        if len(password) < self.min_length:
            errors.append(f"Password must be at least {self.min_length} characters")
        if len(password) > self.max_length:
            errors.append(f"Password must be no more than {self.max_length} characters")
        
        # Character requirements
        if not re.search(r'[a-z]', password):
            errors.append("Password must contain at least one lowercase letter")
        if not re.search(r'[A-Z]', password):
            errors.append("Password must contain at least one uppercase letter")
        if not re.search(r'\d', password):
            errors.append("Password must contain at least one number")
        if not re.search(r'[!@#$%^&*(),.?":{}|<>]', password):
            errors.append("Password must contain at least one special character")
        
        # Common password patterns to avoid
        common_patterns = [
            r'(.)\1{2,}',  # Three or more repeated characters
            r'12345',      # Sequential numbers
            r'abcde',      # Sequential letters
            r'password',   # Common words
            r'qwerty',
        ]
        
        for pattern in common_patterns:
            if re.search(pattern, password.lower()):
                errors.append("Password contains common patterns that are not secure")
                break
        
        return {
            "is_valid": len(errors) == 0,
            "errors": errors,
            "strength_score": self._calculate_strength_score(password)
        }
    
    def _calculate_strength_score(self, password: str) -> int:
        """Calculate password strength score (0-100)"""
        score = 0
        
        # Length scoring
        if len(password) >= 8:
            score += 20
        if len(password) >= 12:
            score += 10
        if len(password) >= 16:
            score += 10
        
        # Character variety scoring
        if re.search(r'[a-z]', password):
            score += 10
        if re.search(r'[A-Z]', password):
            score += 10
        if re.search(r'\d', password):
            score += 10
        if re.search(r'[!@#$%^&*(),.?":{}|<>]', password):
            score += 15
        
        # Complexity bonus
        char_types = sum([
            bool(re.search(r'[a-z]', password)),
            bool(re.search(r'[A-Z]', password)),
            bool(re.search(r'\d', password)),
            bool(re.search(r'[!@#$%^&*(),.?":{}|<>]', password))
        ])
        
        if char_types >= 3:
            score += 10
        if char_types == 4:
            score += 5
        
        return min(score, 100)
    
    def generate_secure_password(self, length: int = 16) -> str:
        """
        Generate a secure password
        
        Args:
            length: Desired password length (minimum 12)
            
        Returns:
            Randomly generated secure password
        """
        import secrets
        import string
        
        if length < 12:
            length = 12
        
        # Character sets
        lowercase = string.ascii_lowercase
        uppercase = string.ascii_uppercase
        digits = string.digits
        special = "!@#$%^&*(),.?\":{}|<>"
        
        # Ensure at least one character from each set
        password = [
            secrets.choice(lowercase),
            secrets.choice(uppercase),
            secrets.choice(digits),
            secrets.choice(special)
        ]
        
        # Fill remaining length with random characters
        all_chars = lowercase + uppercase + digits + special
        for _ in range(length - 4):
            password.append(secrets.choice(all_chars))
        
        # Shuffle the password
        secrets.SystemRandom().shuffle(password)
        return ''.join(password)

# Global password manager instance
password_manager = PasswordManager() 