// SaaSpype Frontend Authentication and API Configuration
const API_BASE_URL = 'http://localhost:8000';

// Authentication functions
function checkAuth() {
    const token = localStorage.getItem('token');
    if (!token) {
        window.location.href = 'auth.html';
        return false;
    }
    return true;
}

function logout() {
    localStorage.removeItem('token');
    window.location.href = 'auth.html';
}

// API helper functions
async function apiCall(endpoint, options = {}) {
    const token = localStorage.getItem('token');
    
    const defaultOptions = {
        headers: {
            'Content-Type': 'application/json',
            ...(token && { 'Authorization': `Bearer ${token}` })
        }
    };
    
    const finalOptions = {
        ...defaultOptions,
        ...options,
        headers: {
            ...defaultOptions.headers,
            ...options.headers
        }
    };
    
    const response = await fetch(`${API_BASE_URL}${endpoint}`, finalOptions);
    
    if (response.status === 401) {
        logout();
        return null;
    }
    
    return response;
}

// Authentication API calls
async function login(email, password) {
    try {
        const response = await apiCall('/api/login', {
            method: 'POST',
            body: JSON.stringify({ email, password })
        });
        
        if (response && response.ok) {
            const data = await response.json();
            localStorage.setItem('token', data.access_token);
            return true;
        }
        return false;
    } catch (error) {
        console.error('Login error:', error);
        return false;
    }
}

async function signup(email, password) {
    try {
        const response = await apiCall('/api/signup', {
            method: 'POST',
            body: JSON.stringify({ email, password })
        });
        
        if (response && response.ok) {
            const data = await response.json();
            localStorage.setItem('token', data.access_token);
            return true;
        }
        return false;
    } catch (error) {
        console.error('Signup error:', error);
        return false;
    }
}

// User info
async function getCurrentUser() {
    try {
        const response = await apiCall('/api/me');
        if (response && response.ok) {
            return await response.json();
        }
        return null;
    } catch (error) {
        console.error('Get user error:', error);
        return null;
    }
} 