#!/usr/bin/env python3
"""
Enhanced Reddit Discovery Scraper - Phase 1B
Advanced content quality and business intelligence system
"""

import requests
import json
import time
import re
from datetime import datetime, timedelta
from typing import List, Dict, Optional, Set
import logging
from difflib import SequenceMatcher
import hashlib

# Configure logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

class EnhancedRedditScraper:
    """Advanced Reddit scraper with enhanced content quality and business intelligence"""
    
    def __init__(self):
        self.session = requests.Session()
        self.session.headers.update({
            'User-Agent': 'SaaSpype:discovery-engine:v2.1 (by /u/saaspype_bot)'
        })
        
        # Target subreddits for SaaS discovery
        self.target_subreddits = [
            'startups',
            'Entrepreneur', 
            'SaaS',
            'freelance',
            'smallbusiness'
        ]
        
        # Enhanced spam detection patterns
        self.spam_keywords = [
            'upvote', 'karma', 'follow me', 'subscribe', 'like and share',
            'check out my', 'dm me', 'click here', 'free money', 'get rich',
            'make money fast', 'work from home', 'easy money', 'passive income',
            'crypto', 'bitcoin', 'nft', 'forex', 'trading signals'
        ]
        
        # Advanced promotional content detection
        self.promotional_patterns = [
            r'\b(my|our)\s+(app|website|startup|product|service|platform|tool)\b',
            r'\b(check\s+out|try\s+our|visit\s+our|download\s+our)\b',
            r'\b(we\s+launched|we\s+built|we\s+created|we\s+developed)\b',
            r'\b(link\s+in\s+bio|dm\s+for\s+details|pm\s+me)\b',
            r'\b(affiliate|referral|commission|promo\s+code)\b'
        ]
        
        # NSFW and inappropriate content filters
        self.nsfw_keywords = [
            'nsfw', 'adult', 'porn', 'sex', 'dating', 'hookup', 'escort',
            'gambling', 'casino', 'bet', 'wager', 'drugs', 'illegal'
        ]
        
        # Business context enhancement patterns
        self.industry_patterns = {
            'software': [r'\b(saas|software|app|platform|api|code|dev|tech|ai|ml)\b'],
            'ecommerce': [r'\b(ecommerce|online\s+store|shopify|amazon|selling|retail)\b'],
            'marketing': [r'\b(marketing|advertising|social\s+media|seo|content|brand)\b'],
            'finance': [r'\b(finance|accounting|money|payment|fintech|banking)\b'],
            'healthcare': [r'\b(health|medical|doctor|patient|clinic|hospital)\b'],
            'education': [r'\b(education|learning|course|training|teach|student)\b'],
            'real_estate': [r'\b(real\s+estate|property|rent|lease|housing)\b'],
            'consulting': [r'\b(consulting|consultant|advisory|professional\s+services)\b']
        }
        
        self.business_size_patterns = {
            'solo': [r'\b(solo|freelance|independent|one\s+person|just\s+me)\b'],
            'small': [r'\b(startup|small\s+business|team\s+of|2-10\s+people)\b'],
            'medium': [r'\b(company|business|team|10-50\s+people|growing)\b'],
            'large': [r'\b(enterprise|corporation|large\s+company|100\+\s+people)\b']
        }
        
        # Content deduplication tracking
        self.seen_content_hashes: Set[str] = set()
        self.similarity_threshold = 0.8

    def _calculate_content_hash(self, title: str, body: str) -> str:
        """Calculate hash for content deduplication"""
        content = f"{title.lower().strip()} {body.lower().strip()}"
        # Remove common words and normalize
        normalized = re.sub(r'\b(the|a|an|and|or|but|in|on|at|to|for|of|with|by)\b', '', content)
        normalized = re.sub(r'\s+', ' ', normalized).strip()
        return hashlib.md5(normalized.encode()).hexdigest()

    def _is_similar_content(self, title: str, body: str, existing_posts: List[Dict]) -> bool:
        """Check if content is similar to existing posts using semantic similarity"""
        current_content = f"{title} {body}".lower()
        
        for post in existing_posts:
            existing_content = f"{post.get('title', '')} {post.get('body', '')}".lower()
            similarity = SequenceMatcher(None, current_content, existing_content).ratio()
            if similarity > self.similarity_threshold:
                return True
        return False

    def _advanced_spam_detection(self, post: Dict) -> Dict:
        """Advanced spam detection with scoring"""
        title = post.get('title', '').lower()
        body = post.get('selftext', '').lower()
        combined_text = f"{title} {body}"
        
        spam_score = 0
        spam_indicators = []
        
        # Keyword-based detection
        for keyword in self.spam_keywords:
            if keyword in combined_text:
                spam_score += 2
                spam_indicators.append(f"spam_keyword_{keyword}")
        
        # Pattern-based detection
        for pattern in self.promotional_patterns:
            if re.search(pattern, combined_text, re.IGNORECASE):
                spam_score += 3
                spam_indicators.append(f"promotional_pattern")
        
        # NSFW content detection
        for keyword in self.nsfw_keywords:
            if keyword in combined_text:
                spam_score += 5
                spam_indicators.append(f"nsfw_content_{keyword}")
        
        # Account quality indicators (if available)
        author = post.get('author', '')
        if author in ['[deleted]', 'AutoModerator'] or len(author) < 3:
            spam_score += 2
            spam_indicators.append("suspicious_account")
        
        # Content quality indicators
        if len(body) < 30:
            spam_score += 1
            spam_indicators.append("low_content_length")
        
        # Excessive capitalization
        if len(re.findall(r'[A-Z]{3,}', title + body)) > 2:
            spam_score += 1
            spam_indicators.append("excessive_caps")
        
        # Excessive punctuation
        if len(re.findall(r'[!?]{2,}', title + body)) > 1:
            spam_score += 1
            spam_indicators.append("excessive_punctuation")
        
        return {
            'spam_score': spam_score,
            'spam_indicators': spam_indicators,
            'is_spam': spam_score >= 5,
            'is_low_quality': spam_score >= 3
        }

    def _enhanced_business_context_analysis(self, post: Dict) -> Dict:
        """Enhanced business context extraction with confidence scoring"""
        title = post.get('title', '').lower()
        body = post.get('selftext', '').lower()
        combined_text = f"{title} {body}"
        
        context = {
            'business_size': 'unknown',
            'business_size_confidence': 0.0,
            'industry': 'general',
            'industry_confidence': 0.0,
            'urgency_level': 'low',
            'urgency_confidence': 0.0,
            'market_indicators': [],
            'competitive_mentions': [],
            'revenue_indicators': [],
            'growth_stage': 'unknown'
        }
        
        # Enhanced business size detection
        size_scores = {}
        for size, patterns in self.business_size_patterns.items():
            score = 0
            for pattern in patterns:
                matches = len(re.findall(pattern, combined_text, re.IGNORECASE))
                score += matches
            if score > 0:
                size_scores[size] = score
        
        if size_scores:
            best_size = max(size_scores, key=size_scores.get)
            context['business_size'] = best_size
            context['business_size_confidence'] = min(size_scores[best_size] / 3.0, 1.0)
        
        # Enhanced industry detection
        industry_scores = {}
        for industry, patterns in self.industry_patterns.items():
            score = 0
            for pattern in patterns:
                matches = len(re.findall(pattern, combined_text, re.IGNORECASE))
                score += matches
            if score > 0:
                industry_scores[industry] = score
        
        if industry_scores:
            best_industry = max(industry_scores, key=industry_scores.get)
            context['industry'] = best_industry
            context['industry_confidence'] = min(industry_scores[best_industry] / 2.0, 1.0)
        
        # Enhanced urgency detection
        urgency_patterns = {
            'high': [r'\b(urgent|asap|immediately|critical|emergency|deadline|crisis)\b'],
            'medium': [r'\b(soon|quickly|fast|need\s+help|time\s+sensitive)\b'],
            'low': [r'\b(eventually|someday|future|planning|considering)\b']
        }
        
        urgency_scores = {}
        for level, patterns in urgency_patterns.items():
            score = 0
            for pattern in patterns:
                matches = len(re.findall(pattern, combined_text, re.IGNORECASE))
                score += matches
            if score > 0:
                urgency_scores[level] = score
        
        if urgency_scores:
            best_urgency = max(urgency_scores, key=urgency_scores.get)
            context['urgency_level'] = best_urgency
            context['urgency_confidence'] = min(urgency_scores[best_urgency] / 2.0, 1.0)
        
        # Market indicators
        market_patterns = [
            r'\$[\d,]+', r'\b\d+k\b', r'\b\d+m\b', r'\bmillion\b', r'\bbillion\b',
            r'\bmarket\s+size\b', r'\btam\b', r'\bvaluation\b', r'\bfunding\b'
        ]
        for pattern in market_patterns:
            matches = re.findall(pattern, combined_text, re.IGNORECASE)
            context['market_indicators'].extend(matches)
        
        # Competitive mentions
        competitor_patterns = [
            r'\bcompetitor\b', r'\brival\b', r'\balternative\s+to\b',
            r'\bbetter\s+than\b', r'\bversus\b', r'\bcompared\s+to\b'
        ]
        for pattern in competitor_patterns:
            if re.search(pattern, combined_text, re.IGNORECASE):
                context['competitive_mentions'].append(pattern)
        
        # Revenue indicators
        revenue_patterns = [
            r'\brevenue\b', r'\bprofit\b', r'\bearnings\b', r'\bincome\b',
            r'\bmrr\b', r'\barr\b', r'\bsubscription\b', r'\bpricing\b'
        ]
        for pattern in revenue_patterns:
            if re.search(pattern, combined_text, re.IGNORECASE):
                context['revenue_indicators'].append(pattern)
        
        # Growth stage detection
        if any(word in combined_text for word in ['idea', 'concept', 'thinking about']):
            context['growth_stage'] = 'ideation'
        elif any(word in combined_text for word in ['mvp', 'prototype', 'building', 'developing']):
            context['growth_stage'] = 'development'
        elif any(word in combined_text for word in ['launched', 'live', 'customers', 'users']):
            context['growth_stage'] = 'early_stage'
        elif any(word in combined_text for word in ['scaling', 'growth', 'expanding', 'series']):
            context['growth_stage'] = 'scaling'
        
        return context

    def fetch_subreddit_posts(self, subreddit: str, limit: int = 10) -> List[Dict]:
        """Fetch recent posts from a subreddit using Reddit JSON API with enhanced filtering"""
        try:
            url = f"https://www.reddit.com/r/{subreddit}/hot.json"
            params = {
                'limit': limit * 3,  # Get extra to filter out low-quality posts
                't': 'day'  # Posts from last day
            }
            
            logger.info(f"Fetching posts from r/{subreddit}")
            response = self.session.get(url, params=params, timeout=10)
            response.raise_for_status()
            
            data = response.json()
            posts = []
            
            for post_data in data.get('data', {}).get('children', []):
                post = post_data.get('data', {})
                
                # Skip if missing essential data
                if not post.get('title') or not post.get('selftext'):
                    continue
                    
                # Skip stickied posts
                if post.get('stickied', False):
                    continue
                    
                # Skip deleted or removed posts
                if post.get('selftext') in ['[deleted]', '[removed]', '']:
                    continue
                
                # Enhanced spam detection
                spam_analysis = self._advanced_spam_detection(post)
                if spam_analysis['is_spam']:
                    logger.debug(f"Filtered spam post: {post.get('title', '')[:50]}...")
                    continue
                
                # Content deduplication check
                title = post.get('title', '')
                body = post.get('selftext', '')
                content_hash = self._calculate_content_hash(title, body)
                
                if content_hash in self.seen_content_hashes:
                    logger.debug(f"Filtered duplicate content: {title[:50]}...")
                    continue
                
                if self._is_similar_content(title, body, posts):
                    logger.debug(f"Filtered similar content: {title[:50]}...")
                    continue
                
                # Basic quality filters (enhanced)
                if not self._enhanced_quality_check(post, spam_analysis):
                    continue
                
                # Add content hash to seen set
                self.seen_content_hashes.add(content_hash)
                
                # Extract relevant data with enhanced analysis
                processed_post = {
                    'post_id': post.get('id', ''),
                    'title': title,
                    'body': body,
                    'url': f"https://reddit.com{post.get('permalink', '')}",
                    'score': post.get('score', 0),
                    'num_comments': post.get('num_comments', 0),
                    'subreddit': subreddit,
                    'created_utc': post.get('created_utc', 0),
                    'author': post.get('author', 'unknown'),
                    'spam_analysis': spam_analysis,
                    'content_hash': content_hash
                }
                
                posts.append(processed_post)
                
                # Stop when we have enough quality posts
                if len(posts) >= limit:
                    break
            
            logger.info(f"Extracted {len(posts)} quality posts from r/{subreddit}")
            return posts
            
        except Exception as e:
            logger.error(f"Error fetching from r/{subreddit}: {e}")
            return []

    def _enhanced_quality_check(self, post: Dict, spam_analysis: Dict) -> bool:
        """Enhanced quality filtering for posts"""
        title = post.get('title', '').lower()
        body = post.get('selftext', '').lower()
        combined_text = f"{title} {body}"
        
        # Skip low quality content based on spam analysis
        if spam_analysis['is_low_quality']:
            return False
        
        # Enhanced minimum content length
        if len(body) < 100:  # Increased from 50 to 100 for better quality
            return False
        
        # Enhanced engagement threshold with subreddit context
        min_score = 3 if post.get('subreddit', '').lower() in ['startups', 'entrepreneur'] else 2
        min_comments = 2
        
        if post.get('score', 0) < min_score and post.get('num_comments', 0) < min_comments:
            return False
        
        # Content diversity check - avoid repetitive posts
        word_count = len(combined_text.split())
        unique_words = len(set(combined_text.split()))
        if word_count > 50 and unique_words / word_count < 0.3:  # Too repetitive
            return False
        
        # Business relevance check
        business_keywords = [
            'business', 'startup', 'company', 'product', 'service', 'customer',
            'market', 'revenue', 'profit', 'growth', 'scale', 'problem', 'solution'
        ]
        business_relevance = sum(1 for keyword in business_keywords if keyword in combined_text)
        if business_relevance < 2:  # Must have at least 2 business-related terms
            return False
        
        return True

    def discover_pain_points(self, target_subreddit: Optional[str] = None, limit: int = 5) -> List[Dict]:
        """Enhanced discovery function with advanced filtering and analysis"""
        try:
            all_posts = []
            
            # Use specific subreddit or scan multiple
            subreddits_to_scan = [target_subreddit] if target_subreddit else self.target_subreddits
            
            for subreddit in subreddits_to_scan:
                posts = self.fetch_subreddit_posts(subreddit, limit)
                all_posts.extend(posts)
                
                # Rate limiting - be respectful to Reddit
                time.sleep(1)
            
            # Enhanced sorting with multiple factors
            def calculate_post_score(post):
                base_score = post['score'] + (post['num_comments'] * 2)
                spam_penalty = post['spam_analysis']['spam_score'] * -5
                
                # Bonus for business context confidence
                business_context = self._enhanced_business_context_analysis(post)
                confidence_bonus = (
                    business_context['business_size_confidence'] +
                    business_context['industry_confidence'] +
                    business_context['urgency_confidence']
                ) * 10
                
                return base_score + spam_penalty + confidence_bonus
            
            all_posts.sort(key=calculate_post_score, reverse=True)
            
            # Return top posts up to limit
            selected_posts = all_posts[:limit]
            
            # Add enhanced analysis for compatibility with existing system
            for post in selected_posts:
                post['pain_point_indicators'] = self._extract_pain_indicators(post)
                post['business_context'] = self._enhanced_business_context_analysis(post)
                post['quality_score'] = calculate_post_score(post)
                
                # Add confidence metrics
                post['analysis_confidence'] = {
                    'spam_detection': 1.0 - (post['spam_analysis']['spam_score'] / 20.0),
                    'business_relevance': post['business_context']['business_size_confidence'],
                    'pain_point_clarity': len(post['pain_point_indicators']) / 10.0,
                    'overall': 0.0
                }
                
                # Calculate overall confidence
                confidence_values = list(post['analysis_confidence'].values())[:-1]  # Exclude 'overall'
                post['analysis_confidence']['overall'] = sum(confidence_values) / len(confidence_values)
            
            logger.info(f"Enhanced discovery complete: {len(selected_posts)} high-quality posts with pain point potential")
            return selected_posts
            
        except Exception as e:
            logger.error(f"Enhanced discovery failed: {e}")
            return []

    def _extract_pain_indicators(self, post: Dict) -> List[str]:
        """Extract potential pain point indicators from post content"""
        title = post.get('title', '').lower()
        body = post.get('body', '').lower()
        combined_text = f"{title} {body}"
        
        indicators = []
        
        # Problem language
        problem_words = ['problem', 'issue', 'struggle', 'difficult', 'hard', 'impossible', 'broken', 'terrible', 'hate', 'frustrated']
        for word in problem_words:
            if word in combined_text:
                indicators.append(f"problem_language_{word}")
        
        # Solution seeking
        solution_words = ['need help', 'looking for', 'wish there was', 'how to', 'any suggestions', 'recommendations']
        for phrase in solution_words:
            if phrase in combined_text:
                indicators.append(f"solution_seeking_{phrase.replace(' ', '_')}")
        
        # Workflow friction
        friction_words = ['manual', 'tedious', 'time consuming', 'repetitive', 'inefficient', 'wasting time']
        for phrase in friction_words:
            if phrase in combined_text:
                indicators.append(f"workflow_friction_{phrase.replace(' ', '_')}")
        
        return indicators

def quick_discovery_scan(subreddit: str = 'startups', limit: int = 5) -> Dict:
    """Enhanced function for API integration - comprehensive discovery scan with quality metrics"""
    scraper = EnhancedRedditScraper()
    
    try:
        start_time = time.time()
        posts = scraper.discover_pain_points(subreddit, limit)
        processing_time = time.time() - start_time
        
        # Calculate quality metrics
        quality_metrics = {
            'total_posts_processed': len(scraper.seen_content_hashes),
            'posts_returned': len(posts),
            'spam_filtered': 0,
            'duplicates_filtered': 0,
            'average_confidence': 0.0,
            'industry_distribution': {},
            'business_size_distribution': {},
            'urgency_distribution': {}
        }
        
        if posts:
            # Calculate average confidence
            total_confidence = sum(post.get('analysis_confidence', {}).get('overall', 0) for post in posts)
            quality_metrics['average_confidence'] = total_confidence / len(posts)
            
            # Calculate distributions
            for post in posts:
                business_context = post.get('business_context', {})
                
                # Industry distribution
                industry = business_context.get('industry', 'unknown')
                quality_metrics['industry_distribution'][industry] = quality_metrics['industry_distribution'].get(industry, 0) + 1
                
                # Business size distribution
                size = business_context.get('business_size', 'unknown')
                quality_metrics['business_size_distribution'][size] = quality_metrics['business_size_distribution'].get(size, 0) + 1
                
                # Urgency distribution
                urgency = business_context.get('urgency_level', 'low')
                quality_metrics['urgency_distribution'][urgency] = quality_metrics['urgency_distribution'].get(urgency, 0) + 1
        
        # Enhanced response with performance metrics
        return {
            'success': True,
            'posts_found': len(posts),
            'pain_points': posts,
            'scraper_type': 'enhanced_reddit_scraper_v2.1',
            'timestamp': datetime.now().isoformat(),
            'subreddit_scanned': subreddit,
            'processing_time_seconds': round(processing_time, 2),
            'quality_metrics': quality_metrics,
            'enhancement_features': [
                'advanced_spam_detection',
                'nsfw_content_filtering',
                'semantic_deduplication',
                'enhanced_business_context',
                'confidence_scoring',
                'multi_factor_ranking'
            ],
            'performance_stats': {
                'posts_per_second': round(len(posts) / processing_time, 2) if processing_time > 0 else 0,
                'quality_filter_efficiency': round((quality_metrics['posts_returned'] / max(quality_metrics['total_posts_processed'], 1)) * 100, 1),
                'average_post_quality': round(quality_metrics['average_confidence'] * 100, 1)
            }
        }
        
    except Exception as e:
        logger.error(f"Enhanced discovery scan failed: {e}")
        return {
            'success': False,
            'error': str(e),
            'posts_found': 0,
            'pain_points': [],
            'scraper_type': 'enhanced_reddit_scraper_v2.1',
            'timestamp': datetime.now().isoformat(),
            'subreddit_scanned': subreddit,
            'processing_time_seconds': 0,
            'quality_metrics': {},
            'enhancement_features': [],
            'performance_stats': {}
        }

if __name__ == "__main__":
    # Test the enhanced scraper
    print("🔍 Testing Enhanced Reddit Scraper v2.1...")
    print("🎯 Phase 1B Features: Advanced spam detection, NSFW filtering, semantic deduplication, enhanced business context")
    
    result = quick_discovery_scan('startups', 3)
    
    print(f"\n✅ Discovery Results:")
    print(f"   Posts Found: {result['posts_found']}")
    print(f"   Processing Time: {result.get('processing_time_seconds', 0)}s")
    print(f"   Quality Score: {result.get('performance_stats', {}).get('average_post_quality', 0)}%")
    
    if result['posts_found'] > 0:
        print(f"\n📊 Quality Metrics:")
        metrics = result.get('quality_metrics', {})
        print(f"   Average Confidence: {metrics.get('average_confidence', 0):.2f}")
        print(f"   Industry Distribution: {metrics.get('industry_distribution', {})}")
        print(f"   Business Size Distribution: {metrics.get('business_size_distribution', {})}")
        
        print(f"\n🎯 Top Pain Points:")
        for i, post in enumerate(result['pain_points'][:3], 1):
            confidence = post.get('analysis_confidence', {}).get('overall', 0)
            industry = post.get('business_context', {}).get('industry', 'unknown')
            print(f"   {i}. {post['title'][:60]}... (Confidence: {confidence:.2f}, Industry: {industry})")
    
    print(f"\n🚀 Enhancement Features Active: {len(result.get('enhancement_features', []))}")
    for feature in result.get('enhancement_features', []):
        print(f"   ✅ {feature.replace('_', ' ').title()}") 