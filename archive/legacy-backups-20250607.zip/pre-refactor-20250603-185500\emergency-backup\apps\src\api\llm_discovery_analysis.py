#!/usr/bin/env python3
"""
LLM Intelligence Pipeline - Phase 2
Advanced semantic analysis and business viability scoring for SaaSpype discovery
"""

import json
import time
import logging
from typing import Dict, List, Optional, Tuple
from datetime import datetime
import re

# Configure logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

class LLMDiscoveryAnalyzer:
    """Advanced LLM-powered discovery analysis system"""
    
    def __init__(self):
        self.analysis_cache = {}  # Cache for repeated analyses
        self.prompt_templates = self._initialize_prompt_templates()
        self.scoring_weights = {
            'problem_severity': 0.25,
            'solution_viability': 0.25,
            'market_potential': 0.20,
            'revenue_potential': 0.15,
            'competitive_advantage': 0.15
        }
    
    def _initialize_prompt_templates(self) -> Dict[str, str]:
        """Initialize structured prompt templates for different analysis types"""
        return {
            'opportunity_analysis': """
You are a business opportunity analyst specializing in SaaS and startup opportunities. Analyze the following Reddit post for business potential.

POST TITLE: {title}
POST CONTENT: {content}
SUBREDDIT: r/{subreddit}
ENGAGEMENT: {score} upvotes, {comments} comments

Analyze this post and provide a structured assessment:

1. PROBLEM SEVERITY (0-10): How significant is the pain point described?
   - Consider frequency, impact, and urgency
   - Look for emotional language indicating frustration

2. SOLUTION VIABILITY (0-10): How feasible is it to build a solution?
   - Technical complexity
   - Resource requirements
   - Time to market

3. MARKET POTENTIAL (0-10): How large is the potential market?
   - Target audience size
   - Market trends
   - Growth potential

4. REVENUE POTENTIAL (0-10): How likely is monetization?
   - Willingness to pay indicators
   - Pricing model viability
   - Revenue scalability

5. COMPETITIVE ADVANTAGE (0-10): How defensible is the opportunity?
   - Existing solutions
   - Barriers to entry
   - Unique value proposition

6. BUSINESS CATEGORY: Choose the most relevant category:
   - productivity_tools
   - business_automation
   - communication_platforms
   - data_analytics
   - e_commerce_tools
   - marketing_solutions
   - financial_services
   - developer_tools
   - other

7. TARGET CUSTOMER: Describe the ideal customer profile
8. SOLUTION SUMMARY: Brief description of potential solution (1-2 sentences)
9. KEY INSIGHTS: Important observations about the opportunity

Respond in JSON format:
{{
    "problem_severity": <score>,
    "solution_viability": <score>,
    "market_potential": <score>,
    "revenue_potential": <score>,
    "competitive_advantage": <score>,
    "business_category": "<category>",
    "target_customer": "<description>",
    "solution_summary": "<summary>",
    "key_insights": "<insights>",
    "confidence_indicators": ["<indicator1>", "<indicator2>", ...],
    "risk_factors": ["<risk1>", "<risk2>", ...]
}}
""",
            
            'market_validation': """
You are a market validation expert. Assess the market signals in this Reddit post.

POST: {title} - {content}
CONTEXT: Posted in r/{subreddit} with {score} upvotes and {comments} comments

Evaluate market validation signals:

1. DEMAND INDICATORS: What suggests people want this solution?
2. URGENCY SIGNALS: How urgent is the need?
3. WILLINGNESS TO PAY: Any indicators of payment readiness?
4. MARKET TIMING: Is this the right time for this solution?
5. TREND ALIGNMENT: Does this align with current market trends?

Respond in JSON format with scores 0-10 and explanations.
""",
            
            'competitive_analysis': """
You are a competitive intelligence analyst. Analyze potential competition for this opportunity.

POST: {title} - {content}

Assess competitive landscape:

1. EXISTING SOLUTIONS: What solutions already exist?
2. MARKET GAPS: What gaps remain unaddressed?
3. DIFFERENTIATION OPPORTUNITIES: How could a new solution differentiate?
4. BARRIERS TO ENTRY: What would prevent new competitors?
5. COMPETITIVE INTENSITY: How crowded is this space?

Provide structured analysis with actionable insights.
"""
        }
    
    def analyze_opportunity(self, post_data: Dict) -> Dict:
        """
        Perform comprehensive LLM-powered opportunity analysis
        
        Args:
            post_data: Enhanced post data from discovery scraper
            
        Returns:
            Dict containing LLM analysis results
        """
        try:
            start_time = time.time()
            
            # Extract key information
            title = post_data.get('title', '')
            content = post_data.get('body', '')
            subreddit = post_data.get('subreddit', '')
            score = post_data.get('score', 0)
            comments = post_data.get('num_comments', 0)
            
            # Check cache first
            cache_key = self._generate_cache_key(title, content)
            if cache_key in self.analysis_cache:
                logger.info("Using cached LLM analysis")
                return self.analysis_cache[cache_key]
            
            # Perform LLM analysis (simulated for now - would integrate with actual LLM)
            llm_analysis = self._simulate_llm_analysis(title, content, subreddit, score, comments)
            
            # Calculate composite scores
            viability_score = self._calculate_viability_score(llm_analysis)
            confidence_score = self._calculate_confidence_score(llm_analysis, post_data)
            
            # Enhance with additional intelligence
            enhanced_analysis = {
                **llm_analysis,
                'viability_score': viability_score,
                'confidence_score': confidence_score,
                'processing_time': time.time() - start_time,
                'analysis_timestamp': datetime.now().isoformat(),
                'llm_version': 'simulated_v1.0',
                'enhancement_level': 'phase_2_llm_intelligence'
            }
            
            # Cache the result
            self.analysis_cache[cache_key] = enhanced_analysis
            
            logger.info(f"LLM analysis completed in {enhanced_analysis['processing_time']:.2f}s")
            return enhanced_analysis
            
        except Exception as e:
            logger.error(f"LLM analysis failed: {e}")
            return self._generate_fallback_analysis(post_data)
    
    def _simulate_llm_analysis(self, title: str, content: str, subreddit: str, score: int, comments: int) -> Dict:
        """
        Simulate LLM analysis with intelligent scoring based on content patterns
        In production, this would call actual LLM APIs (Claude, GPT, etc.)
        """
        
        # Analyze content patterns for intelligent scoring
        combined_text = f"{title} {content}".lower()
        
        # Problem severity analysis
        problem_indicators = [
            'problem', 'issue', 'struggle', 'difficult', 'impossible', 'broken',
            'frustrated', 'annoying', 'terrible', 'hate', 'pain', 'nightmare'
        ]
        problem_severity = min(10, sum(2 for indicator in problem_indicators if indicator in combined_text))
        
        # Solution viability analysis
        tech_complexity_indicators = [
            'ai', 'machine learning', 'blockchain', 'complex algorithm',
            'enterprise integration', 'real-time', 'scalable'
        ]
        simple_solution_indicators = [
            'simple', 'basic', 'straightforward', 'easy', 'quick fix',
            'automation', 'dashboard', 'notification'
        ]
        
        complexity_penalty = sum(1 for indicator in tech_complexity_indicators if indicator in combined_text)
        simplicity_bonus = sum(1 for indicator in simple_solution_indicators if indicator in combined_text)
        solution_viability = max(3, min(10, 7 + simplicity_bonus - complexity_penalty))
        
        # Market potential analysis
        market_size_indicators = [
            'everyone', 'all businesses', 'every company', 'widespread',
            'common problem', 'industry standard', 'universal'
        ]
        niche_indicators = [
            'specific', 'niche', 'specialized', 'particular industry',
            'only for', 'just us', 'small group'
        ]
        
        market_bonus = sum(1 for indicator in market_size_indicators if indicator in combined_text)
        niche_penalty = sum(1 for indicator in niche_indicators if indicator in combined_text)
        market_potential = max(4, min(10, 6 + market_bonus - niche_penalty))
        
        # Revenue potential analysis
        payment_indicators = [
            'pay', 'subscription', 'cost', 'price', 'expensive', 'cheap',
            'budget', 'investment', 'roi', 'save money', 'worth it'
        ]
        revenue_potential = min(10, 5 + sum(1 for indicator in payment_indicators if indicator in combined_text))
        
        # Competitive advantage analysis
        unique_indicators = [
            'no solution', 'nothing exists', 'first to market', 'innovative',
            'unique approach', 'different way', 'novel'
        ]
        crowded_indicators = [
            'many solutions', 'lots of options', 'competitive', 'saturated',
            'existing tools', 'already available'
        ]
        
        unique_bonus = sum(2 for indicator in unique_indicators if indicator in combined_text)
        crowded_penalty = sum(1 for indicator in crowded_indicators if indicator in combined_text)
        competitive_advantage = max(3, min(10, 6 + unique_bonus - crowded_penalty))
        
        # Determine business category
        business_category = self._classify_business_category(combined_text)
        
        # Generate insights based on analysis
        key_insights = self._generate_key_insights(
            title, content, problem_severity, solution_viability, market_potential
        )
        
        # Identify confidence indicators
        confidence_indicators = []
        if score > 10: confidence_indicators.append("high_engagement")
        if comments > 5: confidence_indicators.append("active_discussion")
        if problem_severity >= 7: confidence_indicators.append("clear_pain_point")
        if any(word in combined_text for word in ['urgent', 'asap', 'immediately']):
            confidence_indicators.append("urgency_signals")
        
        # Identify risk factors
        risk_factors = []
        if solution_viability < 5: risk_factors.append("high_technical_complexity")
        if market_potential < 5: risk_factors.append("limited_market_size")
        if competitive_advantage < 5: risk_factors.append("high_competition")
        if revenue_potential < 5: risk_factors.append("monetization_challenges")
        
        return {
            'problem_severity': problem_severity,
            'solution_viability': solution_viability,
            'market_potential': market_potential,
            'revenue_potential': revenue_potential,
            'competitive_advantage': competitive_advantage,
            'business_category': business_category,
            'target_customer': self._identify_target_customer(combined_text, subreddit),
            'solution_summary': self._generate_solution_summary(title, content),
            'key_insights': key_insights,
            'confidence_indicators': confidence_indicators,
            'risk_factors': risk_factors,
            'llm_summary': self._generate_llm_summary(title, problem_severity, solution_viability)
        }
    
    def _classify_business_category(self, text: str) -> str:
        """Classify business category based on content analysis"""
        categories = {
            'productivity_tools': ['productivity', 'efficiency', 'workflow', 'task management', 'organization'],
            'business_automation': ['automation', 'automate', 'manual process', 'repetitive', 'workflow'],
            'communication_platforms': ['communication', 'chat', 'messaging', 'collaboration', 'team'],
            'data_analytics': ['data', 'analytics', 'reporting', 'dashboard', 'metrics', 'insights'],
            'e_commerce_tools': ['ecommerce', 'online store', 'selling', 'inventory', 'orders'],
            'marketing_solutions': ['marketing', 'advertising', 'social media', 'seo', 'campaigns'],
            'financial_services': ['finance', 'accounting', 'payment', 'billing', 'invoicing'],
            'developer_tools': ['development', 'coding', 'api', 'integration', 'technical']
        }
        
        for category, keywords in categories.items():
            if any(keyword in text for keyword in keywords):
                return category
        
        return 'other'
    
    def _identify_target_customer(self, text: str, subreddit: str) -> str:
        """Identify target customer profile"""
        if subreddit in ['startups', 'entrepreneur']:
            return "Early-stage entrepreneurs and startup founders"
        elif subreddit == 'smallbusiness':
            return "Small business owners and operators"
        elif subreddit == 'freelance':
            return "Freelancers and independent contractors"
        elif 'enterprise' in text or 'large company' in text:
            return "Enterprise organizations and large corporations"
        elif 'small business' in text or 'startup' in text:
            return "Small to medium businesses and startups"
        else:
            return "General business users and professionals"
    
    def _generate_solution_summary(self, title: str, content: str) -> str:
        """Generate a brief solution summary"""
        if 'automation' in content.lower():
            return "Automated solution to streamline manual processes and improve efficiency."
        elif 'dashboard' in content.lower() or 'reporting' in content.lower():
            return "Analytics dashboard providing insights and reporting capabilities."
        elif 'integration' in content.lower() or 'connect' in content.lower():
            return "Integration platform connecting disparate systems and workflows."
        elif 'communication' in content.lower() or 'collaboration' in content.lower():
            return "Communication tool enhancing team collaboration and coordination."
        else:
            return "Digital solution addressing identified business pain points and inefficiencies."
    
    def _generate_key_insights(self, title: str, content: str, problem_severity: int, 
                             solution_viability: int, market_potential: int) -> str:
        """Generate key insights based on analysis"""
        insights = []
        
        if problem_severity >= 8:
            insights.append("High-severity pain point with strong emotional indicators")
        if solution_viability >= 7:
            insights.append("Technically feasible solution with reasonable complexity")
        if market_potential >= 7:
            insights.append("Large addressable market with growth potential")
        
        if not insights:
            insights.append("Moderate opportunity requiring further validation")
        
        return "; ".join(insights)
    
    def _generate_llm_summary(self, title: str, problem_severity: int, solution_viability: int) -> str:
        """Generate executive summary of the opportunity"""
        if problem_severity >= 7 and solution_viability >= 7:
            return f"High-potential opportunity: '{title[:50]}...' shows strong pain point with viable solution path."
        elif problem_severity >= 6 or solution_viability >= 6:
            return f"Moderate opportunity: '{title[:50]}...' has potential but requires careful validation."
        else:
            return f"Low-priority opportunity: '{title[:50]}...' shows limited immediate potential."
    
    def _calculate_viability_score(self, analysis: Dict) -> float:
        """Calculate composite viability score using weighted factors"""
        weighted_score = (
            analysis['problem_severity'] * self.scoring_weights['problem_severity'] +
            analysis['solution_viability'] * self.scoring_weights['solution_viability'] +
            analysis['market_potential'] * self.scoring_weights['market_potential'] +
            analysis['revenue_potential'] * self.scoring_weights['revenue_potential'] +
            analysis['competitive_advantage'] * self.scoring_weights['competitive_advantage']
        )
        
        return round(weighted_score / 10.0, 2)  # Normalize to 0-1 scale
    
    def _calculate_confidence_score(self, analysis: Dict, post_data: Dict) -> float:
        """Calculate confidence score based on multiple factors"""
        base_confidence = 0.5
        
        # Boost confidence based on analysis quality
        if len(analysis['confidence_indicators']) >= 3:
            base_confidence += 0.2
        elif len(analysis['confidence_indicators']) >= 2:
            base_confidence += 0.1
        
        # Reduce confidence based on risk factors
        if len(analysis['risk_factors']) >= 3:
            base_confidence -= 0.2
        elif len(analysis['risk_factors']) >= 2:
            base_confidence -= 0.1
        
        # Factor in engagement metrics
        score = post_data.get('score', 0)
        comments = post_data.get('num_comments', 0)
        
        if score > 20 or comments > 10:
            base_confidence += 0.15
        elif score > 10 or comments > 5:
            base_confidence += 0.1
        
        # Factor in spam analysis if available
        spam_analysis = post_data.get('spam_analysis', {})
        if spam_analysis.get('spam_score', 0) < 2:
            base_confidence += 0.1
        
        return round(max(0.0, min(1.0, base_confidence)), 2)
    
    def _generate_cache_key(self, title: str, content: str) -> str:
        """Generate cache key for analysis results"""
        import hashlib
        content_hash = hashlib.md5(f"{title}{content}".encode()).hexdigest()
        return f"llm_analysis_{content_hash}"
    
    def _generate_fallback_analysis(self, post_data: Dict) -> Dict:
        """Generate fallback analysis when LLM analysis fails"""
        return {
            'problem_severity': 5,
            'solution_viability': 5,
            'market_potential': 5,
            'revenue_potential': 5,
            'competitive_advantage': 5,
            'business_category': 'other',
            'target_customer': 'General business users',
            'solution_summary': 'Requires further analysis to determine solution approach',
            'key_insights': 'Analysis incomplete - manual review recommended',
            'confidence_indicators': [],
            'risk_factors': ['analysis_incomplete'],
            'llm_summary': 'Fallback analysis - LLM processing unavailable',
            'viability_score': 0.5,
            'confidence_score': 0.3,
            'processing_time': 0.0,
            'analysis_timestamp': datetime.now().isoformat(),
            'llm_version': 'fallback_v1.0',
            'enhancement_level': 'fallback_analysis'
        }

class ConfidenceValidator:
    """Advanced confidence validation system"""
    
    def __init__(self):
        self.validation_criteria = {
            'clarity': 0.25,      # How clear is the problem statement
            'urgency': 0.20,      # How urgent is the need
            'monetizability': 0.25, # How likely to generate revenue
            'trend_potential': 0.15, # Alignment with market trends
            'feasibility': 0.15    # Technical and business feasibility
        }
    
    def validate_opportunity(self, post_data: Dict, llm_analysis: Dict) -> Dict:
        """
        Validate opportunity confidence using multiple criteria
        
        Returns:
            Dict with validation results and final confidence score
        """
        try:
            validation_scores = {}
            
            # Clarity assessment
            validation_scores['clarity'] = self._assess_clarity(post_data, llm_analysis)
            
            # Urgency assessment
            validation_scores['urgency'] = self._assess_urgency(post_data, llm_analysis)
            
            # Monetizability assessment
            validation_scores['monetizability'] = self._assess_monetizability(post_data, llm_analysis)
            
            # Trend potential assessment
            validation_scores['trend_potential'] = self._assess_trend_potential(post_data, llm_analysis)
            
            # Feasibility assessment
            validation_scores['feasibility'] = self._assess_feasibility(post_data, llm_analysis)
            
            # Calculate weighted confidence score
            final_confidence = sum(
                score * self.validation_criteria[criterion]
                for criterion, score in validation_scores.items()
            )
            
            return {
                'validation_scores': validation_scores,
                'final_confidence': round(final_confidence, 3),
                'confidence_level': self._get_confidence_level(final_confidence),
                'validation_summary': self._generate_validation_summary(validation_scores)
            }
            
        except Exception as e:
            logger.error(f"Confidence validation failed: {e}")
            return {
                'validation_scores': {},
                'final_confidence': 0.5,
                'confidence_level': 'medium',
                'validation_summary': 'Validation incomplete'
            }
    
    def _assess_clarity(self, post_data: Dict, llm_analysis: Dict) -> float:
        """Assess how clearly the problem is articulated"""
        title = post_data.get('title', '').lower()
        content = post_data.get('body', '').lower()
        
        clarity_score = 0.5  # Base score
        
        # Check for specific problem statements
        if any(phrase in content for phrase in ['the problem is', 'issue with', 'struggling with']):
            clarity_score += 0.2
        
        # Check for detailed descriptions
        if len(content) > 200:
            clarity_score += 0.1
        
        # Check for examples or specifics
        if any(phrase in content for phrase in ['for example', 'specifically', 'such as']):
            clarity_score += 0.1
        
        # Factor in LLM problem severity score
        problem_severity = llm_analysis.get('problem_severity', 5)
        if problem_severity >= 7:
            clarity_score += 0.1
        
        return min(1.0, clarity_score)
    
    def _assess_urgency(self, post_data: Dict, llm_analysis: Dict) -> float:
        """Assess urgency of the need"""
        content = f"{post_data.get('title', '')} {post_data.get('body', '')}".lower()
        
        urgency_score = 0.3  # Base score
        
        # Check for urgency indicators
        urgency_words = ['urgent', 'asap', 'immediately', 'critical', 'emergency', 'deadline']
        urgency_score += min(0.4, sum(0.1 for word in urgency_words if word in content))
        
        # Check for time-sensitive language
        time_sensitive = ['need now', 'right away', 'can\'t wait', 'time sensitive']
        urgency_score += min(0.2, sum(0.1 for phrase in time_sensitive if phrase in content))
        
        # Factor in engagement (high engagement often indicates urgency)
        score = post_data.get('score', 0)
        if score > 20:
            urgency_score += 0.1
        
        return min(1.0, urgency_score)
    
    def _assess_monetizability(self, post_data: Dict, llm_analysis: Dict) -> float:
        """Assess likelihood of successful monetization"""
        revenue_potential = llm_analysis.get('revenue_potential', 5)
        business_category = llm_analysis.get('business_category', 'other')
        
        # Base score from LLM analysis
        monetization_score = revenue_potential / 10.0
        
        # Boost for high-monetization categories
        high_value_categories = ['business_automation', 'data_analytics', 'financial_services']
        if business_category in high_value_categories:
            monetization_score += 0.1
        
        # Check for payment willingness indicators
        content = f"{post_data.get('title', '')} {post_data.get('body', '')}".lower()
        payment_indicators = ['pay for', 'subscription', 'worth paying', 'budget for', 'invest in']
        if any(indicator in content for indicator in payment_indicators):
            monetization_score += 0.15
        
        return min(1.0, monetization_score)
    
    def _assess_trend_potential(self, post_data: Dict, llm_analysis: Dict) -> float:
        """Assess alignment with current market trends"""
        content = f"{post_data.get('title', '')} {post_data.get('body', '')}".lower()
        
        trend_score = 0.5  # Base score
        
        # Check for trending technologies/concepts
        trending_keywords = [
            'ai', 'automation', 'remote work', 'digital transformation',
            'cloud', 'saas', 'api', 'integration', 'analytics'
        ]
        trend_matches = sum(1 for keyword in trending_keywords if keyword in content)
        trend_score += min(0.3, trend_matches * 0.1)
        
        # Factor in market potential from LLM
        market_potential = llm_analysis.get('market_potential', 5)
        if market_potential >= 7:
            trend_score += 0.2
        
        return min(1.0, trend_score)
    
    def _assess_feasibility(self, post_data: Dict, llm_analysis: Dict) -> float:
        """Assess technical and business feasibility"""
        solution_viability = llm_analysis.get('solution_viability', 5)
        competitive_advantage = llm_analysis.get('competitive_advantage', 5)
        
        # Base feasibility from LLM scores
        feasibility_score = (solution_viability + competitive_advantage) / 20.0
        
        # Check for complexity indicators
        content = f"{post_data.get('title', '')} {post_data.get('body', '')}".lower()
        simple_indicators = ['simple', 'basic', 'straightforward', 'easy']
        complex_indicators = ['complex', 'complicated', 'enterprise', 'advanced']
        
        if any(indicator in content for indicator in simple_indicators):
            feasibility_score += 0.1
        if any(indicator in content for indicator in complex_indicators):
            feasibility_score -= 0.1
        
        return max(0.0, min(1.0, feasibility_score))
    
    def _get_confidence_level(self, confidence_score: float) -> str:
        """Convert confidence score to descriptive level"""
        if confidence_score >= 0.8:
            return 'very_high'
        elif confidence_score >= 0.7:
            return 'high'
        elif confidence_score >= 0.5:
            return 'medium'
        elif confidence_score >= 0.3:
            return 'low'
        else:
            return 'very_low'
    
    def _generate_validation_summary(self, validation_scores: Dict) -> str:
        """Generate human-readable validation summary"""
        strengths = []
        weaknesses = []
        
        for criterion, score in validation_scores.items():
            if score >= 0.7:
                strengths.append(criterion)
            elif score <= 0.4:
                weaknesses.append(criterion)
        
        summary_parts = []
        if strengths:
            summary_parts.append(f"Strong in: {', '.join(strengths)}")
        if weaknesses:
            summary_parts.append(f"Weak in: {', '.join(weaknesses)}")
        
        return "; ".join(summary_parts) if summary_parts else "Balanced opportunity profile"

def enhance_discovery_with_llm(post_data: Dict) -> Dict:
    """
    Main function to enhance discovery data with LLM intelligence
    
    Args:
        post_data: Enhanced post data from Phase 1B discovery scraper
        
    Returns:
        Dict with LLM intelligence enhancements
    """
    try:
        # Initialize analyzers
        llm_analyzer = LLMDiscoveryAnalyzer()
        confidence_validator = ConfidenceValidator()
        
        # Perform LLM analysis
        llm_analysis = llm_analyzer.analyze_opportunity(post_data)
        
        # Validate confidence
        validation_results = confidence_validator.validate_opportunity(post_data, llm_analysis)
        
        # Combine results
        enhanced_data = {
            **post_data,
            'llm_analysis': llm_analysis,
            'confidence_validation': validation_results,
            'phase_2_enhancements': {
                'llm_summary': llm_analysis.get('llm_summary', ''),
                'confidence_score': validation_results.get('final_confidence', 0.5),
                'viability_score': llm_analysis.get('viability_score', 0.5),
                'business_category': llm_analysis.get('business_category', 'other'),
                'target_customer': llm_analysis.get('target_customer', ''),
                'solution_summary': llm_analysis.get('solution_summary', ''),
                'key_insights': llm_analysis.get('key_insights', ''),
                'confidence_level': validation_results.get('confidence_level', 'medium')
            }
        }
        
        logger.info(f"LLM enhancement completed for post: {post_data.get('title', '')[:50]}...")
        return enhanced_data
        
    except Exception as e:
        logger.error(f"LLM enhancement failed: {e}")
        # Return original data with minimal enhancement
        return {
            **post_data,
            'phase_2_enhancements': {
                'llm_summary': 'LLM analysis unavailable',
                'confidence_score': 0.5,
                'viability_score': 0.5,
                'business_category': 'other',
                'target_customer': 'General users',
                'solution_summary': 'Analysis pending',
                'key_insights': 'Manual review required',
                'confidence_level': 'medium'
            }
        }

if __name__ == "__main__":
    # Test the LLM intelligence system
    print("🧠 Testing LLM Intelligence Pipeline...")
    
    # Sample post data for testing
    test_post = {
        'title': 'Struggling with manual invoice processing - takes hours every week',
        'body': 'Our small business processes about 50 invoices per week manually. It takes our accountant 3-4 hours every week just to enter data, check for errors, and file everything. This is getting expensive and error-prone. Looking for a solution that can automate this process. Willing to pay for a good solution that saves us time.',
        'subreddit': 'smallbusiness',
        'score': 15,
        'num_comments': 8,
        'spam_analysis': {'spam_score': 1, 'is_spam': False}
    }
    
    # Test LLM enhancement
    enhanced_result = enhance_discovery_with_llm(test_post)
    
    print(f"\n✅ LLM Analysis Results:")
    phase2 = enhanced_result.get('phase_2_enhancements', {})
    print(f"   LLM Summary: {phase2.get('llm_summary', '')}")
    print(f"   Confidence Score: {phase2.get('confidence_score', 0)}")
    print(f"   Viability Score: {phase2.get('viability_score', 0)}")
    print(f"   Business Category: {phase2.get('business_category', '')}")
    print(f"   Confidence Level: {phase2.get('confidence_level', '')}")
    
    print(f"\n🎯 Key Insights: {phase2.get('key_insights', '')}")
    print(f"💡 Solution Summary: {phase2.get('solution_summary', '')}")
    
    print(f"\n🚀 Phase 2 LLM Intelligence Pipeline: OPERATIONAL") 