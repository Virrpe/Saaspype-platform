#!/usr/bin/env python3
"""
Test script for LLM-Enhanced Discovery API
Verifies Phase 2 LLM Intelligence integration is working correctly
"""

import requests
import json
import time

def test_llm_enhanced_discovery_api():
    """Test the LLM-enhanced discovery API endpoint"""
    print("🧠 Testing LLM-Enhanced Discovery API v2.1")
    print("=" * 60)
    
    # Test endpoint
    url = "http://127.0.0.1:8000/api/discover"
    
    # Test payload
    payload = {
        "subreddit": "startups",
        "limit": 3
    }
    
    # Mock authentication token (you'll need to get a real token)
    headers = {
        "Content-Type": "application/json",
        "Authorization": "Bearer mock_token_for_testing"
    }
    
    try:
        print(f"📡 Sending request to: {url}")
        print(f"📋 Payload: {json.dumps(payload, indent=2)}")
        
        start_time = time.time()
        response = requests.post(url, json=payload, headers=headers, timeout=60)
        response_time = time.time() - start_time
        
        print(f"⏱️  Response time: {response_time:.2f}s")
        print(f"📊 Status code: {response.status_code}")
        
        if response.status_code == 200:
            data = response.json()
            
            print("\n✅ API Response Analysis:")
            print(f"   Success: {data.get('success', False)}")
            print(f"   Posts Analyzed: {data.get('posts_analyzed', 0)}")
            print(f"   Scraper Type: {data.get('scraper_type', 'unknown')}")
            print(f"   Enhancement Level: {data.get('enhancement_level', 'unknown')}")
            
            # Check for LLM analysis stats
            llm_stats = data.get('llm_analysis_stats', {})
            if llm_stats:
                print(f"\n🧠 LLM Analysis Statistics:")
                print(f"   Posts Analyzed: {llm_stats.get('posts_analyzed', 0)}")
                print(f"   Average Confidence: {llm_stats.get('average_confidence', 0):.3f}")
                print(f"   Average Viability: {llm_stats.get('average_viability', 0):.3f}")
                print(f"   Business Categories: {llm_stats.get('business_categories', [])}")
            
            # Check quality metrics
            quality_metrics = data.get('quality_metrics', {})
            if quality_metrics:
                print(f"\n📊 Quality Metrics:")
                print(f"   Average Confidence: {quality_metrics.get('average_confidence', 0):.3f}")
                print(f"   Industry Distribution: {quality_metrics.get('industry_distribution', {})}")
                print(f"   Business Size Distribution: {quality_metrics.get('business_size_distribution', {})}")
            
            # Check performance stats
            performance_stats = data.get('performance_stats', {})
            if performance_stats:
                print(f"\n⚡ Performance Statistics:")
                print(f"   Posts per Second: {performance_stats.get('posts_per_second', 0)}")
                print(f"   Quality Filter Efficiency: {performance_stats.get('quality_filter_efficiency', 0)}%")
                print(f"   Average Post Quality: {performance_stats.get('average_post_quality', 0)}%")
            
            # Check ranked opportunities with LLM enhancements
            opportunities = data.get('ranked_opportunities', [])
            if opportunities:
                print(f"\n🎯 LLM-Enhanced Opportunities ({len(opportunities)}):")
                for i, opp in enumerate(opportunities[:3], 1):
                    print(f"\n   {i}. {opp.get('title', '')[:60]}...")
                    print(f"      Business Category: {opp.get('business_category', 'unknown')}")
                    print(f"      Confidence Score: {opp.get('confidence_score', 0):.3f}")
                    print(f"      Viability Score: {opp.get('viability_score', 0):.3f}")
                    print(f"      Opportunity Score: {opp.get('opportunity_score', 0):.2f}")
                    print(f"      Target Customer: {opp.get('target_customer', '')}")
                    print(f"      LLM Summary: {opp.get('llm_summary', '')[:100]}...")
                    print(f"      Key Insights: {opp.get('key_insights', '')}")
                    
                    # LLM Analysis Details
                    print(f"      Problem Severity: {opp.get('problem_severity', 0)}/10")
                    print(f"      Solution Viability: {opp.get('solution_viability', 0)}/10")
                    print(f"      Market Potential: {opp.get('market_potential', 0)}/10")
                    print(f"      Revenue Potential: {opp.get('revenue_potential', 0)}/10")
                    print(f"      Competitive Advantage: {opp.get('competitive_advantage', 0)}/10")
                    
                    confidence_indicators = opp.get('confidence_indicators', [])
                    risk_factors = opp.get('risk_factors', [])
                    print(f"      Confidence Indicators: {confidence_indicators}")
                    print(f"      Risk Factors: {risk_factors}")
            
            # Check generated concepts
            concepts = data.get('generated_concepts', [])
            if concepts:
                print(f"\n💡 LLM-Generated Concepts ({len(concepts)}):")
                for i, concept in enumerate(concepts[:3], 1):
                    print(f"\n   {i}. {concept.get('concept_title', '')}")
                    print(f"      Description: {concept.get('concept_description', '')}")
                    print(f"      Target Market: {concept.get('target_market', '')}")
                    print(f"      Business Category: {concept.get('business_category', '')}")
                    print(f"      Revenue Model: {concept.get('revenue_model', '')}")
                    print(f"      Confidence: {concept.get('confidence', 0):.3f}")
                    print(f"      Viability: {concept.get('viability', 0):.3f}")
                    print(f"      Key Insights: {concept.get('key_insights', '')}")
            
            # Check pain points with LLM enhancements
            pain_points = data.get('pain_points', [])
            if pain_points:
                print(f"\n🔍 LLM-Enhanced Pain Points ({len(pain_points)}):")
                for i, post in enumerate(pain_points[:2], 1):
                    phase2_data = post.get('phase_2_enhancements', {})
                    print(f"\n   {i}. {post.get('title', '')[:60]}...")
                    print(f"      Subreddit: r/{post.get('subreddit', '')}")
                    print(f"      Engagement: {post.get('score', 0)} upvotes, {post.get('num_comments', 0)} comments")
                    print(f"      LLM Summary: {phase2_data.get('llm_summary', '')}")
                    print(f"      Confidence Level: {phase2_data.get('confidence_level', '')}")
                    print(f"      Business Category: {phase2_data.get('business_category', '')}")
                    print(f"      Solution Summary: {phase2_data.get('solution_summary', '')}")
            
            print(f"\n✅ LLM-Enhanced Discovery API Test: PASSED")
            return True
            
        elif response.status_code == 401:
            print(f"❌ Authentication Error: {response.status_code}")
            print("💡 This is expected - you need to authenticate first")
            print("   1. Register/login to get a valid token")
            print("   2. Update the test script with the real token")
            return False
            
        else:
            print(f"❌ API Error: {response.status_code}")
            print(f"Response: {response.text}")
            return False
            
    except requests.exceptions.ConnectionError:
        print("❌ Connection Error: API server not running on port 8000")
        print("💡 Make sure to start the API server first:")
        print("   cd apps/src/api && python -m uvicorn main:app --host 127.0.0.1 --port 8000 --reload")
        return False
        
    except Exception as e:
        print(f"❌ Test failed: {e}")
        return False

def test_llm_module_standalone():
    """Test the LLM module standalone"""
    print("\n🧠 Testing LLM Intelligence Module Standalone...")
    print("=" * 50)
    
    try:
        from llm_discovery_analysis import enhance_discovery_with_llm
        
        # Sample post data for testing
        test_post = {
            'title': 'Need help with automated customer support - spending too much time on repetitive questions',
            'body': 'Our startup gets about 100 customer support emails per day, and 80% of them are the same 10 questions. Our team spends 4-5 hours daily just answering these repetitive questions. We need an automated solution that can handle common questions but still escalate complex issues to humans. Willing to pay $200-500/month for a good solution.',
            'subreddit': 'startups',
            'score': 25,
            'num_comments': 12,
            'spam_analysis': {'spam_score': 0, 'is_spam': False}
        }
        
        # Test LLM enhancement
        enhanced_result = enhance_discovery_with_llm(test_post)
        
        print(f"✅ LLM Module Test Results:")
        phase2 = enhanced_result.get('phase_2_enhancements', {})
        llm_analysis = enhanced_result.get('llm_analysis', {})
        
        print(f"   LLM Summary: {phase2.get('llm_summary', '')}")
        print(f"   Confidence Score: {phase2.get('confidence_score', 0):.3f}")
        print(f"   Viability Score: {phase2.get('viability_score', 0):.3f}")
        print(f"   Business Category: {phase2.get('business_category', '')}")
        print(f"   Target Customer: {phase2.get('target_customer', '')}")
        print(f"   Confidence Level: {phase2.get('confidence_level', '')}")
        
        print(f"\n📊 Detailed LLM Analysis:")
        print(f"   Problem Severity: {llm_analysis.get('problem_severity', 0)}/10")
        print(f"   Solution Viability: {llm_analysis.get('solution_viability', 0)}/10")
        print(f"   Market Potential: {llm_analysis.get('market_potential', 0)}/10")
        print(f"   Revenue Potential: {llm_analysis.get('revenue_potential', 0)}/10")
        print(f"   Competitive Advantage: {llm_analysis.get('competitive_advantage', 0)}/10")
        
        print(f"\n🎯 Key Insights: {phase2.get('key_insights', '')}")
        print(f"💡 Solution Summary: {phase2.get('solution_summary', '')}")
        
        confidence_validation = enhanced_result.get('confidence_validation', {})
        print(f"\n🔍 Confidence Validation:")
        print(f"   Final Confidence: {confidence_validation.get('final_confidence', 0):.3f}")
        print(f"   Validation Summary: {confidence_validation.get('validation_summary', '')}")
        
        print(f"\n🚀 LLM Intelligence Module: OPERATIONAL")
        return True
        
    except Exception as e:
        print(f"❌ LLM Module test failed: {e}")
        return False

if __name__ == "__main__":
    print("🧠 LLM Intelligence Pipeline Testing Suite")
    print("=" * 60)
    
    # Test standalone LLM module first
    llm_success = test_llm_module_standalone()
    
    # Test API integration
    api_success = test_llm_enhanced_discovery_api()
    
    print(f"\n📋 Test Results Summary:")
    print(f"   LLM Module: {'✅ PASSED' if llm_success else '❌ FAILED'}")
    print(f"   API Integration: {'✅ PASSED' if api_success else '⚠️ NEEDS AUTH'}")
    
    if llm_success:
        print(f"\n🎉 Phase 2 LLM Intelligence Implementation: SUCCESSFUL")
        print(f"🔧 Advanced semantic analysis and business viability scoring operational")
        print(f"🚀 Ready for Phase 3: Live Trend & Signal Detection")
    else:
        print(f"\n⚠️  Phase 2 LLM Intelligence Implementation: NEEDS ATTENTION")
        print(f"🔧 Check LLM module configuration and dependencies") 