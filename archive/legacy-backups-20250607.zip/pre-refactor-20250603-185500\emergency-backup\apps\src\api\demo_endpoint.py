#!/usr/bin/env python3
"""
Demo API Endpoint - SaaSpype Boomerang Flow Trigger
===================================================

This file modification should trigger the following agent flow:
1. backend-specialist (auto-triggered by file pattern)
2. reflexion-agent (handoff for quality review)
3. product-strategist (handoff for strategic analysis)
4. orchestrator (coordination and completion)

This demonstrates the live boomerang logic system in action.
"""

from fastapi import FastAPI, HTTPException
from pydantic import BaseModel
from typing import Dict, Any
import json
import os
from datetime import datetime, timezone

app = FastAPI(title="SaaSpype Demo API", version="1.0.0")

class BoomerangTrigger(BaseModel):
    """Model for triggering boomerang flow demonstration"""
    action: str
    agent_target: str = "backend-specialist"
    test_mode: bool = True

@app.get("/")
async def root():
    """Root endpoint - should trigger backend-specialist via file pattern"""
    return {
        "message": "SaaSpype Demo API - Boomerang Flow Active",
        "timestamp": datetime.now(timezone.utc).isoformat(),
        "agents_triggered": ["backend-specialist"],
        "expected_flow": [
            "backend-specialist",
            "reflexion-agent", 
            "product-strategist",
            "orchestrator"
        ]
    }

@app.post("/trigger-boomerang")
async def trigger_boomerang_flow(trigger: BoomerangTrigger):
    """
    Endpoint to manually trigger boomerang flow for testing
    
    This endpoint modification should trigger:
    1. backend-specialist (file pattern match)
    2. Automatic handoff chain via boomerang logic
    """
    
    # Log the trigger event
    event = {
        "timestamp": datetime.now(timezone.utc).isoformat(),
        "event_type": "MANUAL_BOOMERANG_TRIGGER",
        "trigger_data": trigger.dict(),
        "expected_agents": ["backend-specialist", "reflexion-agent", "product-strategist", "orchestrator"]
    }
    
    # This file modification should trigger the agent flow
    return {
        "status": "boomerang_triggered",
        "trigger_event": event,
        "message": "File modification detected - agent flow should activate",
        "monitoring": "Check memory/agent-log.jsonl for flow events"
    }

@app.get("/agent-status")
async def get_agent_status():
    """Check current agent coordination status"""
    try:
        # Read current coordination state
        if os.path.exists("working-memory/agent-coordination.json"):
            with open("working-memory/agent-coordination.json", 'r') as f:
                coordination = json.load(f)
        else:
            coordination = {"status": "no_coordination_file"}
            
        # Read recent agent events
        recent_events = []
        if os.path.exists("memory/agent-log.jsonl"):
            with open("memory/agent-log.jsonl", 'r') as f:
                lines = f.readlines()
                # Get last 5 events
                for line in lines[-5:]:
                    try:
                        recent_events.append(json.loads(line.strip()))
                    except:
                        continue
                        
        return {
            "coordination_status": coordination,
            "recent_events": recent_events,
            "timestamp": datetime.now(timezone.utc).isoformat()
        }
        
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Error reading agent status: {e}")

# This comment modification should trigger backend-specialist
# Expected flow: backend-specialist → reflexion-agent → product-strategist → orchestrator
# Boomerang logic: If any agent fails, reflexion-agent should detect and reactivate
# Orchestrator rerouting: If handoff fails, orchestrator should reroute to backup agent 