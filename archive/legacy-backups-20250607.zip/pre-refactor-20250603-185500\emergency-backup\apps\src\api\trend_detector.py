#!/usr/bin/env python3
"""
Live Trend & Signal Detection Engine - Phase 3
Real-time monitoring, trend detection, and predictive analytics for SaaSpype discovery
"""

import json
import time
import logging
from typing import Dict, List, Optional, Tuple, Set
from datetime import datetime, timedelta
from collections import defaultdict, Counter
import sqlite3
import os
from pathlib import Path
import hashlib
import re

# Configure logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

class TrendDetectionEngine:
    """Advanced trend detection and signal analysis system"""
    
    def __init__(self, database_path: str = None):
        self.database_path = database_path or os.path.join(os.path.dirname(__file__), "..", "..", "..", "saaspype_discovery.db")
        self.trend_memory = {}  # In-memory trend tracking
        self.signal_cache = {}  # Signal strength cache
        self.keyword_trends = defaultdict(list)  # Keyword frequency over time
        self.business_category_trends = defaultdict(list)  # Category trends
        self.subreddit_activity = defaultdict(list)  # Subreddit activity patterns
        
        # Trend detection parameters
        self.trend_window_hours = 24  # Look back window for trend analysis
        self.signal_decay_factor = 0.8  # Signal strength decay over time
        self.anomaly_threshold = 2.0  # Standard deviations for anomaly detection
        self.min_data_points = 5  # Minimum data points for trend calculation
        
        # Initialize trend tracking database
        self._init_trend_database()
    
    def _init_trend_database(self):
        """Initialize trend tracking tables"""
        try:
            conn = sqlite3.connect(self.database_path)
            cursor = conn.cursor()
            
            # Trend tracking table
            cursor.execute("""
                CREATE TABLE IF NOT EXISTS trend_tracking (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    timestamp TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                    subreddit TEXT NOT NULL,
                    keyword TEXT NOT NULL,
                    business_category TEXT,
                    frequency INTEGER DEFAULT 1,
                    signal_strength REAL DEFAULT 0.0,
                    trend_velocity REAL DEFAULT 0.0,
                    confidence_score REAL DEFAULT 0.0,
                    post_id TEXT,
                    session_data TEXT
                )
            """)
            
            # Signal alerts table
            cursor.execute("""
                CREATE TABLE IF NOT EXISTS signal_alerts (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    alert_timestamp TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                    alert_type TEXT NOT NULL,
                    signal_strength REAL NOT NULL,
                    trend_data TEXT NOT NULL,
                    opportunity_summary TEXT,
                    action_required TEXT,
                    status TEXT DEFAULT 'active'
                )
            """)
            
            # Trend summaries table
            cursor.execute("""
                CREATE TABLE IF NOT EXISTS trend_summaries (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    summary_date DATE DEFAULT CURRENT_DATE,
                    trending_keywords TEXT,
                    trending_categories TEXT,
                    top_signals TEXT,
                    market_insights TEXT,
                    prediction_data TEXT
                )
            """)
            
            conn.commit()
            conn.close()
            logger.info("Trend detection database initialized successfully")
            
        except Exception as e:
            logger.error(f"Failed to initialize trend database: {e}")
    
    def analyze_discovery_trends(self, discovery_sessions: List[Dict]) -> Dict:
        """
        Analyze trends from recent discovery sessions
        
        Args:
            discovery_sessions: List of discovery session data
            
        Returns:
            Dict containing trend analysis results
        """
        try:
            start_time = time.time()
            
            # Extract trend data from sessions
            trend_data = self._extract_trend_data(discovery_sessions)
            
            # Detect keyword trends
            keyword_trends = self._detect_keyword_trends(trend_data)
            
            # Analyze business category trends
            category_trends = self._analyze_category_trends(trend_data)
            
            # Calculate signal strengths
            signal_analysis = self._calculate_signal_strengths(trend_data)
            
            # Detect anomalies and emerging trends
            anomaly_detection = self._detect_trend_anomalies(trend_data)
            
            # Generate predictive insights
            predictions = self._generate_trend_predictions(trend_data)
            
            # Compile comprehensive trend report
            trend_report = {
                'analysis_timestamp': datetime.now().isoformat(),
                'analysis_duration': time.time() - start_time,
                'data_points_analyzed': len(discovery_sessions),
                'trend_window_hours': self.trend_window_hours,
                
                # Core trend analysis
                'keyword_trends': keyword_trends,
                'category_trends': category_trends,
                'signal_analysis': signal_analysis,
                'anomaly_detection': anomaly_detection,
                'predictions': predictions,
                
                # Summary metrics
                'trending_keywords': self._get_top_trending_keywords(keyword_trends),
                'emerging_categories': self._get_emerging_categories(category_trends),
                'high_signal_opportunities': self._get_high_signal_opportunities(signal_analysis),
                'market_insights': self._generate_market_insights(trend_data),
                
                # Performance metrics
                'trend_detection_stats': {
                    'keywords_tracked': len(keyword_trends),
                    'categories_analyzed': len(category_trends),
                    'signals_detected': len(signal_analysis),
                    'anomalies_found': len(anomaly_detection.get('anomalies', [])),
                    'predictions_generated': len(predictions)
                }
            }
            
            # Store trend analysis
            self._store_trend_analysis(trend_report)
            
            logger.info(f"Trend analysis completed in {trend_report['analysis_duration']:.2f}s")
            return trend_report
            
        except Exception as e:
            logger.error(f"Trend analysis failed: {e}")
            return self._generate_fallback_trend_report()
    
    def _extract_trend_data(self, discovery_sessions: List[Dict]) -> Dict:
        """Extract trend-relevant data from discovery sessions"""
        trend_data = {
            'keywords': defaultdict(list),
            'categories': defaultdict(list),
            'subreddits': defaultdict(list),
            'timestamps': [],
            'confidence_scores': [],
            'viability_scores': [],
            'posts': []
        }
        
        for session in discovery_sessions:
            session_data = session.get('session_data', {})
            if isinstance(session_data, str):
                try:
                    session_data = json.loads(session_data)
                except:
                    continue
            
            timestamp = session.get('created_at', datetime.now().isoformat())
            trend_data['timestamps'].append(timestamp)
            
            # Extract pain points and opportunities
            pain_points = session_data.get('pain_points', [])
            opportunities = session_data.get('ranked_opportunities', [])
            
            for post in pain_points + opportunities:
                # Extract keywords from title and content
                title = post.get('title', '')
                content = post.get('description', '') or post.get('body', '')
                keywords = self._extract_keywords(f"{title} {content}")
                
                # Track keyword frequency over time
                for keyword in keywords:
                    trend_data['keywords'][keyword].append({
                        'timestamp': timestamp,
                        'frequency': 1,
                        'subreddit': post.get('subreddit', ''),
                        'confidence': post.get('confidence_score', 0.5)
                    })
                
                # Track business categories
                category = post.get('business_category', 'other')
                trend_data['categories'][category].append({
                    'timestamp': timestamp,
                    'confidence': post.get('confidence_score', 0.5),
                    'viability': post.get('viability_score', 0.5)
                })
                
                # Track subreddit activity
                subreddit = post.get('subreddit', '')
                if subreddit:
                    trend_data['subreddits'][subreddit].append({
                        'timestamp': timestamp,
                        'engagement': post.get('engagement_score', 0),
                        'quality': post.get('opportunity_score', 0)
                    })
                
                # Store post data
                trend_data['posts'].append(post)
                
                # Track confidence and viability scores
                if 'confidence_score' in post:
                    trend_data['confidence_scores'].append(post['confidence_score'])
                if 'viability_score' in post:
                    trend_data['viability_scores'].append(post['viability_score'])
        
        return trend_data
    
    def _extract_keywords(self, text: str) -> List[str]:
        """Extract relevant keywords from text"""
        # Business and tech keywords
        business_keywords = [
            'automation', 'saas', 'platform', 'dashboard', 'analytics', 'integration',
            'workflow', 'productivity', 'efficiency', 'management', 'tracking',
            'reporting', 'notification', 'alert', 'monitoring', 'optimization',
            'scaling', 'growth', 'revenue', 'customer', 'user', 'client',
            'api', 'cloud', 'mobile', 'web', 'app', 'software', 'tool',
            'solution', 'service', 'system', 'process', 'business', 'startup',
            'enterprise', 'small business', 'freelance', 'remote work',
            'collaboration', 'communication', 'project management', 'crm',
            'marketing', 'sales', 'finance', 'accounting', 'hr', 'support'
        ]
        
        text_lower = text.lower()
        found_keywords = []
        
        for keyword in business_keywords:
            if keyword in text_lower:
                found_keywords.append(keyword)
        
        # Extract additional keywords using regex
        # Look for problem indicators
        problem_patterns = [
            r'\b(problem|issue|struggle|difficult|challenge|pain|frustrat\w+)\b',
            r'\b(need|want|require|looking for|searching for)\b',
            r'\b(manual|repetitive|time.consuming|inefficient)\b'
        ]
        
        for pattern in problem_patterns:
            matches = re.findall(pattern, text_lower)
            found_keywords.extend(matches)
        
        return list(set(found_keywords))  # Remove duplicates
    
    def _detect_keyword_trends(self, trend_data: Dict) -> Dict:
        """Detect trending keywords and their velocity"""
        keyword_trends = {}
        
        for keyword, occurrences in trend_data['keywords'].items():
            if len(occurrences) < self.min_data_points:
                continue
            
            # Calculate frequency over time
            time_buckets = defaultdict(int)
            confidence_scores = []
            
            for occurrence in occurrences:
                # Bucket by hour
                timestamp = datetime.fromisoformat(occurrence['timestamp'].replace('Z', '+00:00'))
                hour_bucket = timestamp.replace(minute=0, second=0, microsecond=0)
                time_buckets[hour_bucket] += 1
                confidence_scores.append(occurrence['confidence'])
            
            # Calculate trend velocity (change in frequency over time)
            frequencies = list(time_buckets.values())
            if len(frequencies) >= 2:
                recent_freq = sum(frequencies[-3:]) / min(3, len(frequencies))  # Last 3 time periods
                earlier_freq = sum(frequencies[:-3]) / max(1, len(frequencies) - 3)  # Earlier periods
                velocity = (recent_freq - earlier_freq) / max(earlier_freq, 1)
            else:
                velocity = 0.0
            
            keyword_trends[keyword] = {
                'total_occurrences': len(occurrences),
                'trend_velocity': velocity,
                'average_confidence': sum(confidence_scores) / len(confidence_scores),
                'time_buckets': len(time_buckets),
                'recent_frequency': frequencies[-1] if frequencies else 0,
                'trend_direction': 'rising' if velocity > 0.2 else 'falling' if velocity < -0.2 else 'stable'
            }
        
        return keyword_trends
    
    def _analyze_category_trends(self, trend_data: Dict) -> Dict:
        """Analyze business category trends"""
        category_trends = {}
        
        for category, occurrences in trend_data['categories'].items():
            if len(occurrences) < self.min_data_points:
                continue
            
            # Calculate metrics
            confidence_scores = [occ['confidence'] for occ in occurrences]
            viability_scores = [occ['viability'] for occ in occurrences]
            
            # Time-based analysis
            timestamps = [datetime.fromisoformat(occ['timestamp'].replace('Z', '+00:00')) for occ in occurrences]
            recent_count = sum(1 for ts in timestamps if ts > datetime.now() - timedelta(hours=12))
            total_count = len(occurrences)
            
            category_trends[category] = {
                'total_opportunities': total_count,
                'recent_opportunities': recent_count,
                'growth_rate': recent_count / max(total_count - recent_count, 1),
                'average_confidence': sum(confidence_scores) / len(confidence_scores),
                'average_viability': sum(viability_scores) / len(viability_scores),
                'trend_strength': recent_count / max(total_count, 1),
                'category_health': 'hot' if recent_count > total_count * 0.4 else 'warm' if recent_count > total_count * 0.2 else 'cool'
            }
        
        return category_trends
    
    def _calculate_signal_strengths(self, trend_data: Dict) -> Dict:
        """Calculate signal strength for opportunities"""
        signal_analysis = {}
        
        for post in trend_data['posts']:
            post_id = post.get('post_id', '') or post.get('id', '') or str(hash(post.get('title', '')))
            
            # Base signal from LLM analysis
            confidence = post.get('confidence_score', 0.5)
            viability = post.get('viability_score', 0.5)
            engagement = post.get('engagement_score', 0) / 100.0  # Normalize
            
            # Trend boost factors
            category = post.get('business_category', 'other')
            category_trend = trend_data['categories'].get(category, [])
            category_boost = len(category_trend) / 10.0  # More occurrences = higher boost
            
            # Keyword trend boost
            title = post.get('title', '')
            keywords = self._extract_keywords(title)
            keyword_boost = 0.0
            for keyword in keywords:
                keyword_occurrences = len(trend_data['keywords'].get(keyword, []))
                keyword_boost += keyword_occurrences / 20.0
            
            # Time decay factor
            timestamp = post.get('analysis_timestamp', '') or datetime.now().isoformat()
            try:
                post_time = datetime.fromisoformat(timestamp.replace('Z', '+00:00'))
                hours_old = (datetime.now() - post_time.replace(tzinfo=None)).total_seconds() / 3600
                time_decay = self.signal_decay_factor ** (hours_old / 24)  # Decay over days
            except:
                time_decay = 1.0
            
            # Calculate composite signal strength
            base_signal = (confidence * 0.4 + viability * 0.4 + engagement * 0.2)
            trend_boost = min(category_boost + keyword_boost, 1.0)  # Cap boost at 1.0
            
            signal_strength = (base_signal + trend_boost) * time_decay
            signal_strength = min(signal_strength, 2.0)  # Cap at 2.0
            
            signal_analysis[post_id] = {
                'signal_strength': signal_strength,
                'base_signal': base_signal,
                'trend_boost': trend_boost,
                'time_decay': time_decay,
                'confidence': confidence,
                'viability': viability,
                'engagement': engagement,
                'category': category,
                'keywords': keywords,
                'title': title[:100],
                'signal_level': 'high' if signal_strength > 1.2 else 'medium' if signal_strength > 0.8 else 'low'
            }
        
        return signal_analysis
    
    def _detect_trend_anomalies(self, trend_data: Dict) -> Dict:
        """Detect anomalies and emerging trends"""
        anomalies = []
        
        # Keyword frequency anomalies
        for keyword, occurrences in trend_data['keywords'].items():
            if len(occurrences) < self.min_data_points:
                continue
            
            # Calculate recent vs historical frequency
            timestamps = [datetime.fromisoformat(occ['timestamp'].replace('Z', '+00:00')) for occ in occurrences]
            recent_count = sum(1 for ts in timestamps if ts > datetime.now() - timedelta(hours=6))
            historical_avg = len(occurrences) / max(self.trend_window_hours / 6, 1)  # Average per 6-hour period
            
            if recent_count > historical_avg * self.anomaly_threshold:
                anomalies.append({
                    'type': 'keyword_surge',
                    'keyword': keyword,
                    'recent_count': recent_count,
                    'historical_average': historical_avg,
                    'anomaly_factor': recent_count / max(historical_avg, 1),
                    'significance': 'high' if recent_count > historical_avg * 3 else 'medium'
                })
        
        # Category emergence anomalies
        for category, occurrences in trend_data['categories'].items():
            if len(occurrences) < 3:  # Lower threshold for categories
                continue
            
            timestamps = [datetime.fromisoformat(occ['timestamp'].replace('Z', '+00:00')) for occ in occurrences]
            recent_count = sum(1 for ts in timestamps if ts > datetime.now() - timedelta(hours=12))
            
            if recent_count >= len(occurrences) * 0.6:  # 60% of activity in last 12 hours
                anomalies.append({
                    'type': 'category_emergence',
                    'category': category,
                    'recent_activity': recent_count,
                    'total_activity': len(occurrences),
                    'emergence_rate': recent_count / len(occurrences),
                    'significance': 'high' if recent_count >= len(occurrences) * 0.8 else 'medium'
                })
        
        return {
            'anomalies': anomalies,
            'anomaly_count': len(anomalies),
            'detection_threshold': self.anomaly_threshold,
            'analysis_window': f"{self.trend_window_hours} hours"
        }
    
    def _generate_trend_predictions(self, trend_data: Dict) -> Dict:
        """Generate predictive insights based on trend analysis"""
        predictions = {}
        
        # Predict trending keywords for next 24 hours
        keyword_predictions = []
        for keyword, occurrences in trend_data['keywords'].items():
            if len(occurrences) >= self.min_data_points:
                # Simple linear trend prediction
                timestamps = [datetime.fromisoformat(occ['timestamp'].replace('Z', '+00:00')) for occ in occurrences]
                recent_trend = sum(1 for ts in timestamps if ts > datetime.now() - timedelta(hours=12))
                earlier_trend = len(occurrences) - recent_trend
                
                if recent_trend > earlier_trend:
                    growth_rate = (recent_trend - earlier_trend) / max(earlier_trend, 1)
                    predicted_frequency = recent_trend * (1 + growth_rate)
                    
                    keyword_predictions.append({
                        'keyword': keyword,
                        'predicted_frequency': predicted_frequency,
                        'growth_rate': growth_rate,
                        'confidence': min(growth_rate, 1.0)
                    })
        
        # Sort by predicted frequency
        keyword_predictions.sort(key=lambda x: x['predicted_frequency'], reverse=True)
        
        # Predict emerging business categories
        category_predictions = []
        for category, occurrences in trend_data['categories'].items():
            if len(occurrences) >= 3:
                avg_confidence = sum(occ['confidence'] for occ in occurrences) / len(occurrences)
                avg_viability = sum(occ['viability'] for occ in occurrences) / len(occurrences)
                
                # Calculate emergence potential
                emergence_score = (avg_confidence + avg_viability) / 2 * len(occurrences) / 10
                
                category_predictions.append({
                    'category': category,
                    'emergence_score': emergence_score,
                    'opportunity_count': len(occurrences),
                    'average_confidence': avg_confidence,
                    'average_viability': avg_viability
                })
        
        category_predictions.sort(key=lambda x: x['emergence_score'], reverse=True)
        
        predictions = {
            'trending_keywords_24h': keyword_predictions[:10],
            'emerging_categories': category_predictions[:5],
            'market_timing_insights': self._generate_timing_insights(trend_data),
            'opportunity_hotspots': self._identify_opportunity_hotspots(trend_data),
            'prediction_confidence': 'medium',  # Based on data quality
            'next_update_recommended': (datetime.now() + timedelta(hours=6)).isoformat()
        }
        
        return predictions
    
    def _generate_timing_insights(self, trend_data: Dict) -> List[Dict]:
        """Generate market timing insights"""
        insights = []
        
        # Analyze posting patterns
        timestamps = [datetime.fromisoformat(ts.replace('Z', '+00:00')) for ts in trend_data['timestamps']]
        if timestamps:
            # Peak activity hours
            hours = [ts.hour for ts in timestamps]
            hour_counts = Counter(hours)
            peak_hour = hour_counts.most_common(1)[0][0] if hour_counts else 12
            
            insights.append({
                'type': 'peak_activity',
                'insight': f"Peak discovery activity occurs around {peak_hour}:00",
                'data': {'peak_hour': peak_hour, 'activity_distribution': dict(hour_counts)}
            })
        
        # Category timing patterns
        for category, occurrences in trend_data['categories'].items():
            if len(occurrences) >= 5:
                timestamps = [datetime.fromisoformat(occ['timestamp'].replace('Z', '+00:00')) for occ in occurrences]
                recent_activity = sum(1 for ts in timestamps if ts > datetime.now() - timedelta(hours=24))
                
                if recent_activity >= len(occurrences) * 0.5:
                    insights.append({
                        'type': 'category_timing',
                        'insight': f"{category} category showing high recent activity",
                        'data': {'category': category, 'recent_ratio': recent_activity / len(occurrences)}
                    })
        
        return insights
    
    def _identify_opportunity_hotspots(self, trend_data: Dict) -> List[Dict]:
        """Identify opportunity hotspots by subreddit and category"""
        hotspots = []
        
        # Subreddit hotspots
        subreddit_activity = defaultdict(list)
        for post in trend_data['posts']:
            subreddit = post.get('subreddit', '')
            if subreddit:
                confidence = post.get('confidence_score', 0.5)
                viability = post.get('viability_score', 0.5)
                subreddit_activity[subreddit].append((confidence + viability) / 2)
        
        for subreddit, scores in subreddit_activity.items():
            if len(scores) >= 3:
                avg_quality = sum(scores) / len(scores)
                hotspots.append({
                    'type': 'subreddit_hotspot',
                    'location': subreddit,
                    'opportunity_count': len(scores),
                    'average_quality': avg_quality,
                    'hotspot_score': avg_quality * len(scores)
                })
        
        # Category hotspots
        for category, occurrences in trend_data['categories'].items():
            if len(occurrences) >= 5:
                avg_confidence = sum(occ['confidence'] for occ in occurrences) / len(occurrences)
                avg_viability = sum(occ['viability'] for occ in occurrences) / len(occurrences)
                
                hotspots.append({
                    'type': 'category_hotspot',
                    'location': category,
                    'opportunity_count': len(occurrences),
                    'average_confidence': avg_confidence,
                    'average_viability': avg_viability,
                    'hotspot_score': (avg_confidence + avg_viability) / 2 * len(occurrences)
                })
        
        # Sort by hotspot score
        hotspots.sort(key=lambda x: x['hotspot_score'], reverse=True)
        return hotspots[:10]
    
    def _get_top_trending_keywords(self, keyword_trends: Dict) -> List[Dict]:
        """Get top trending keywords"""
        trending = []
        for keyword, data in keyword_trends.items():
            if data['trend_velocity'] > 0.1:  # Positive trend
                trending.append({
                    'keyword': keyword,
                    'velocity': data['trend_velocity'],
                    'occurrences': data['total_occurrences'],
                    'direction': data['trend_direction']
                })
        
        trending.sort(key=lambda x: x['velocity'], reverse=True)
        return trending[:10]
    
    def _get_emerging_categories(self, category_trends: Dict) -> List[Dict]:
        """Get emerging business categories"""
        emerging = []
        for category, data in category_trends.items():
            if data['category_health'] in ['hot', 'warm']:
                emerging.append({
                    'category': category,
                    'health': data['category_health'],
                    'opportunities': data['total_opportunities'],
                    'growth_rate': data['growth_rate'],
                    'confidence': data['average_confidence']
                })
        
        emerging.sort(key=lambda x: x['growth_rate'], reverse=True)
        return emerging[:5]
    
    def _get_high_signal_opportunities(self, signal_analysis: Dict) -> List[Dict]:
        """Get high signal strength opportunities"""
        high_signals = []
        for post_id, data in signal_analysis.items():
            if data['signal_level'] == 'high':
                high_signals.append({
                    'post_id': post_id,
                    'signal_strength': data['signal_strength'],
                    'title': data['title'],
                    'category': data['category'],
                    'confidence': data['confidence'],
                    'viability': data['viability']
                })
        
        high_signals.sort(key=lambda x: x['signal_strength'], reverse=True)
        return high_signals[:10]
    
    def _generate_market_insights(self, trend_data: Dict) -> List[str]:
        """Generate market insights from trend data"""
        insights = []
        
        # Overall market activity
        total_opportunities = len(trend_data['posts'])
        if total_opportunities > 0:
            avg_confidence = sum(trend_data['confidence_scores']) / len(trend_data['confidence_scores']) if trend_data['confidence_scores'] else 0.5
            insights.append(f"Market shows {total_opportunities} opportunities with {avg_confidence:.1%} average confidence")
        
        # Category diversity
        categories = len(trend_data['categories'])
        if categories > 5:
            insights.append(f"High market diversity with {categories} business categories active")
        elif categories < 3:
            insights.append(f"Market concentration in {categories} primary categories")
        
        # Keyword activity
        keywords = len(trend_data['keywords'])
        if keywords > 20:
            insights.append(f"High keyword activity suggests diverse problem landscape ({keywords} keywords)")
        
        return insights
    
    def _store_trend_analysis(self, trend_report: Dict):
        """Store trend analysis in database"""
        try:
            conn = sqlite3.connect(self.database_path)
            cursor = conn.cursor()
            
            # Store trend summary
            cursor.execute("""
                INSERT INTO trend_summaries (
                    trending_keywords, trending_categories, top_signals, 
                    market_insights, prediction_data
                ) VALUES (?, ?, ?, ?, ?)
            """, (
                json.dumps(trend_report.get('trending_keywords', [])),
                json.dumps(trend_report.get('emerging_categories', [])),
                json.dumps(trend_report.get('high_signal_opportunities', [])),
                json.dumps(trend_report.get('market_insights', [])),
                json.dumps(trend_report.get('predictions', {}))
            ))
            
            conn.commit()
            conn.close()
            
        except Exception as e:
            logger.error(f"Failed to store trend analysis: {e}")
    
    def _generate_fallback_trend_report(self) -> Dict:
        """Generate fallback trend report when analysis fails"""
        return {
            'analysis_timestamp': datetime.now().isoformat(),
            'analysis_duration': 0.0,
            'data_points_analyzed': 0,
            'trend_window_hours': self.trend_window_hours,
            'keyword_trends': {},
            'category_trends': {},
            'signal_analysis': {},
            'anomaly_detection': {'anomalies': [], 'anomaly_count': 0},
            'predictions': {},
            'trending_keywords': [],
            'emerging_categories': [],
            'high_signal_opportunities': [],
            'market_insights': ['Trend analysis unavailable - insufficient data'],
            'trend_detection_stats': {
                'keywords_tracked': 0,
                'categories_analyzed': 0,
                'signals_detected': 0,
                'anomalies_found': 0,
                'predictions_generated': 0
            },
            'status': 'fallback_analysis'
        }

class RealTimeMonitor:
    """Real-time monitoring system for continuous trend detection"""
    
    def __init__(self, trend_engine: TrendDetectionEngine):
        self.trend_engine = trend_engine
        self.monitoring_active = False
        self.alert_thresholds = {
            'high_signal': 1.5,
            'trend_velocity': 0.5,
            'anomaly_factor': 2.0
        }
    
    def start_monitoring(self, interval_minutes: int = 30):
        """Start real-time monitoring (placeholder for background service)"""
        logger.info(f"Real-time monitoring configured for {interval_minutes}-minute intervals")
        self.monitoring_active = True
        
        # In production, this would start a background service
        # For now, we'll just log the configuration
        return {
            'status': 'configured',
            'interval_minutes': interval_minutes,
            'alert_thresholds': self.alert_thresholds,
            'monitoring_active': self.monitoring_active
        }
    
    def check_for_alerts(self, trend_report: Dict) -> List[Dict]:
        """Check trend report for alert conditions"""
        alerts = []
        
        # High signal alerts
        high_signals = trend_report.get('high_signal_opportunities', [])
        for signal in high_signals:
            if signal['signal_strength'] > self.alert_thresholds['high_signal']:
                alerts.append({
                    'type': 'high_signal_opportunity',
                    'severity': 'high',
                    'message': f"High signal opportunity detected: {signal['title']}",
                    'data': signal
                })
        
        # Trend velocity alerts
        trending_keywords = trend_report.get('trending_keywords', [])
        for keyword_data in trending_keywords:
            if keyword_data['velocity'] > self.alert_thresholds['trend_velocity']:
                alerts.append({
                    'type': 'trending_keyword',
                    'severity': 'medium',
                    'message': f"Keyword trending rapidly: {keyword_data['keyword']}",
                    'data': keyword_data
                })
        
        # Anomaly alerts
        anomalies = trend_report.get('anomaly_detection', {}).get('anomalies', [])
        for anomaly in anomalies:
            if anomaly.get('anomaly_factor', 0) > self.alert_thresholds['anomaly_factor']:
                alerts.append({
                    'type': 'trend_anomaly',
                    'severity': 'high' if anomaly.get('significance') == 'high' else 'medium',
                    'message': f"Trend anomaly detected: {anomaly.get('keyword', anomaly.get('category', 'Unknown'))}",
                    'data': anomaly
                })
        
        return alerts

def run_trend_analysis(limit_sessions: int = 50) -> Dict:
    """
    Main function to run trend analysis on recent discovery sessions
    
    Args:
        limit_sessions: Number of recent sessions to analyze
        
    Returns:
        Dict containing comprehensive trend analysis
    """
    try:
        # Initialize trend detection engine
        trend_engine = TrendDetectionEngine()
        
        # Load recent discovery sessions from database
        conn = sqlite3.connect(trend_engine.database_path)
        cursor = conn.cursor()
        
        cursor.execute("""
            SELECT id, subreddit, posts_analyzed, pain_points_found, session_data, created_at
            FROM discovery_sessions 
            ORDER BY created_at DESC 
            LIMIT ?
        """, (limit_sessions,))
        
        sessions = []
        for row in cursor.fetchall():
            sessions.append({
                'id': row[0],
                'subreddit': row[1],
                'posts_analyzed': row[2],
                'pain_points_found': row[3],
                'session_data': row[4],
                'created_at': row[5]
            })
        
        conn.close()
        
        if not sessions:
            logger.warning("No discovery sessions found for trend analysis")
            return trend_engine._generate_fallback_trend_report()
        
        # Run trend analysis
        trend_report = trend_engine.analyze_discovery_trends(sessions)
        
        # Initialize real-time monitor
        monitor = RealTimeMonitor(trend_engine)
        monitoring_status = monitor.start_monitoring()
        
        # Check for alerts
        alerts = monitor.check_for_alerts(trend_report)
        
        # Add monitoring data to report
        trend_report['monitoring_status'] = monitoring_status
        trend_report['alerts'] = alerts
        trend_report['alert_count'] = len(alerts)
        
        logger.info(f"Trend analysis completed: {len(sessions)} sessions analyzed, {len(alerts)} alerts generated")
        return trend_report
        
    except Exception as e:
        logger.error(f"Trend analysis failed: {e}")
        return TrendDetectionEngine()._generate_fallback_trend_report()

if __name__ == "__main__":
    # Test the trend detection system
    print("🔍 Testing Live Trend & Signal Detection Engine...")
    
    # Run trend analysis
    trend_report = run_trend_analysis(limit_sessions=10)
    
    print(f"\n✅ Trend Analysis Results:")
    print(f"   Data Points Analyzed: {trend_report.get('data_points_analyzed', 0)}")
    print(f"   Keywords Tracked: {trend_report.get('trend_detection_stats', {}).get('keywords_tracked', 0)}")
    print(f"   Categories Analyzed: {trend_report.get('trend_detection_stats', {}).get('categories_analyzed', 0)}")
    print(f"   Signals Detected: {trend_report.get('trend_detection_stats', {}).get('signals_detected', 0)}")
    print(f"   Anomalies Found: {trend_report.get('trend_detection_stats', {}).get('anomalies_found', 0)}")
    print(f"   Alerts Generated: {trend_report.get('alert_count', 0)}")
    
    trending_keywords = trend_report.get('trending_keywords', [])
    if trending_keywords:
        print(f"\n🔥 Top Trending Keywords:")
        for i, keyword in enumerate(trending_keywords[:5], 1):
            print(f"   {i}. {keyword['keyword']} (velocity: {keyword['velocity']:.2f})")
    
    emerging_categories = trend_report.get('emerging_categories', [])
    if emerging_categories:
        print(f"\n📈 Emerging Categories:")
        for i, category in enumerate(emerging_categories[:3], 1):
            print(f"   {i}. {category['category']} ({category['health']}, {category['opportunities']} opportunities)")
    
    market_insights = trend_report.get('market_insights', [])
    if market_insights:
        print(f"\n💡 Market Insights:")
        for insight in market_insights[:3]:
            print(f"   • {insight}")
    
    print(f"\n🚀 Phase 3 Trend Detection Engine: OPERATIONAL") 