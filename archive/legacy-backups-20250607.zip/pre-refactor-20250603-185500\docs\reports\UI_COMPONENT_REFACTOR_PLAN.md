# SaaSpype V2 UI Component Refactor Plan

## Executive Summary & Design Philosophy

### Current State Analysis
SaaSpype currently uses **custom HTML + Tailwind CSS** across four main interfaces:
- **Landing Page** (`/index.html`) - Marketing site with hero, features, pricing
- **Product Dashboard** (`/dashboard.html`) - User analytics and insights
- **Admin Panel** (`/admin.html`) - Administrative interface
- **Monitoring Dashboard** (port 5003) - Real-time system monitoring

### Design Philosophy for V2
**SaaSpype V2** will embody **"Intelligent Simplicity"** - sophisticated functionality delivered through clean, intuitive interfaces that scale from startup to enterprise.

**Core Visual Principles:**
1. **Data-Driven Clarity** - Every element serves user decision-making
2. **Progressive Disclosure** - Complex features revealed contextually
3. **Consistent Interaction Language** - Unified patterns across all interfaces
4. **Performance-First Design** - Optimized for speed and accessibility
5. **Adaptive Intelligence** - UI adapts to user behavior and data patterns

---

## 🎨 Design Token System

### Color Palette
```css
/* Primary Brand Colors */
--primary-50: #f0f4ff;
--primary-100: #e0e9ff;
--primary-500: #667eea;  /* Main brand */
--primary-600: #5a67d8;
--primary-700: #4c51bf;
--primary-900: #2d3748;

/* Semantic Colors */
--success-50: #f0fff4;
--success-500: #48bb78;
--success-600: #38a169;

--warning-50: #fffbeb;
--warning-500: #ed8936;
--warning-600: #dd6b20;

--error-50: #fed7d7;
--error-500: #f56565;
--error-600: #e53e3e;

/* Neutral Palette */
--gray-50: #f9fafb;
--gray-100: #f3f4f6;
--gray-200: #e5e7eb;
--gray-300: #d1d5db;
--gray-600: #4b5563;
--gray-700: #374151;
--gray-900: #111827;
```

### Typography Scale
```css
--text-xs: 0.75rem;    /* 12px */
--text-sm: 0.875rem;   /* 14px */
--text-base: 1rem;     /* 16px */
--text-lg: 1.125rem;   /* 18px */
--text-xl: 1.25rem;    /* 20px */
--text-2xl: 1.5rem;    /* 24px */
--text-3xl: 1.875rem;  /* 30px */
--text-4xl: 2.25rem;   /* 36px */
--text-5xl: 3rem;      /* 48px */
--text-6xl: 3.75rem;   /* 60px */

--font-weight-normal: 400;
--font-weight-medium: 500;
--font-weight-semibold: 600;
--font-weight-bold: 700;
```

### Spacing & Layout
```css
--space-1: 0.25rem;   /* 4px */
--space-2: 0.5rem;    /* 8px */
--space-3: 0.75rem;   /* 12px */
--space-4: 1rem;      /* 16px */
--space-6: 1.5rem;    /* 24px */
--space-8: 2rem;      /* 32px */
--space-12: 3rem;     /* 48px */
--space-16: 4rem;     /* 64px */
--space-20: 5rem;     /* 80px */

--radius-sm: 0.375rem;  /* 6px */
--radius-md: 0.5rem;    /* 8px */
--radius-lg: 0.75rem;   /* 12px */
--radius-xl: 1rem;      /* 16px */
--radius-2xl: 1.5rem;   /* 24px */
```

### Shadows & Effects
```css
--shadow-sm: 0 1px 2px 0 rgba(0, 0, 0, 0.05);
--shadow-md: 0 4px 6px -1px rgba(0, 0, 0, 0.1);
--shadow-lg: 0 10px 15px -3px rgba(0, 0, 0, 0.1);
--shadow-xl: 0 20px 25px -5px rgba(0, 0, 0, 0.1);

--gradient-primary: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
--gradient-success: linear-gradient(135deg, #48bb78 0%, #38a169 100%);
--glass-effect: backdrop-filter: blur(10px); background: rgba(255, 255, 255, 0.1);
```

---

## 📁 Component Architecture

### Folder Structure
```
src/components/
├── foundation/           # Core design system components
│   ├── Button/
│   ├── Input/
│   ├── Typography/
│   └── Layout/
├── navigation/          # Navigation components
│   ├── Navbar/
│   ├── Sidebar/
│   ├── Breadcrumb/
│   └── TabNavigation/
├── data-display/        # Data visualization components
│   ├── MetricCard/
│   ├── Chart/
│   ├── Table/
│   └── ProgressBar/
├── feedback/           # User feedback components
│   ├── Alert/
│   ├── Toast/
│   ├── Modal/
│   └── LoadingSpinner/
├── forms/              # Form components
│   ├── FormField/
│   ├── Select/
│   ├── Checkbox/
│   └── RadioGroup/
├── marketing/          # Landing page components
│   ├── Hero/
│   ├── FeatureCard/
│   ├── TestimonialCard/
│   └── PricingCard/
├── dashboard/          # Dashboard-specific components
│   ├── DashboardLayout/
│   ├── InsightCard/
│   ├── RevenueChart/
│   └── CustomerTable/
└── admin/              # Admin panel components
    ├── AdminLayout/
    ├── UserManagement/
    ├── SystemStatus/
    └── ConfigPanel/
```

---

## 🧩 Foundation Components

### Button Component
```typescript
interface ButtonProps {
  variant: 'primary' | 'secondary' | 'outline' | 'ghost' | 'danger';
  size: 'sm' | 'md' | 'lg' | 'xl';
  loading?: boolean;
  disabled?: boolean;
  icon?: React.ReactNode;
  iconPosition?: 'left' | 'right';
  fullWidth?: boolean;
  onClick?: () => void;
  children: React.ReactNode;
}
```

**Tailwind Classes:**
```css
/* Base */
.btn-base: "inline-flex items-center justify-center font-medium transition-all duration-200 focus:outline-none focus:ring-2 focus:ring-offset-2 disabled:opacity-50 disabled:cursor-not-allowed"

/* Variants */
.btn-primary: "bg-primary-600 text-white hover:bg-primary-700 focus:ring-primary-500"
.btn-secondary: "bg-gray-100 text-gray-900 hover:bg-gray-200 focus:ring-gray-500"
.btn-outline: "border border-primary-600 text-primary-600 hover:bg-primary-50 focus:ring-primary-500"
.btn-ghost: "text-primary-600 hover:bg-primary-50 focus:ring-primary-500"
.btn-danger: "bg-error-600 text-white hover:bg-error-700 focus:ring-error-500"

/* Sizes */
.btn-sm: "px-3 py-1.5 text-sm rounded-md"
.btn-md: "px-4 py-2 text-base rounded-lg"
.btn-lg: "px-6 py-3 text-lg rounded-lg"
.btn-xl: "px-8 py-4 text-xl rounded-xl"
```

### Input Component
```typescript
interface InputProps {
  type: 'text' | 'email' | 'password' | 'number' | 'tel' | 'url';
  label?: string;
  placeholder?: string;
  error?: string;
  helperText?: string;
  required?: boolean;
  disabled?: boolean;
  icon?: React.ReactNode;
  iconPosition?: 'left' | 'right';
  size: 'sm' | 'md' | 'lg';
}
```

### Typography Component
```typescript
interface TypographyProps {
  variant: 'h1' | 'h2' | 'h3' | 'h4' | 'h5' | 'h6' | 'body1' | 'body2' | 'caption' | 'overline';
  color?: 'primary' | 'secondary' | 'success' | 'warning' | 'error' | 'inherit';
  align?: 'left' | 'center' | 'right' | 'justify';
  weight?: 'normal' | 'medium' | 'semibold' | 'bold';
  children: React.ReactNode;
}
```

---

## 🧭 Navigation Components

### Navbar Component
```typescript
interface NavbarProps {
  variant: 'marketing' | 'app' | 'admin';
  transparent?: boolean;
  sticky?: boolean;
  logo?: React.ReactNode;
  navigation?: NavigationItem[];
  actions?: React.ReactNode;
  user?: UserInfo;
}

interface NavigationItem {
  label: string;
  href: string;
  icon?: React.ReactNode;
  active?: boolean;
  badge?: string | number;
}
```

**Features:**
- Glass morphism effect for marketing variant
- Responsive mobile menu with slide-out animation
- Active state indicators
- User dropdown with avatar
- Notification badges

### Sidebar Component
```typescript
interface SidebarProps {
  variant: 'dashboard' | 'admin' | 'monitoring';
  collapsible?: boolean;
  collapsed?: boolean;
  navigation: SidebarSection[];
  footer?: React.ReactNode;
  onCollapse?: (collapsed: boolean) => void;
}

interface SidebarSection {
  title?: string;
  items: SidebarItem[];
}

interface SidebarItem {
  label: string;
  href: string;
  icon: React.ReactNode;
  active?: boolean;
  badge?: string | number;
  children?: SidebarItem[];
}
```

**Features:**
- Collapsible with icon-only mode
- Nested navigation support
- Upgrade prompts for freemium users
- Keyboard navigation support

---

## 📊 Data Display Components

### MetricCard Component
```typescript
interface MetricCardProps {
  title: string;
  value: string | number;
  change?: {
    value: number;
    period: string;
    trend: 'up' | 'down' | 'neutral';
  };
  icon?: React.ReactNode;
  color?: 'primary' | 'success' | 'warning' | 'error' | 'neutral';
  size?: 'sm' | 'md' | 'lg';
  loading?: boolean;
  onClick?: () => void;
}
```

**Features:**
- Animated value counting
- Trend indicators with arrows
- Hover animations
- Loading skeleton states
- Color-coded themes

### Chart Component
```typescript
interface ChartProps {
  type: 'line' | 'bar' | 'area' | 'pie' | 'donut';
  data: ChartData;
  options?: ChartOptions;
  height?: number;
  loading?: boolean;
  error?: string;
  timeRange?: TimeRangeSelector;
}
```

**Features:**
- Chart.js integration
- Responsive design
- Dark mode support
- Export functionality
- Real-time data updates

### Table Component
```typescript
interface TableProps<T> {
  columns: TableColumn<T>[];
  data: T[];
  loading?: boolean;
  pagination?: PaginationConfig;
  sorting?: SortingConfig;
  filtering?: FilterConfig;
  selection?: SelectionConfig;
  actions?: TableAction<T>[];
}
```

**Features:**
- Virtual scrolling for large datasets
- Column sorting and filtering
- Row selection
- Bulk actions
- Export to CSV/Excel

---

## 🔔 Feedback Components

### Alert Component
```typescript
interface AlertProps {
  variant: 'info' | 'success' | 'warning' | 'error';
  title?: string;
  description: string;
  dismissible?: boolean;
  actions?: AlertAction[];
  icon?: React.ReactNode;
  onDismiss?: () => void;
}
```

### Toast Component
```typescript
interface ToastProps {
  variant: 'info' | 'success' | 'warning' | 'error';
  title?: string;
  description: string;
  duration?: number;
  action?: ToastAction;
  position?: 'top-right' | 'top-left' | 'bottom-right' | 'bottom-left';
}
```

### Modal Component
```typescript
interface ModalProps {
  open: boolean;
  onClose: () => void;
  title?: string;
  size?: 'sm' | 'md' | 'lg' | 'xl' | 'full';
  closeOnOverlayClick?: boolean;
  closeOnEscape?: boolean;
  children: React.ReactNode;
}
```

---

## 🏠 Marketing Components

### Hero Component
```typescript
interface HeroProps {
  variant: 'default' | 'gradient' | 'video' | 'split';
  title: string;
  subtitle?: string;
  description: string;
  primaryAction: ActionButton;
  secondaryAction?: ActionButton;
  metrics?: HeroMetric[];
  media?: React.ReactNode;
  background?: string;
}
```

**Features:**
- Typing animation for headlines
- Real-time metric updates
- Video backgrounds
- Gradient overlays
- Floating dashboard preview

### FeatureCard Component
```typescript
interface FeatureCardProps {
  icon: React.ReactNode;
  title: string;
  description: string;
  features?: string[];
  link?: string;
  variant?: 'default' | 'highlighted' | 'compact';
  interactive?: boolean;
}
```

### TestimonialCard Component
```typescript
interface TestimonialCardProps {
  quote: string;
  author: {
    name: string;
    title: string;
    company: string;
    avatar: string;
  };
  metric?: {
    value: string;
    label: string;
    color: string;
  };
  variant?: 'default' | 'featured' | 'compact';
}
```

---

## 📈 Dashboard Components

### DashboardLayout Component
```typescript
interface DashboardLayoutProps {
  sidebar: React.ReactNode;
  header: React.ReactNode;
  children: React.ReactNode;
  breadcrumbs?: BreadcrumbItem[];
  actions?: React.ReactNode;
}
```

### InsightCard Component
```typescript
interface InsightCardProps {
  type: 'opportunity' | 'warning' | 'info' | 'success';
  title: string;
  description: string;
  action?: {
    label: string;
    onClick: () => void;
  };
  dismissible?: boolean;
  priority?: 'high' | 'medium' | 'low';
}
```

**Features:**
- AI-powered insights
- Priority-based styling
- Action buttons
- Dismissible with persistence
- Animation on appearance

### RevenueChart Component
```typescript
interface RevenueChartProps {
  data: RevenueData[];
  timeRange: TimeRange;
  metrics: ('mrr' | 'arr' | 'churn' | 'ltv')[];
  comparison?: boolean;
  forecast?: boolean;
  onTimeRangeChange: (range: TimeRange) => void;
}
```

---

## ⚙️ Admin Components

### AdminLayout Component
```typescript
interface AdminLayoutProps {
  navigation: AdminNavigation[];
  user: AdminUser;
  children: React.ReactNode;
  breadcrumbs?: BreadcrumbItem[];
  notifications?: Notification[];
}
```

### UserManagement Component
```typescript
interface UserManagementProps {
  users: User[];
  filters: UserFilter[];
  actions: UserAction[];
  onUserAction: (action: string, user: User) => void;
  onBulkAction: (action: string, users: User[]) => void;
}
```

### SystemStatus Component
```typescript
interface SystemStatusProps {
  services: ServiceStatus[];
  metrics: SystemMetric[];
  alerts: SystemAlert[];
  refreshInterval?: number;
  onServiceAction: (service: string, action: string) => void;
}
```

---

## 🎯 Implementation Strategy

### Phase 1: Foundation (Week 1-2)
1. **Design Token Setup** - CSS custom properties and Tailwind config
2. **Core Components** - Button, Input, Typography, Layout
3. **Navigation Components** - Navbar, Sidebar, Breadcrumb
4. **Component Documentation** - Storybook setup

### Phase 2: Data Components (Week 3-4)
1. **MetricCard Implementation** - With animations and states
2. **Chart Components** - Chart.js integration
3. **Table Component** - With sorting, filtering, pagination
4. **Feedback Components** - Alert, Toast, Modal

### Phase 3: Page-Specific Components (Week 5-6)
1. **Marketing Components** - Hero, FeatureCard, TestimonialCard
2. **Dashboard Components** - Layout, InsightCard, RevenueChart
3. **Admin Components** - UserManagement, SystemStatus
4. **Responsive Testing** - Mobile, tablet, desktop

### Phase 4: Enhancement & Polish (Week 7-8)
1. **Accessibility Audit** - WCAG 2.1 AA compliance
2. **Performance Optimization** - Bundle size, lazy loading
3. **Animation Polish** - Micro-interactions, transitions
4. **Cross-browser Testing** - Chrome, Firefox, Safari, Edge

---

## 🔧 Technical Implementation

### Component Template
```typescript
// components/foundation/Button/Button.tsx
import React from 'react';
import { cn } from '@/lib/utils';
import { buttonVariants } from './Button.variants';

export interface ButtonProps extends React.ButtonHTMLAttributes<HTMLButtonElement> {
  variant?: 'primary' | 'secondary' | 'outline' | 'ghost' | 'danger';
  size?: 'sm' | 'md' | 'lg' | 'xl';
  loading?: boolean;
  icon?: React.ReactNode;
  iconPosition?: 'left' | 'right';
  fullWidth?: boolean;
}

export const Button = React.forwardRef<HTMLButtonElement, ButtonProps>(
  ({ 
    className, 
    variant = 'primary', 
    size = 'md', 
    loading = false,
    icon,
    iconPosition = 'left',
    fullWidth = false,
    children, 
    disabled,
    ...props 
  }, ref) => {
    return (
      <button
        className={cn(
          buttonVariants({ variant, size, fullWidth }),
          loading && 'opacity-50 cursor-not-allowed',
          className
        )}
        ref={ref}
        disabled={disabled || loading}
        {...props}
      >
        {loading && <LoadingSpinner className="mr-2" />}
        {icon && iconPosition === 'left' && <span className="mr-2">{icon}</span>}
        {children}
        {icon && iconPosition === 'right' && <span className="ml-2">{icon}</span>}
      </button>
    );
  }
);

Button.displayName = 'Button';
```

### Variant System
```typescript
// components/foundation/Button/Button.variants.ts
import { cva } from 'class-variance-authority';

export const buttonVariants = cva(
  'inline-flex items-center justify-center font-medium transition-all duration-200 focus:outline-none focus:ring-2 focus:ring-offset-2 disabled:opacity-50 disabled:cursor-not-allowed',
  {
    variants: {
      variant: {
        primary: 'bg-primary-600 text-white hover:bg-primary-700 focus:ring-primary-500',
        secondary: 'bg-gray-100 text-gray-900 hover:bg-gray-200 focus:ring-gray-500',
        outline: 'border border-primary-600 text-primary-600 hover:bg-primary-50 focus:ring-primary-500',
        ghost: 'text-primary-600 hover:bg-primary-50 focus:ring-primary-500',
        danger: 'bg-error-600 text-white hover:bg-error-700 focus:ring-error-500',
      },
      size: {
        sm: 'px-3 py-1.5 text-sm rounded-md',
        md: 'px-4 py-2 text-base rounded-lg',
        lg: 'px-6 py-3 text-lg rounded-lg',
        xl: 'px-8 py-4 text-xl rounded-xl',
      },
      fullWidth: {
        true: 'w-full',
      },
    },
    defaultVariants: {
      variant: 'primary',
      size: 'md',
    },
  }
);
```

---

## 📱 Responsive Design Strategy

### Breakpoint System
```css
/* Mobile First Approach */
--breakpoint-sm: 640px;   /* Small devices */
--breakpoint-md: 768px;   /* Medium devices */
--breakpoint-lg: 1024px;  /* Large devices */
--breakpoint-xl: 1280px;  /* Extra large devices */
--breakpoint-2xl: 1536px; /* 2X large devices */
```

### Component Responsiveness
- **MetricCard**: 1 column mobile, 2 tablet, 4 desktop
- **Navigation**: Hamburger menu mobile, full nav desktop
- **Charts**: Responsive height and font sizes
- **Tables**: Horizontal scroll mobile, full table desktop
- **Modals**: Full screen mobile, centered desktop

---

## ♿ Accessibility Standards

### WCAG 2.1 AA Compliance
1. **Color Contrast**: Minimum 4.5:1 ratio for normal text
2. **Keyboard Navigation**: Full keyboard accessibility
3. **Screen Reader Support**: Proper ARIA labels and roles
4. **Focus Management**: Visible focus indicators
5. **Alternative Text**: Images and icons with alt text

### Implementation
```typescript
// Accessibility utilities
export const a11y = {
  // Screen reader only text
  srOnly: 'sr-only',
  
  // Focus management
  focusRing: 'focus:ring-2 focus:ring-primary-500 focus:ring-offset-2',
  
  // High contrast mode support
  highContrast: 'contrast-more:border-black contrast-more:text-black',
  
  // Reduced motion support
  reducedMotion: 'motion-reduce:transition-none motion-reduce:animate-none',
};
```

---

## 🚀 Performance Optimization

### Bundle Optimization
1. **Tree Shaking**: Import only used components
2. **Code Splitting**: Lazy load page-specific components
3. **Image Optimization**: WebP format with fallbacks
4. **CSS Purging**: Remove unused Tailwind classes

### Runtime Performance
1. **Virtual Scrolling**: For large data tables
2. **Memoization**: React.memo for expensive components
3. **Debounced Inputs**: For search and filters
4. **Optimistic Updates**: Immediate UI feedback

---

## 📊 Success Metrics

### Development Metrics
- **Component Reusability**: 80%+ code reuse across pages
- **Bundle Size**: <200KB gzipped for core components
- **Performance**: Lighthouse score 95+ for all pages
- **Accessibility**: WCAG 2.1 AA compliance 100%

### User Experience Metrics
- **Page Load Time**: <2 seconds first contentful paint
- **Interaction Response**: <100ms for all interactions
- **Mobile Usability**: 95%+ mobile usability score
- **User Satisfaction**: 4.5+ star rating for UI/UX

---

## 🎉 Conclusion

This comprehensive UI Component Refactor Plan transforms SaaSpype from a functional but fragmented interface into a cohesive, scalable, and delightful user experience. The modular component system ensures consistency, maintainability, and rapid feature development while meeting enterprise-grade accessibility and performance standards.

**Next Steps:**
1. **Stakeholder Review** - Validate component specifications
2. **Design System Setup** - Implement design tokens and core components
3. **Component Development** - Build components following the phased approach
4. **Integration Testing** - Ensure seamless integration with existing backend
5. **User Testing** - Validate improved user experience with real users

The result will be a production-ready SaaS platform that scales beautifully from startup to enterprise, providing users with the tools they need to grow their businesses efficiently and effectively.

---

**Document Status**: ✅ COMPLETE  
**Created**: 2025-06-01  
**Last Updated**: 2025-06-01  
**Version**: 1.0  
**Author**: UI/UX Refactor Strategist 