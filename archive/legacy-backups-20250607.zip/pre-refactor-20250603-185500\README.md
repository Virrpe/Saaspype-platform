# SaaSpype - Scale Your SaaS from $0 to $1M ARR

A complete SaaS analytics platform with JWT authentication, real user management, and subscription tracking. Built with FastAPI backend and modern frontend.

## 🚀 Quick Start

### Prerequisites
- Python 3.8+
- Modern web browser

### Installation & Setup

1. **Install Dependencies**
   ```bash
   pip install fastapi uvicorn pydantic passlib python-jose bcrypt python-multipart
   ```

2. **Start the Backend API**
   ```bash
   python apps/src/api/main.py
   ```

3. **Start the Frontend Server** (in a new terminal)
   ```bash
   python serve_clean.py
   ```

4. **Access the Application**
   - 🌐 **Landing Page**: http://localhost:8081
   - 🔐 **Login/Signup**: http://localhost:8081/auth
   - 📊 **User Dashboard**: http://localhost:8081/dashboard (requires auth)
   - 👨‍💼 **Admin Panel**: http://localhost:8081/admin (requires auth)
   - 🔧 **API Documentation**: http://localhost:8000/docs

## 🏗️ Project Structure

```
saaspype/
├── apps/
│   ├── src/
│   │   └── api/
│   │       └── main.py              # FastAPI backend with JWT auth
│   └── frontend/
│       └── pages/
│           ├── index.html           # Public landing page
│           ├── auth.html            # Login/Signup page
│           ├── dashboard.html       # User dashboard (protected)
│           └── admin.html           # Admin panel (protected)
├── memory/
│   └── saaspype.db                  # SQLite database
├── serve_clean.py                   # Frontend server launcher
└── README.md
```

## 🎯 Features

### Public Landing Page
- **Hero Section** with compelling SaaS messaging
- **Features Showcase** highlighting platform capabilities
- **Dynamic Pricing Plans** loaded from API
- **Contact Form** with backend integration
- **User Signup** with proper authentication flow
- **Responsive Design** with modern UI/UX

### Authentication System
- **JWT Token Authentication** with 30-minute expiration
- **Secure Password Hashing** using bcrypt
- **User Registration & Login** with form validation
- **Protected Routes** requiring valid authentication
- **Automatic Token Validation** and refresh handling

### User Dashboard
- **Real User Data** isolation per authenticated user
- **Subscription Management** with add/edit capabilities
- **Analytics Metrics** based on user's actual data
- **Interactive Charts** showing revenue and growth
- **Responsive Design** with loading states

### Admin Panel
- **JWT-Protected Access** (any authenticated user can access)
- **User Management** with detailed user information
- **Contact Messages** management and viewing
- **Real-time Statistics** and analytics
- **Clean Admin Interface** with navigation

### Backend API
- **FastAPI Framework** with automatic documentation
- **SQLite Database** with proper relational schema
- **JWT Authentication** with secure token handling
- **CORS Support** for frontend integration
- **RESTful Endpoints** for all operations

## 🔐 Authentication Flow

**New User Registration:**
1. Visit landing page → Click "Start Free Trial"
2. Fill signup form → Submit → JWT token generated
3. Automatic redirect to dashboard with user data

**Existing User Login:**
1. Visit /auth → Enter credentials → Submit
2. JWT token validated → Redirect to dashboard

**Protected Access:**
- Dashboard and Admin panel check for valid JWT tokens
- Invalid/expired tokens redirect to login page
- All API calls include Bearer token authentication

## 📊 API Endpoints

### Public Endpoints
- `GET /` - API status
- `GET /api/pricing` - Get pricing plans
- `POST /api/contact` - Submit contact form
- `POST /api/signup` - User registration (returns JWT)
- `POST /api/login` - User authentication (returns JWT)

### Protected Endpoints (Requires JWT)
- `GET /api/me` - Get current user info
- `GET /api/dashboard` - Get user's dashboard data
- `POST /api/subscription` - Create subscription for user
- `GET /api/admin/users` - List all users (admin)
- `GET /api/admin/contacts` - List contact messages (admin)

## 🗄️ Database Schema

### Users Table
- `id` (TEXT PRIMARY KEY)
- `email` (TEXT UNIQUE)
- `name` (TEXT)
- `company` (TEXT, optional)
- `password_hash` (TEXT, bcrypt)
- `created_at` (TIMESTAMP)
- `is_active` (BOOLEAN)

### Subscriptions Table
- `id` (TEXT PRIMARY KEY)
- `user_id` (TEXT, foreign key)
- `plan` (TEXT)
- `amount` (REAL)
- `status` (TEXT, default 'active')
- `created_at` (TIMESTAMP)

### Contacts Table
- `id` (TEXT PRIMARY KEY)
- `name` (TEXT)
- `email` (TEXT)
- `company` (TEXT, optional)
- `message` (TEXT)
- `created_at` (TIMESTAMP)

## 🎨 Technology Stack

**Frontend:**
- HTML5 with semantic structure
- Tailwind CSS for styling
- Vanilla JavaScript for interactivity
- Font Awesome for icons
- JWT token management in localStorage

**Backend:**
- FastAPI for API development
- Pydantic for data validation
- SQLite for database storage
- bcrypt for password hashing
- python-jose for JWT handling
- Uvicorn for ASGI server

**Security:**
- JWT tokens with HS256 algorithm
- bcrypt password hashing with salt
- Protected API routes
- CORS configuration
- Input validation

## 🚀 Development

### Adding New Features
1. **Backend**: Add endpoints in `apps/src/api/main.py`
2. **Frontend**: Update HTML/JS in `apps/frontend/pages/`
3. **Database**: Modify schema in the `init_database()` function

### Testing the System
1. Start both servers (API on :8000, Frontend on :8081)
2. Visit http://localhost:8081
3. Create a new account or login
4. Test dashboard functionality
5. Try admin panel access

## 📝 Production Notes

- **Change SECRET_KEY** in production environment
- **Configure proper CORS** origins for production
- **Use environment variables** for sensitive configuration
- **Implement proper logging** and monitoring
- **Add rate limiting** for API endpoints
- **Consider database migrations** for schema changes

---

Built with ❤️ using FastAPI, JWT authentication, and modern web technologies.
