#!/usr/bin/env python3
"""
Test script for Enhanced Discovery API
Verifies Phase 1B improvements are integrated correctly
"""

import requests
import json
import time

def test_enhanced_discovery_api():
    """Test the enhanced discovery API endpoint"""
    print("🧪 Testing Enhanced Discovery API v2.1")
    print("=" * 50)
    
    # Test endpoint
    url = "http://127.0.0.1:8000/api/discover"
    
    # Test payload
    payload = {
        "query": "startups"
    }
    
    try:
        print(f"📡 Sending request to: {url}")
        print(f"📋 Payload: {json.dumps(payload, indent=2)}")
        
        start_time = time.time()
        response = requests.post(url, json=payload, timeout=30)
        response_time = time.time() - start_time
        
        print(f"⏱️  Response time: {response_time:.2f}s")
        print(f"📊 Status code: {response.status_code}")
        
        if response.status_code == 200:
            data = response.json()
            
            print("\n✅ API Response Analysis:")
            print(f"   Success: {data.get('success', False)}")
            print(f"   Posts Found: {data.get('posts_found', 0)}")
            print(f"   Scraper Type: {data.get('scraper_type', 'unknown')}")
            print(f"   Processing Time: {data.get('processing_time_seconds', 0)}s")
            
            # Check for Phase 1B enhancements
            enhancement_features = data.get('enhancement_features', [])
            print(f"\n🚀 Phase 1B Enhancement Features ({len(enhancement_features)}):")
            for feature in enhancement_features:
                print(f"   ✅ {feature.replace('_', ' ').title()}")
            
            # Quality metrics
            quality_metrics = data.get('quality_metrics', {})
            if quality_metrics:
                print(f"\n📊 Quality Metrics:")
                print(f"   Average Confidence: {quality_metrics.get('average_confidence', 0):.2f}")
                print(f"   Posts Processed: {quality_metrics.get('total_posts_processed', 0)}")
                print(f"   Posts Returned: {quality_metrics.get('posts_returned', 0)}")
                print(f"   Industry Distribution: {quality_metrics.get('industry_distribution', {})}")
                print(f"   Business Size Distribution: {quality_metrics.get('business_size_distribution', {})}")
            
            # Performance stats
            performance_stats = data.get('performance_stats', {})
            if performance_stats:
                print(f"\n⚡ Performance Statistics:")
                print(f"   Posts per Second: {performance_stats.get('posts_per_second', 0)}")
                print(f"   Quality Filter Efficiency: {performance_stats.get('quality_filter_efficiency', 0)}%")
                print(f"   Average Post Quality: {performance_stats.get('average_post_quality', 0)}%")
            
            # Sample pain points
            pain_points = data.get('pain_points', [])
            if pain_points:
                print(f"\n🎯 Sample Pain Points ({len(pain_points)}):")
                for i, post in enumerate(pain_points[:3], 1):
                    confidence = post.get('analysis_confidence', {}).get('overall', 0)
                    industry = post.get('business_context', {}).get('industry', 'unknown')
                    spam_score = post.get('spam_analysis', {}).get('spam_score', 0)
                    print(f"   {i}. {post.get('title', '')[:60]}...")
                    print(f"      Industry: {industry} | Confidence: {confidence:.2f} | Spam Score: {spam_score}")
            
            print(f"\n✅ Enhanced Discovery API Test: PASSED")
            return True
            
        else:
            print(f"❌ API Error: {response.status_code}")
            print(f"Response: {response.text}")
            return False
            
    except requests.exceptions.ConnectionError:
        print("❌ Connection Error: API server not running on port 8000")
        print("💡 Make sure to start the API server first:")
        print("   cd apps/src/api && python -m uvicorn main:app --host 127.0.0.1 --port 8000 --reload")
        return False
        
    except Exception as e:
        print(f"❌ Test failed: {e}")
        return False

if __name__ == "__main__":
    success = test_enhanced_discovery_api()
    
    if success:
        print("\n🎉 Phase 1B Enhancement Integration: SUCCESSFUL")
        print("🔧 All enhanced features are operational and accessible via API")
    else:
        print("\n⚠️  Phase 1B Enhancement Integration: NEEDS ATTENTION")
        print("🔧 Check API server status and configuration") 