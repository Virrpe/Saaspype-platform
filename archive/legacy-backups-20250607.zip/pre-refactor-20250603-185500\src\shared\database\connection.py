#!/usr/bin/env python3
"""
Database Connection - Centralized database connection management
"""

import sqlite3
import logging
from pathlib import Path
from typing import Optional
from src.shared.config.settings import DATABASE_PATH

logger = logging.getLogger(__name__)

class DatabaseService:
    def __init__(self, db_path: Optional[str] = None):
        self.db_path = db_path or DATABASE_PATH
        self.init_db()
    
    def get_connection(self) -> sqlite3.Connection:
        """Get database connection"""
        return sqlite3.connect(self.db_path)
    
    def init_db(self):
        """Initialize the database with discovery-focused tables"""
        conn = self.get_connection()
        cursor = conn.cursor()
        
        # Users table
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS users (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                email TEXT UNIQUE NOT NULL,
                password_hash TEXT NOT NULL,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            )
        """)
        
        # Saved ideas table
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS saved_ideas (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                user_id INTEGER NOT NULL,
                idea_title TEXT NOT NULL,
                idea_description TEXT,
                pain_point_source TEXT,
                market_potential TEXT,
                concept_data TEXT,
                system_generated INTEGER DEFAULT 0,
                saved_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                FOREIGN KEY (user_id) REFERENCES users (id)
            )
        """)
        
        # Discovery sessions table
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS discovery_sessions (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                user_id INTEGER,
                subreddit TEXT NOT NULL,
                posts_analyzed INTEGER DEFAULT 0,
                pain_points_found INTEGER DEFAULT 0,
                session_data TEXT,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                FOREIGN KEY (user_id) REFERENCES users (id)
            )
        """)
        
        conn.commit()
        
        # Ensure system_generated column exists (for existing databases)
        try:
            cursor.execute('ALTER TABLE saved_ideas ADD COLUMN system_generated INTEGER DEFAULT 0')
            conn.commit()
            logger.info("Added system_generated column to existing database")
        except sqlite3.OperationalError as e:
            if "duplicate column name" not in str(e):
                logger.warning(f"Could not add system_generated column: {e}")
        
        conn.close()
        logger.info(f"Database initialized at {self.db_path}")

# Global database instance
db_service = DatabaseService() 