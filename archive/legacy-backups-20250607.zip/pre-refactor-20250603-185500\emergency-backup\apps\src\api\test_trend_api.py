#!/usr/bin/env python3
"""
Test script for Phase 3 Live Trend & Signal Detection API
Verifies all trend detection endpoints and functionality
"""

import requests
import json
import time

def test_trend_detection_api():
    """Test all trend detection API endpoints"""
    print("🔍 Testing Phase 3 Live Trend & Signal Detection API")
    print("=" * 70)
    
    # Base URL and headers
    base_url = "http://127.0.0.1:8001"
    headers = {
        "Content-Type": "application/json",
        "Authorization": "Bearer mock_token_for_testing"
    }
    
    # Test endpoints
    endpoints = [
        {
            'name': 'Main Trend Analysis',
            'url': f"{base_url}/api/trends",
            'params': {'limit_sessions': 20, 'include_predictions': True, 'include_alerts': True}
        },
        {
            'name': 'Trending Keywords',
            'url': f"{base_url}/api/trends/keywords",
            'params': {'limit': 10}
        },
        {
            'name': 'Emerging Categories',
            'url': f"{base_url}/api/trends/categories",
            'params': {'limit': 5}
        },
        {
            'name': 'High Signal Opportunities',
            'url': f"{base_url}/api/trends/signals",
            'params': {'limit': 10}
        },
        {
            'name': 'Trend Alerts',
            'url': f"{base_url}/api/trends/alerts",
            'params': {}
        },
        {
            'name': 'Trend Predictions',
            'url': f"{base_url}/api/trends/predictions",
            'params': {}
        }
    ]
    
    results = {}
    
    for endpoint in endpoints:
        print(f"\n🧪 Testing {endpoint['name']}...")
        print(f"   URL: {endpoint['url']}")
        
        try:
            start_time = time.time()
            response = requests.get(endpoint['url'], params=endpoint['params'], headers=headers, timeout=30)
            response_time = time.time() - start_time
            
            print(f"   ⏱️  Response time: {response_time:.2f}s")
            print(f"   📊 Status code: {response.status_code}")
            
            if response.status_code == 200:
                data = response.json()
                
                # Analyze response based on endpoint type
                if 'trends' in endpoint['url'] and endpoint['url'].endswith('/trends'):
                    # Main trend analysis
                    print(f"   ✅ Main Trend Analysis Results:")
                    print(f"      Success: {data.get('success', False)}")
                    print(f"      Data Points: {data.get('data_points_analyzed', 0)}")
                    print(f"      Enhancement Level: {data.get('enhancement_level', 'unknown')}")
                    print(f"      Trending Keywords: {len(data.get('trending_keywords', []))}")
                    print(f"      Emerging Categories: {len(data.get('emerging_categories', []))}")
                    print(f"      High Signals: {len(data.get('high_signal_opportunities', []))}")
                    print(f"      Market Insights: {len(data.get('market_insights', []))}")
                    print(f"      Alerts: {data.get('alert_count', 0)}")
                    
                    # Show sample trending keywords
                    trending = data.get('trending_keywords', [])
                    if trending:
                        print(f"      🔥 Top Trending Keywords:")
                        for i, keyword in enumerate(trending[:3], 1):
                            print(f"         {i}. {keyword.get('keyword', '')} (velocity: {keyword.get('velocity', 0):.2f})")
                    
                    # Show sample market insights
                    insights = data.get('market_insights', [])
                    if insights:
                        print(f"      💡 Market Insights:")
                        for insight in insights[:2]:
                            print(f"         • {insight}")
                
                elif 'keywords' in endpoint['url']:
                    # Trending keywords
                    print(f"   ✅ Trending Keywords Results:")
                    keywords = data.get('trending_keywords', [])
                    print(f"      Total Keywords: {data.get('total_keywords', 0)}")
                    print(f"      Returned: {len(keywords)}")
                    if keywords:
                        print(f"      Top Keywords:")
                        for i, kw in enumerate(keywords[:5], 1):
                            print(f"         {i}. {kw.get('keyword', '')} (velocity: {kw.get('velocity', 0):.2f}, direction: {kw.get('direction', '')})")
                
                elif 'categories' in endpoint['url']:
                    # Emerging categories
                    print(f"   ✅ Emerging Categories Results:")
                    categories = data.get('emerging_categories', [])
                    print(f"      Total Categories: {data.get('total_categories', 0)}")
                    print(f"      Returned: {len(categories)}")
                    if categories:
                        print(f"      Emerging Categories:")
                        for i, cat in enumerate(categories[:3], 1):
                            print(f"         {i}. {cat.get('category', '')} ({cat.get('health', '')}, {cat.get('opportunities', 0)} opportunities)")
                
                elif 'signals' in endpoint['url']:
                    # High signal opportunities
                    print(f"   ✅ High Signal Opportunities Results:")
                    signals = data.get('high_signal_opportunities', [])
                    print(f"      Total Signals: {data.get('total_signals', 0)}")
                    print(f"      Returned: {len(signals)}")
                    print(f"      Signal Threshold: {data.get('signal_threshold', 0)}")
                    if signals:
                        print(f"      High Signal Opportunities:")
                        for i, signal in enumerate(signals[:3], 1):
                            print(f"         {i}. {signal.get('title', '')[:50]}...")
                            print(f"            Signal Strength: {signal.get('signal_strength', 0):.2f}")
                            print(f"            Category: {signal.get('category', '')}")
                            print(f"            Confidence: {signal.get('confidence', 0):.2f}")
                
                elif 'alerts' in endpoint['url']:
                    # Trend alerts
                    print(f"   ✅ Trend Alerts Results:")
                    alerts = data.get('alerts', [])
                    print(f"      Alert Count: {data.get('alert_count', 0)}")
                    print(f"      Total Alerts: {data.get('total_alerts', 0)}")
                    print(f"      Monitoring Status: {data.get('monitoring_status', {}).get('status', 'unknown')}")
                    if alerts:
                        print(f"      Active Alerts:")
                        for i, alert in enumerate(alerts[:3], 1):
                            print(f"         {i}. {alert.get('type', '')} ({alert.get('severity', '')})")
                            print(f"            Message: {alert.get('message', '')}")
                
                elif 'predictions' in endpoint['url']:
                    # Trend predictions
                    print(f"   ✅ Trend Predictions Results:")
                    predictions = data.get('predictions', {})
                    print(f"      Prediction Confidence: {data.get('prediction_confidence', 'unknown')}")
                    print(f"      Next Update: {data.get('next_update_recommended', 'unknown')}")
                    
                    # Show keyword predictions
                    keyword_pred = predictions.get('trending_keywords_24h', [])
                    if keyword_pred:
                        print(f"      🔮 Predicted Trending Keywords (24h):")
                        for i, pred in enumerate(keyword_pred[:3], 1):
                            print(f"         {i}. {pred.get('keyword', '')} (predicted freq: {pred.get('predicted_frequency', 0):.1f})")
                    
                    # Show category predictions
                    category_pred = predictions.get('emerging_categories', [])
                    if category_pred:
                        print(f"      📈 Predicted Emerging Categories:")
                        for i, pred in enumerate(category_pred[:3], 1):
                            print(f"         {i}. {pred.get('category', '')} (emergence score: {pred.get('emergence_score', 0):.2f})")
                
                results[endpoint['name']] = 'PASSED'
                
            elif response.status_code == 401:
                print(f"   ⚠️  Authentication Error: {response.status_code}")
                print("   💡 This is expected - you need to authenticate first")
                results[endpoint['name']] = 'NEEDS_AUTH'
                
            else:
                print(f"   ❌ API Error: {response.status_code}")
                print(f"   Response: {response.text}")
                results[endpoint['name']] = 'FAILED'
                
        except requests.exceptions.ConnectionError:
            print(f"   ❌ Connection Error: API server not running on port 8001")
            print("   💡 Make sure to start the API server first")
            results[endpoint['name']] = 'CONNECTION_ERROR'
            
        except Exception as e:
            print(f"   ❌ Test failed: {e}")
            results[endpoint['name']] = 'ERROR'
    
    # Summary
    print(f"\n📋 Test Results Summary:")
    print("=" * 50)
    for endpoint_name, result in results.items():
        status_icon = {
            'PASSED': '✅',
            'NEEDS_AUTH': '⚠️',
            'FAILED': '❌',
            'CONNECTION_ERROR': '🔌',
            'ERROR': '💥'
        }.get(result, '❓')
        print(f"   {status_icon} {endpoint_name}: {result}")
    
    # Overall assessment
    passed_count = sum(1 for r in results.values() if r == 'PASSED')
    auth_count = sum(1 for r in results.values() if r == 'NEEDS_AUTH')
    total_count = len(results)
    
    if passed_count > 0:
        print(f"\n🎉 Phase 3 Live Trend & Signal Detection: FUNCTIONAL")
        print(f"   ✅ {passed_count} endpoints working correctly")
        if auth_count > 0:
            print(f"   ⚠️  {auth_count} endpoints need authentication (expected)")
        print(f"🔧 Advanced trend detection, signal analysis, and predictive analytics operational")
    else:
        print(f"\n⚠️  Phase 3 Implementation: NEEDS ATTENTION")
        print(f"🔧 Check API server status and trend detection module")
    
    return results

def test_trend_module_standalone():
    """Test the trend detection module standalone"""
    print("\n🔍 Testing Trend Detection Module Standalone...")
    print("=" * 50)
    
    try:
        from trend_detector import run_trend_analysis, TrendDetectionEngine, RealTimeMonitor
        
        # Test trend analysis
        print("   Running trend analysis...")
        trend_report = run_trend_analysis(limit_sessions=10)
        
        print(f"   ✅ Trend Analysis Results:")
        print(f"      Data Points: {trend_report.get('data_points_analyzed', 0)}")
        print(f"      Analysis Duration: {trend_report.get('analysis_duration', 0):.3f}s")
        print(f"      Keywords Tracked: {trend_report.get('trend_detection_stats', {}).get('keywords_tracked', 0)}")
        print(f"      Categories Analyzed: {trend_report.get('trend_detection_stats', {}).get('categories_analyzed', 0)}")
        print(f"      Signals Detected: {trend_report.get('trend_detection_stats', {}).get('signals_detected', 0)}")
        print(f"      Anomalies Found: {trend_report.get('trend_detection_stats', {}).get('anomalies_found', 0)}")
        print(f"      Alerts Generated: {trend_report.get('alert_count', 0)}")
        
        # Test real-time monitor
        print("\n   Testing real-time monitor...")
        trend_engine = TrendDetectionEngine()
        monitor = RealTimeMonitor(trend_engine)
        monitoring_status = monitor.start_monitoring(interval_minutes=15)
        
        print(f"   ✅ Real-time Monitor:")
        print(f"      Status: {monitoring_status.get('status', 'unknown')}")
        print(f"      Interval: {monitoring_status.get('interval_minutes', 0)} minutes")
        print(f"      Active: {monitoring_status.get('monitoring_active', False)}")
        
        print(f"\n🚀 Trend Detection Module: OPERATIONAL")
        return True
        
    except Exception as e:
        print(f"   ❌ Module test failed: {e}")
        return False

if __name__ == "__main__":
    print("🔍 Phase 3 Live Trend & Signal Detection Testing Suite")
    print("=" * 70)
    
    # Test standalone module first
    module_success = test_trend_module_standalone()
    
    # Test API integration
    api_results = test_trend_detection_api()
    
    print(f"\n📋 Final Test Summary:")
    print("=" * 50)
    print(f"   Trend Module: {'✅ OPERATIONAL' if module_success else '❌ FAILED'}")
    
    api_passed = sum(1 for r in api_results.values() if r in ['PASSED', 'NEEDS_AUTH'])
    api_total = len(api_results)
    print(f"   API Endpoints: {api_passed}/{api_total} functional")
    
    if module_success and api_passed > 0:
        print(f"\n🎉 Phase 3 Implementation: SUCCESSFUL")
        print(f"🔧 Live trend detection, signal analysis, and predictive analytics operational")
        print(f"🚀 Ready for production use with real-time monitoring capabilities")
    else:
        print(f"\n⚠️  Phase 3 Implementation: NEEDS ATTENTION")
        print(f"🔧 Check trend detection module and API integration") 