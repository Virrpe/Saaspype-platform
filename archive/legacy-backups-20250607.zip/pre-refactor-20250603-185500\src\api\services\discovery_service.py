#!/usr/bin/env python3
"""
Discovery Service - Enhanced Reddit discovery with LLM analysis
Now using real Reddit API with OAuth2 and rate limiting
"""

import random
import time
import json
import re
import asyncio
from datetime import datetime, timedelta
from typing import List, Dict, Any, Optional, Set
import os
import logging
import hashlib
from collections import defaultdict

# Configure logging
logger = logging.getLogger(__name__)

from src.shared.config.settings import MEMORY_DIR, PROCESSED_POSTS_FILE
from src.shared.database.connection import db_service
from src.api.services.reddit_api_client import reddit_api_client

class DiscoveryService:
    """Reddit discovery service with enhanced content quality and business intelligence"""
    
    def __init__(self):
        # Initialize Reddit API client
        self.reddit_client = reddit_api_client
        
        # Target subreddits for SaaS discovery
        self.target_subreddits = [
            'startups', 'Entrepreneur', 'SaaS', 'freelance', 'smallbusiness',
            'indiehackers', 'entrepreneur', 'business', 'marketing'
        ]
        
        # Enhanced spam detection patterns
        self.spam_keywords = [
            'upvote', 'karma', 'follow me', 'subscribe', 'like and share',
            'check out my', 'dm me', 'click here', 'free money', 'get rich',
            'make money fast', 'work from home', 'easy money', 'passive income',
            'crypto', 'bitcoin', 'nft', 'forex', 'trading signals'
        ]
        
        # Business-related keywords for content filtering
        self.business_keywords = [
            'startup', 'business', 'entrepreneur', 'saas', 'revenue', 'customers',
            'product', 'market', 'solution', 'problem', 'pain point', 'workflow',
            'automation', 'efficiency', 'cost', 'save time', 'productivity',
            'freelancer', 'client', 'agency', 'tool', 'platform', 'software'
        ]
        
        # Industries for categorization
        self.industries = [
            'fintech', 'healthcare', 'education', 'marketing', 'sales', 'hr',
            'logistics', 'ecommerce', 'real estate', 'travel', 'food', 'fitness',
            'legal', 'construction', 'manufacturing', 'retail', 'consulting'
        ]
        
        # Business context patterns for industry detection
        self.industry_patterns = {
            'software': [r'\b(saas|software|app|platform|api|code|dev|tech|ai|ml)\b'],
            'ecommerce': [r'\b(ecommerce|online\s+store|shopify|amazon|selling|retail)\b'],
            'marketing': [r'\b(marketing|advertising|social\s+media|seo|content|brand)\b'],
            'finance': [r'\b(finance|accounting|money|payment|fintech|banking)\b'],
            'healthcare': [r'\b(health|medical|doctor|patient|clinic|hospital)\b'],
            'education': [r'\b(education|learning|course|training|teach|student)\b'],
            'hr': [r'\b(hr|human\s+resources|hiring|recruitment|employee|staff)\b'],
            'logistics': [r'\b(logistics|shipping|delivery|transportation|supply\s+chain)\b'],
            'real estate': [r'\b(real\s+estate|property|housing|rent|mortgage)\b'],
            'travel': [r'\b(travel|tourism|hotel|booking|vacation|flight)\b'],
            'legal': [r'\b(legal|law|lawyer|attorney|contract|compliance)\b']
        }
        
        logger.info("Discovery Service initialized with Reddit API client")
    
    async def fetch_subreddit_posts(self, subreddit: str, limit: int = 10) -> List[Dict]:
        """Fetch posts from specified subreddit using real Reddit API"""
        try:
            logger.info(f"Fetching {limit} posts from r/{subreddit} using Reddit API")
            
            # Use the real Reddit API client
            raw_posts = await self.reddit_client.get_subreddit_posts(
                subreddit=subreddit,
                sort='new',  # Get recent posts for trend detection
                limit=limit * 2,  # Fetch more to account for filtering
                time_filter='day'
            )
            
            # If Reddit API fails or returns no data, try fallback
            if not raw_posts:
                logger.warning(f"Reddit API returned no data for r/{subreddit}, trying fallback")
                return await self._fallback_fetch_posts(subreddit, limit)
            
            # Process and filter posts
            processed_posts = []
            for post in raw_posts:
                # Skip if missing essential data
                if not post.get('title') or post.get('stickied', False):
                    continue
                
                # Skip deleted or removed posts
                if post.get('selftext') in ['[deleted]', '[removed]', '']:
                    continue
                
                # Enhanced spam detection
                spam_analysis = self._advanced_spam_detection(post)
                if spam_analysis['is_spam']:
                    logger.debug(f"Filtered spam post: {post.get('title', '')[:50]}...")
                    continue
                
                # Extract business context
                business_context = self._extract_business_context(post)
                
                # Convert created_utc to datetime for compatibility
                created_utc = post.get('created_utc', 0)
                if isinstance(created_utc, (int, float)):
                    created_datetime = datetime.fromtimestamp(created_utc)
                else:
                    created_datetime = datetime.now()
                
                processed_post = {
                    'id': post.get('id'),
                    'title': post.get('title'),
                    'body': post.get('selftext', ''),
                    'author': post.get('author'),
                    'score': post.get('score', 0),
                    'upvote_ratio': post.get('upvote_ratio', 0.5),
                    'num_comments': post.get('num_comments', 0),
                    'created_utc': created_utc,
                    'created_datetime': created_datetime.isoformat(),
                    'subreddit': subreddit,
                    'url': f"https://reddit.com{post.get('permalink', '')}",
                    'full_url': post.get('url', ''),
                    'is_self': post.get('is_self', True),
                    'link_flair_text': post.get('link_flair_text', ''),
                    'over_18': post.get('over_18', False),
                    'locked': post.get('locked', False),
                    'spam_analysis': spam_analysis,
                    'business_context': business_context,
                    'retrieved_via': 'reddit_api_oauth2'
                }
                
                processed_posts.append(processed_post)
                
                if len(processed_posts) >= limit:
                    break
            
            # If we got no processed posts after filtering, try fallback
            if not processed_posts:
                logger.warning(f"No valid posts after filtering from Reddit API for r/{subreddit}, trying fallback")
                return await self._fallback_fetch_posts(subreddit, limit)
            
            logger.info(f"Processed {len(processed_posts)} quality posts from r/{subreddit}")
            return processed_posts
            
        except Exception as e:
            logger.error(f"Error fetching posts from r/{subreddit} via Reddit API: {e}")
            # Fallback to public API if OAuth fails (for development/testing)
            logger.info(f"Attempting fallback to public API for r/{subreddit}")
            return await self._fallback_fetch_posts(subreddit, limit)
    
    async def _fallback_fetch_posts(self, subreddit: str, limit: int) -> List[Dict]:
        """Fallback to public Reddit JSON API if OAuth fails"""
        try:
            import requests
            
            logger.warning(f"Falling back to public JSON API for r/{subreddit}")
            
            session = requests.Session()
            session.headers.update({
                'User-Agent': 'SaaSpype:discovery-engine:v2.1 (by /u/saaspype_bot)'
            })
            
            url = f"https://www.reddit.com/r/{subreddit}/new.json"
            params = {'limit': limit * 3}  # Fetch more to account for filtering
            
            response = session.get(url, params=params, timeout=10)
            response.raise_for_status()
            
            data = response.json()
            posts = []
            
            for post_data in data.get('data', {}).get('children', []):
                post = post_data.get('data', {})
                
                # Skip if no title or if it's a sticky/pinned post
                if not post.get('title') or post.get('stickied', False):
                    continue
                
                # Skip deleted/removed posts
                if post.get('selftext') in ['[deleted]', '[removed]']:
                    continue
                
                # Accept both self posts and link posts with good titles
                # Skip only image/video posts without substantial text
                post_type = 'link' if not post.get('is_self', True) else 'self'
                
                # For link posts, ensure they have meaningful titles
                if post_type == 'link' and len(post.get('title', '')) < 20:
                    continue
                
                # Basic spam detection
                spam_analysis = self._advanced_spam_detection(post)
                if spam_analysis['is_spam']:
                    logger.debug(f"Filtered spam: {post.get('title', '')[:50]}...")
                    continue
                
                # Extract business context
                business_context = self._extract_business_context(post)
                
                # Convert created_utc to datetime
                created_utc = post.get('created_utc', 0)
                if isinstance(created_utc, (int, float)):
                    created_datetime = datetime.fromtimestamp(created_utc)
                else:
                    created_datetime = datetime.now()
                
                processed_post = {
                    'id': post.get('id'),
                    'title': post.get('title'),
                    'body': post.get('selftext', ''),
                    'author': post.get('author'),
                    'score': post.get('score', 0),
                    'upvote_ratio': post.get('upvote_ratio', 0.5),
                    'num_comments': post.get('num_comments', 0),
                    'created_utc': created_utc,
                    'created_datetime': created_datetime.isoformat(),
                    'subreddit': subreddit,
                    'url': f"https://reddit.com{post.get('permalink', '')}",
                    'full_url': post.get('url', ''),
                    'is_self': post.get('is_self', True),
                    'link_flair_text': post.get('link_flair_text', ''),
                    'over_18': post.get('over_18', False),
                    'locked': post.get('locked', False),
                    'spam_analysis': spam_analysis,
                    'business_context': business_context,
                    'retrieved_via': 'fallback_json_api'
                }
                
                posts.append(processed_post)
                
                if len(posts) >= limit:
                    break
            
            logger.info(f"Fallback: Successfully fetched {len(posts)} posts from r/{subreddit}")
            return posts
            
        except Exception as e:
            logger.error(f"Fallback fetch also failed for r/{subreddit}: {e}")
            return []
    
    def _calculate_content_hash(self, title: str, body: str) -> str:
        """Calculate hash for content deduplication"""
        content = f"{title.lower().strip()} {body.lower().strip()}"
        normalized = re.sub(r'\b(the|a|an|and|or|but|in|on|at|to|for|of|with|by)\b', '', content)
        normalized = re.sub(r'\s+', ' ', normalized).strip()
        return hashlib.md5(normalized.encode()).hexdigest()
    
    def _advanced_spam_detection(self, post: Dict) -> Dict:
        """Advanced spam detection with scoring"""
        title = post.get('title', '').lower()
        body = post.get('selftext', '').lower()
        combined_text = f"{title} {body}"
        
        spam_score = 0
        spam_indicators = []
        
        # Keyword-based detection (more targeted)
        high_spam_keywords = ['upvote', 'karma', 'follow me', 'dm me', 'free money', 'get rich quick']
        for keyword in high_spam_keywords:
            if keyword in combined_text:
                spam_score += 3
                spam_indicators.append(f"high_spam_keyword: {keyword}")
        
        # Lower-level spam indicators
        mild_spam_keywords = ['check out my', 'click here', 'subscribe', 'like and share']
        for keyword in mild_spam_keywords:
            if keyword in combined_text:
                spam_score += 1
                spam_indicators.append(f"mild_spam_keyword: {keyword}")
        
        # Account quality indicators
        author = post.get('author', '')
        if author in ['[deleted]', 'AutoModerator']:
            spam_score += 1
            spam_indicators.append("deleted_or_bot_account")
        
        # Content quality indicators (less aggressive)
        if len(title + body) < 20:  # Very short posts only
            spam_score += 1
            spam_indicators.append("very_low_content_length")
        
        # Multiple exclamation marks or caps
        if title.count('!') > 2 or len([c for c in title if c.isupper()]) > len(title) * 0.7:
            spam_score += 1
            spam_indicators.append("excessive_caps_or_exclamation")
        
        return {
            'spam_score': spam_score,
            'spam_indicators': spam_indicators,
            'is_spam': spam_score >= 6,  # Increased threshold
            'spam_confidence': min(1.0, spam_score / 10.0),
            'is_low_quality': spam_score >= 3
        }
    
    def _extract_business_context(self, post: Dict) -> Dict:
        """Extract business context from post content"""
        title = post.get('title', '').lower()
        body = post.get('selftext', '').lower()
        combined_text = f"{title} {body}"
        
        context = {
            'industry': 'general',
            'business_score': 0.0,
            'business_keywords': [],
            'problem_type': 'unknown',
            'urgency_level': 'low',
            'market_indicators': [],
            'pain_indicators': []
        }
        
        # Business keywords detection
        business_keywords_found = []
        for keyword in self.business_keywords:
            if keyword in combined_text:
                business_keywords_found.append(keyword)
                context['business_score'] += 0.2
        
        context['business_keywords'] = business_keywords_found
        
        # Industry detection (improved)
        industry_score = {}
        for industry, patterns in self.industry_patterns.items():
            score = 0
            for pattern in patterns:
                matches = len(re.findall(pattern, combined_text, re.IGNORECASE))
                score += matches
            if score > 0:
                industry_score[industry] = score
        
        if industry_score:
            context['industry'] = max(industry_score, key=industry_score.get)
            context['business_score'] += 0.5
        
        # Problem/pain point detection (improved)
        pain_patterns = {
            'workflow': [r'\b(workflow|process|manual|automat\w+|efficient|streamlin\w+)\b'],
            'cost': [r'\b(expensive|costly|save money|budget|cheap\w+|afford\w+)\b'],
            'time': [r'\b(time consuming|slow|faster|quick\w+|save time|speed)\b'],
            'technical': [r'\b(bug|error|broken|not working|failing|glitch)\b'],
            'user_experience': [r'\b(confusing|difficult|hard to use|user friendly|intuitive)\b'],
            'scaling': [r'\b(scale|scaling|grow\w+|expand\w+|capacity|limit\w+)\b']
        }
        
        problem_scores = {}
        for problem_type, patterns in pain_patterns.items():
            score = 0
            for pattern in patterns:
                matches = re.findall(pattern, combined_text, re.IGNORECASE)
                score += len(matches)
                context['pain_indicators'].extend(matches)
            if score > 0:
                problem_scores[problem_type] = score
        
        if problem_scores:
            context['problem_type'] = max(problem_scores, key=problem_scores.get)
            context['business_score'] += 0.3
        
        # Urgency detection
        urgency_patterns = [
            r'\b(urgent|asap|immediately|deadline|critical|emergency)\b',
            r'\b(need help|desperate|struggling|stuck)\b'
        ]
        
        urgency_score = 0
        for pattern in urgency_patterns:
            urgency_score += len(re.findall(pattern, combined_text, re.IGNORECASE))
        
        if urgency_score >= 2:
            context['urgency_level'] = 'high'
            context['business_score'] += 0.2
        elif urgency_score >= 1:
            context['urgency_level'] = 'medium'
            context['business_score'] += 0.1
        
        # Normalize business score
        context['business_score'] = min(1.0, context['business_score'])
        
        return context
    
    async def discover_pain_points(self, subreddit: str = 'startups', limit: int = 5) -> Dict:
        """Discover pain points from Reddit posts using real API"""
        try:
            logger.info(f"Starting pain point discovery for r/{subreddit} with limit {limit}")
            
            # Fetch posts using real Reddit API
            posts = await self.fetch_subreddit_posts(subreddit, limit)
            
            if not posts:
                logger.warning(f"No posts fetched from r/{subreddit}")
                return {
                    'subreddit': subreddit,
                    'posts_analyzed': 0,
                    'pain_points_found': 0,
                    'pain_points': [],
                    'ranked_opportunities': [],
                    'generated_concepts': [],
                    'error': 'No posts could be fetched from Reddit API',
                    'reddit_api_status': self.reddit_client.get_rate_limit_status()
                }
            
            pain_points = []
            ranked_opportunities = []
            generated_concepts = []
            
            for post in posts:
                if len(post['business_context']['pain_indicators']) > 0:
                    pain_point = {
                        'title': post['title'],
                        'description': post['body'][:500] + '...' if len(post['body']) > 500 else post['body'],
                        'source': f"r/{subreddit}",
                        'url': post['url'],
                        'industry': post['business_context']['industry'],
                        'pain_indicators': post['business_context']['pain_indicators'],
                        'engagement_score': post['score'] + post['num_comments'],
                        'discovered_at': datetime.now().isoformat(),
                        'reddit_metrics': {
                            'score': post['score'],
                            'upvote_ratio': post.get('upvote_ratio', 0.5),
                            'num_comments': post['num_comments'],
                            'author': post['author'],
                            'created_utc': post['created_utc']
                        },
                        # Additional fields for frontend compatibility
                        'selftext': post['body'],
                        'business_potential': 'medium',
                        'score': min(10, max(1, (post['score'] + post['num_comments']) // 5)),
                        'num_comments': post['num_comments'],
                        'post_age_days': 1,
                        'pain_point_indicators': post['business_context']['pain_indicators'],
                        'retrieved_via': post.get('retrieved_via', 'reddit_api')
                    }
                    pain_points.append(pain_point)
                    
                    # Generate opportunity from pain point
                    opportunity = {
                        'title': f"SaaS Solution for: {post['title'][:50]}...",
                        'score': min(10, max(1, (post['score'] + post['num_comments']) // 3)),
                        'domain': post['business_context']['industry'],
                        'business_potential': 'medium',
                        'subreddit': subreddit,
                        'pain_point_indicators': post['business_context']['pain_indicators'],
                        'source_post': post['title'],
                        'reddit_metrics': {
                            'score': post['score'],
                            'num_comments': post['num_comments'],
                            'upvote_ratio': post.get('upvote_ratio', 0.5)
                        }
                    }
                    ranked_opportunities.append(opportunity)
                    
                    # Generate SaaS concept from pain point
                    concept = {
                        'saas_concept': {
                            'name': f"{post['business_context']['industry'].title()} Assistant",
                            'description': f"AI-powered solution to address {post['business_context']['industry']} challenges mentioned in Reddit discussions",
                            'key_features': [
                                f"Automated {post['business_context']['industry']} workflow management",
                                "Real-time problem detection and alerts",
                                "Community-driven solution recommendations",
                                "Integration with existing tools"
                            ]
                        },
                        'source_opportunity': {
                            'score': min(10, max(1, (post['score'] + post['num_comments']) // 4)),
                            'title': post['title']
                        },
                        'data': {
                            'subreddit': subreddit,
                            'source_post': post['title'],
                            'industry': post['business_context']['industry'],
                            'retrieved_via': post.get('retrieved_via', 'reddit_api')
                        }
                    }
                    generated_concepts.append(concept)
            
            # Sort by engagement/score
            ranked_opportunities.sort(key=lambda x: x['score'], reverse=True)
            generated_concepts.sort(key=lambda x: x['source_opportunity']['score'], reverse=True)
            
            # Limit results
            ranked_opportunities = ranked_opportunities[:5]
            generated_concepts = generated_concepts[:3]
            
            # Save to database
            self._save_discovery_session(subreddit, len(posts), len(pain_points), pain_points)
            
            result = {
                'subreddit': subreddit,
                'posts_analyzed': len(posts),
                'pain_points_found': len(pain_points),
                'pain_points': pain_points,
                'ranked_opportunities': ranked_opportunities,
                'generated_concepts': generated_concepts,
                'timestamp': datetime.now().isoformat(),
                'reddit_api_status': self.reddit_client.get_rate_limit_status(),
                'api_integration': 'reddit_oauth2_with_fallback'
            }
            
            logger.info(f"Discovery completed: {len(pain_points)} pain points found from {len(posts)} posts")
            return result
            
        except Exception as e:
            logger.error(f"Error in pain point discovery: {e}")
            return {
                'subreddit': subreddit,
                'posts_analyzed': 0,
                'pain_points_found': 0,
                'pain_points': [],
                'ranked_opportunities': [],
                'generated_concepts': [],
                'error': str(e),
                'reddit_api_status': self.reddit_client.get_rate_limit_status()
            }
    
    def _save_discovery_session(self, subreddit: str, posts_analyzed: int, pain_points_found: int, pain_points: List[Dict]):
        """Save discovery session to database"""
        try:
            conn = db_service.get_connection()
            cursor = conn.cursor()
            
            session_data = {
                'pain_points': pain_points,
                'timestamp': datetime.now().isoformat()
            }
            
            cursor.execute("""
                INSERT INTO discovery_sessions (subreddit, posts_analyzed, pain_points_found, session_data)
                VALUES (?, ?, ?, ?)
            """, (subreddit, posts_analyzed, pain_points_found, json.dumps(session_data)))
            
            conn.commit()
            conn.close()
            
            logger.info(f"Saved discovery session: {subreddit} - {pain_points_found} pain points")
            
        except Exception as e:
            logger.error(f"Error saving discovery session: {e}")

# Global discovery service instance
discovery_service = DiscoveryService() 