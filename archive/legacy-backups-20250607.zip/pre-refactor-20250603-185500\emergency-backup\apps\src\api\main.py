#!/usr/bin/env python3
"""
SaaSpype API - SaaS Idea Discovery Engine
Reddit scraper + LLM analysis for finding SaaS opportunities
"""

from fastapi import FastAPI, HTTPException, Depends, status, Request
from fastapi.security import HTTPBearer, HTTPAuthorizationCredentials
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse
from pydantic import BaseModel
from typing import List, Optional, Dict, Any, Set
import sqlite3
import bcrypt
import jwt
from datetime import datetime, timedelta
import json
import os
import subprocess
import sys
import time
import psutil
import logging
from pathlib import Path

# Configure logging
log_dir = os.path.join(os.path.dirname(__file__), "..", "..", "..", "logs")
os.makedirs(log_dir, exist_ok=True)

logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler(os.path.join(log_dir, 'api.log')),
        logging.StreamHandler()
    ]
)
logger = logging.getLogger(__name__)

# Import the new quick scraper and LLM intelligence
from discovery_scraper import quick_discovery_scan
from llm_discovery_analysis import enhance_discovery_with_llm
from trend_detector import run_trend_analysis, TrendDetectionEngine, RealTimeMonitor

# Initialize FastAPI with production metadata
app = FastAPI(
    title="SaaSpype API",
    description="SaaS Idea Discovery Engine - Real-time Reddit analysis with LLM intelligence",
    version="2.0.0",
    docs_url="/docs",
    redoc_url="/redoc"
)

# Global metrics storage
app_metrics = {
    "start_time": time.time(),
    "requests_total": 0,
    "requests_by_endpoint": {},
    "errors_total": 0,
    "discovery_sessions": 0,
    "ideas_saved": 0,
    "trend_analyses": 0
}

# Add CORS middleware
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Request counting middleware
@app.middleware("http")
async def metrics_middleware(request: Request, call_next):
    start_time = time.time()
    
    # Increment request counter
    app_metrics["requests_total"] += 1
    endpoint = request.url.path
    app_metrics["requests_by_endpoint"][endpoint] = app_metrics["requests_by_endpoint"].get(endpoint, 0) + 1
    
    try:
        response = await call_next(request)
        
        # Log request
        process_time = time.time() - start_time
        logger.info(f"{request.method} {endpoint} - {response.status_code} - {process_time:.3f}s")
        
        return response
    except Exception as e:
        app_metrics["errors_total"] += 1
        logger.error(f"Request failed: {request.method} {endpoint} - {str(e)}")
        raise

# Security
security = HTTPBearer()
SECRET_KEY = "saaspype-discovery-secret-key-2025"
ALGORITHM = "HS256"
ACCESS_TOKEN_EXPIRE_MINUTES = 30

# Database setup
DATABASE = os.path.join(os.path.dirname(__file__), "..", "..", "..", "saaspype_discovery.db")

def init_db():
    """Initialize the database with discovery-focused tables"""
    conn = sqlite3.connect(DATABASE)
    cursor = conn.cursor()
    
    # Users table
    cursor.execute("""
        CREATE TABLE IF NOT EXISTS users (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            email TEXT UNIQUE NOT NULL,
            password_hash TEXT NOT NULL,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        )
    """)
    
    # Saved ideas table
    cursor.execute("""
        CREATE TABLE IF NOT EXISTS saved_ideas (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id INTEGER NOT NULL,
            idea_title TEXT NOT NULL,
            idea_description TEXT,
            pain_point_source TEXT,
            market_potential TEXT,
            concept_data TEXT,
            system_generated INTEGER DEFAULT 0,
            saved_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY (user_id) REFERENCES users (id)
        )
    """)
    
    # Discovery sessions table
    cursor.execute("""
        CREATE TABLE IF NOT EXISTS discovery_sessions (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id INTEGER,
            subreddit TEXT NOT NULL,
            posts_analyzed INTEGER DEFAULT 0,
            pain_points_found INTEGER DEFAULT 0,
            session_data TEXT,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY (user_id) REFERENCES users (id)
        )
    """)
    
    conn.commit()
    
    # Ensure system_generated column exists (for existing databases)
    try:
        cursor.execute('ALTER TABLE saved_ideas ADD COLUMN system_generated INTEGER DEFAULT 0')
        conn.commit()
        logger.info("Added system_generated column to existing database")
    except sqlite3.OperationalError as e:
        if "duplicate column name" not in str(e):
            logger.warning(f"Could not add system_generated column: {e}")
    
    conn.close()

# Startup and shutdown events
@app.on_event("startup")
async def startup_event():
    logger.info("🚀 SaaSpype API v2.0 starting up...")
    
    # Initialize database
    init_db()
    logger.info("✅ Database initialized")
    
    # Create logs directory
    os.makedirs("logs", exist_ok=True)
    logger.info("✅ Logs directory ready")
    
    # Verify trend detection components
    try:
        trend_engine = TrendDetectionEngine()
        logger.info("✅ Trend detection engine initialized")
    except Exception as e:
        logger.warning(f"⚠️ Trend detection engine warning: {e}")
    
    logger.info("🎯 SaaSpype API ready for discovery!")

@app.on_event("shutdown")
async def shutdown_event():
    logger.info("🛑 SaaSpype API shutting down...")
    logger.info("📊 Final metrics:")
    logger.info(f"   Total requests: {app_metrics['requests_total']}")
    logger.info(f"   Total errors: {app_metrics['errors_total']}")
    logger.info(f"   Discovery sessions: {app_metrics['discovery_sessions']}")
    logger.info(f"   Ideas saved: {app_metrics['ideas_saved']}")

# Initialize database on startup
init_db()

# Pydantic models
class UserCreate(BaseModel):
    email: str
    password: str

class UserLogin(BaseModel):
    email: str
    password: str

class DiscoveryRequest(BaseModel):
    subreddit: str
    limit: Optional[int] = 10

class SaveIdeaRequest(BaseModel):
    idea_title: str
    idea_description: str
    pain_point_source: str
    market_potential: str
    concept_data: Optional[Dict] = None

class Token(BaseModel):
    access_token: str
    token_type: str

class TrendRequest(BaseModel):
    limit_sessions: Optional[int] = 50
    include_predictions: Optional[bool] = True
    include_alerts: Optional[bool] = True

# Helper functions
def create_access_token(data: dict, expires_delta: Optional[timedelta] = None):
    to_encode = data.copy()
    if expires_delta:
        expire = datetime.utcnow() + expires_delta
    else:
        expire = datetime.utcnow() + timedelta(minutes=15)
    to_encode.update({"exp": expire})
    encoded_jwt = jwt.encode(to_encode, SECRET_KEY, algorithm=ALGORITHM)
    return encoded_jwt

def load_processed_posts() -> Set[str]:
    """Load processed post IDs for deduplication"""
    processed_file = Path("saaspype/memory/processed-posts.json")
    
    if not processed_file.exists():
        return set()
    
    try:
        with open(processed_file, 'r', encoding='utf-8') as f:
            data = json.load(f)
            return set(data.get('processed_post_ids', []))
    except Exception as e:
        print(f"Warning: Could not load processed posts: {e}")
        return set()

def save_processed_posts(processed_posts: Set[str]):
    """Save updated processed post IDs"""
    processed_file = Path("saaspype/memory/processed-posts.json")
    
    try:
        data = {
            "last_updated": datetime.now().isoformat(),
            "total_processed": len(processed_posts),
            "processed_post_ids": list(processed_posts)
        }
        
        with open(processed_file, 'w', encoding='utf-8') as f:
            json.dump(data, f, indent=2)
    except Exception as e:
        print(f"Warning: Could not save processed posts: {e}")

def verify_token(credentials: HTTPAuthorizationCredentials = Depends(security)):
    try:
        payload = jwt.decode(credentials.credentials, SECRET_KEY, algorithms=[ALGORITHM])
        email: str = payload.get("sub")
        if email is None:
            raise HTTPException(status_code=401, detail="Invalid token")
        return email
    except jwt.PyJWTError:
        raise HTTPException(status_code=401, detail="Invalid token")

def get_current_user(email: str = Depends(verify_token)):
    conn = sqlite3.connect(DATABASE)
    cursor = conn.cursor()
    cursor.execute("SELECT id, email FROM users WHERE email = ?", (email,))
    user = cursor.fetchone()
    conn.close()
    
    if user is None:
        raise HTTPException(status_code=404, detail="User not found")
    
    return {"id": user[0], "email": user[1]}

# API Routes

@app.get("/")
async def root():
    return {"message": "SaaSpype Discovery API", "version": "2.0", "purpose": "SaaS Idea Discovery Engine"}

@app.get("/health")
async def health_check():
    """Health check endpoint for monitoring"""
    try:
        # Check database connectivity
        conn = sqlite3.connect(DATABASE)
        cursor = conn.cursor()
        cursor.execute("SELECT 1")
        cursor.fetchone()
        conn.close()
        db_status = "healthy"
    except Exception as e:
        logger.error(f"Database health check failed: {e}")
        db_status = "unhealthy"
    
    # Check system resources
    memory_usage = psutil.virtual_memory().percent
    disk_usage = psutil.disk_usage('.').percent
    
    # Calculate uptime
    uptime_seconds = time.time() - app_metrics["start_time"]
    uptime_hours = uptime_seconds / 3600
    
    health_status = {
        "status": "healthy" if db_status == "healthy" and memory_usage < 90 and disk_usage < 90 else "degraded",
        "timestamp": datetime.utcnow().isoformat(),
        "uptime_hours": round(uptime_hours, 2),
        "version": "2.0.0",
        "components": {
            "database": db_status,
            "memory_usage_percent": memory_usage,
            "disk_usage_percent": disk_usage
        },
        "metrics": {
            "total_requests": app_metrics["requests_total"],
            "total_errors": app_metrics["errors_total"],
            "discovery_sessions": app_metrics["discovery_sessions"],
            "ideas_saved": app_metrics["ideas_saved"]
        }
    }
    
    status_code = 200 if health_status["status"] == "healthy" else 503
    return JSONResponse(content=health_status, status_code=status_code)

@app.get("/metrics")
async def get_metrics():
    """Detailed metrics endpoint for monitoring and analytics"""
    uptime_seconds = time.time() - app_metrics["start_time"]
    
    # Get system metrics
    cpu_percent = psutil.cpu_percent(interval=1)
    memory = psutil.virtual_memory()
    disk = psutil.disk_usage('.')
    
    # Calculate request rate
    requests_per_hour = app_metrics["requests_total"] / (uptime_seconds / 3600) if uptime_seconds > 0 else 0
    error_rate = (app_metrics["errors_total"] / app_metrics["requests_total"] * 100) if app_metrics["requests_total"] > 0 else 0
    
    # Get database stats
    try:
        conn = sqlite3.connect(DATABASE)
        cursor = conn.cursor()
        
        cursor.execute("SELECT COUNT(*) FROM users")
        total_users = cursor.fetchone()[0]
        
        cursor.execute("SELECT COUNT(*) FROM saved_ideas")
        total_ideas = cursor.fetchone()[0]
        
        cursor.execute("SELECT COUNT(*) FROM discovery_sessions")
        total_sessions = cursor.fetchone()[0]
        
        conn.close()
    except Exception as e:
        logger.error(f"Failed to get database stats: {e}")
        total_users = total_ideas = total_sessions = 0
    
    return {
        "timestamp": datetime.utcnow().isoformat(),
        "uptime": {
            "seconds": round(uptime_seconds, 2),
            "hours": round(uptime_seconds / 3600, 2),
            "days": round(uptime_seconds / 86400, 2)
        },
        "system": {
            "cpu_percent": cpu_percent,
            "memory": {
                "total_gb": round(memory.total / (1024**3), 2),
                "available_gb": round(memory.available / (1024**3), 2),
                "used_percent": memory.percent
            },
            "disk": {
                "total_gb": round(disk.total / (1024**3), 2),
                "free_gb": round(disk.free / (1024**3), 2),
                "used_percent": round(disk.used / disk.total * 100, 2)
            }
        },
        "api": {
            "total_requests": app_metrics["requests_total"],
            "requests_per_hour": round(requests_per_hour, 2),
            "total_errors": app_metrics["errors_total"],
            "error_rate_percent": round(error_rate, 2),
            "requests_by_endpoint": app_metrics["requests_by_endpoint"]
        },
        "business": {
            "total_users": total_users,
            "total_ideas_saved": total_ideas,
            "discovery_sessions": total_sessions,
            "discovery_sessions_today": app_metrics["discovery_sessions"],
            "ideas_saved_today": app_metrics["ideas_saved"],
            "trend_analyses": app_metrics["trend_analyses"]
        }
    }

@app.get("/status")
async def get_status():
    """Simple status endpoint for quick checks"""
    return {
        "status": "operational",
        "timestamp": datetime.utcnow().isoformat(),
        "version": "2.0.0",
        "uptime_hours": round((time.time() - app_metrics["start_time"]) / 3600, 2)
    }

@app.post("/api/signup", response_model=Token)
async def signup(user: UserCreate):
    conn = sqlite3.connect(DATABASE)
    cursor = conn.cursor()
    
    # Check if user exists
    cursor.execute("SELECT id FROM users WHERE email = ?", (user.email,))
    if cursor.fetchone():
        conn.close()
        raise HTTPException(status_code=400, detail="Email already registered")
    
    # Hash password
    password_hash = bcrypt.hashpw(user.password.encode('utf-8'), bcrypt.gensalt())
    
    # Create user
    cursor.execute(
        "INSERT INTO users (email, password_hash) VALUES (?, ?)",
        (user.email, password_hash)
    )
    conn.commit()
    conn.close()
    
    # Create token
    access_token_expires = timedelta(minutes=ACCESS_TOKEN_EXPIRE_MINUTES)
    access_token = create_access_token(
        data={"sub": user.email}, expires_delta=access_token_expires
    )
    
    return {"access_token": access_token, "token_type": "bearer"}

@app.post("/api/login", response_model=Token)
async def login(user: UserLogin):
    conn = sqlite3.connect(DATABASE)
    cursor = conn.cursor()
    
    cursor.execute("SELECT password_hash FROM users WHERE email = ?", (user.email,))
    result = cursor.fetchone()
    conn.close()
    
    if not result or not bcrypt.checkpw(user.password.encode('utf-8'), result[0]):
        raise HTTPException(status_code=401, detail="Invalid credentials")
    
    access_token_expires = timedelta(minutes=ACCESS_TOKEN_EXPIRE_MINUTES)
    access_token = create_access_token(
        data={"sub": user.email}, expires_delta=access_token_expires
    )
    
    return {"access_token": access_token, "token_type": "bearer"}

@app.get("/api/me")
async def get_current_user_info(current_user: dict = Depends(get_current_user)):
    return current_user

@app.get("/api/system-ideas")
async def get_system_ideas():
    """Get top system-generated ideas for display with enhanced confidence scoring"""
    print(f"DEBUG: System ideas endpoint called!")
    print(f"DEBUG: Current working directory: {os.getcwd()}")
    print(f"DEBUG: Database path: {DATABASE}")
    print(f"DEBUG: Database exists: {os.path.exists(DATABASE)}")
    
    conn = sqlite3.connect(DATABASE)
    cursor = conn.cursor()
    
    try:
        cursor.execute("""
            SELECT idea_title, idea_description, pain_point_source, market_potential, concept_data, saved_at
            FROM saved_ideas 
            WHERE system_generated = 1 
            ORDER BY saved_at DESC
            LIMIT 5
        """)
        
        ideas = []
        
        # Import the enhanced opportunity ranker for confidence scoring
        project_root = Path(__file__).parent.parent.parent.parent
        sys.path.append(str(project_root / "saaspype" / "src"))
        
        try:
            from agents.opportunity_ranker import OpportunityRankerAgent
            ranker = OpportunityRankerAgent()
        except ImportError:
            print("DEBUG: Could not import enhanced ranker, using basic scoring")
            ranker = None
        
        for row in cursor.fetchall():
            concept_data = None
            if row[4]:
                try:
                    concept_data = json.loads(row[4])
                except Exception as e:
                    print(f"DEBUG: JSON parse error: {e}")
                    pass
            
            # Create enhanced idea object with confidence scoring
            idea = {
                "idea_title": row[0],
                "idea_description": row[1],
                "pain_point_source": row[2],
                "market_potential": row[3],
                "concept_data": concept_data,
                "saved_at": row[5]
            }
            
            # Add enhanced confidence scoring if ranker is available
            if ranker and concept_data:
                try:
                    # Create a mock pain point for scoring
                    mock_pain_point = {
                        "title": row[0],
                        "selftext": row[1],
                        "score": concept_data.get("reddit_data", {}).get("score", 50),
                        "num_comments": concept_data.get("reddit_data", {}).get("num_comments", 10),
                        "pain_point_indicators": concept_data.get("pain_point_indicators", []),
                        "business_potential": row[3]
                    }
                    
                    # Calculate enhanced scoring
                    scoring_result = ranker.score_opportunity(mock_pain_point)
                    confidence = ranker.calculate_opportunity_confidence(mock_pain_point)
                    
                    # Add enhanced metrics to the idea
                    idea["confidence_score"] = round(confidence, 2)
                    idea["enhanced_score"] = scoring_result["total_score"]
                    idea["scoring_breakdown"] = {
                        "urgency": scoring_result["urgency"],
                        "frequency": scoring_result["frequency"],
                        "market_size": scoring_result["market_size"],
                        "solution_gap": scoring_result["solution_gap"],
                        "monetization": scoring_result["monetization"],
                        "base_score": scoring_result["base_score"],
                        "confidence": scoring_result["confidence"],
                        "domain": scoring_result["domain"]
                    }
                    
                except Exception as e:
                    print(f"DEBUG: Error calculating enhanced scoring: {e}")
                    # Fallback to basic confidence estimation
                    idea["confidence_score"] = 0.5
                    idea["enhanced_score"] = concept_data.get("score", 5)
                    idea["scoring_breakdown"] = None
            else:
                # Fallback for basic scoring
                idea["confidence_score"] = 0.5
                idea["enhanced_score"] = concept_data.get("score", 5) if concept_data else 5
                idea["scoring_breakdown"] = None
            
            ideas.append(idea)
        
        conn.close()
        print(f"DEBUG: Successfully found {len(ideas)} ideas with enhanced scoring")
        
        return {"system_ideas": ideas, "total": len(ideas)}
        
    except Exception as e:
        print(f"DEBUG: Database error: {e}")
        import traceback
        traceback.print_exc()
        conn.close()
        raise

@app.post("/api/discover")
async def discover_opportunities(
    request: DiscoveryRequest,
    current_user: dict = Depends(get_current_user)
):
    """Run Reddit scraper to discover SaaS opportunities with LLM intelligence and deduplication"""
    try:
        print(f"🔍 DISCOVERY: Using Enhanced Reddit Scraper + LLM Intelligence for subreddit: {request.subreddit}")
        
        # Load processed posts for deduplication
        processed_posts = load_processed_posts()
        initial_processed_count = len(processed_posts)
        
        # Use the enhanced scraper with Phase 1B improvements
        scraper_result = quick_discovery_scan(request.subreddit, request.limit)
        
        if not scraper_result.get('success', False):
            raise HTTPException(status_code=500, detail=f"Enhanced scraper failed: {scraper_result.get('error', 'Unknown error')}")
        
        # Get discovered posts
        discovered_posts = scraper_result.get('pain_points', [])
        
        # Filter out already processed posts for deduplication
        new_pain_points = []
        for post in discovered_posts:
            post_id = post.get('post_id')
            if post_id and post_id not in processed_posts:
                new_pain_points.append(post)
                processed_posts.add(post_id)
            else:
                print(f"🔄 DEDUP: Skipping already processed post {post_id}")
        
        # Update processed posts file
        save_processed_posts(processed_posts)
        
        print(f"📊 DISCOVERY: Found {len(new_pain_points)} new posts after deduplication")
        
        # Phase 2: Enhance posts with LLM Intelligence
        print(f"🧠 LLM INTELLIGENCE: Analyzing {len(new_pain_points)} posts with advanced semantic analysis...")
        llm_enhanced_posts = []
        
        for post in new_pain_points:
            try:
                # Apply LLM intelligence enhancements
                enhanced_post = enhance_discovery_with_llm(post)
                llm_enhanced_posts.append(enhanced_post)
                print(f"✅ LLM: Enhanced post '{post.get('title', '')[:50]}...' with confidence {enhanced_post.get('phase_2_enhancements', {}).get('confidence_score', 0)}")
            except Exception as e:
                print(f"⚠️ LLM: Failed to enhance post '{post.get('title', '')[:30]}...': {e}")
                # Use original post if LLM enhancement fails
                llm_enhanced_posts.append(post)
        
        # Create enhanced ranked opportunities from LLM-analyzed posts
        enhanced_opportunities = []
        for post in llm_enhanced_posts[:10]:  # Top 10 posts
            # Get LLM enhancements
            phase2_data = post.get('phase_2_enhancements', {})
            llm_analysis = post.get('llm_analysis', {})
            confidence_validation = post.get('confidence_validation', {})
            
            # Calculate enhanced opportunity score using LLM data
            engagement_score = post.get('score', 0) + post.get('num_comments', 0)
            pain_indicators = len(post.get('pain_point_indicators', []))
            llm_viability = phase2_data.get('viability_score', 0.5)
            llm_confidence = phase2_data.get('confidence_score', 0.5)
            
            # Composite opportunity score
            opportunity_score = (
                (engagement_score * 0.2) +
                (pain_indicators * 0.2) +
                (llm_viability * 0.3) +
                (llm_confidence * 0.3)
            )
            
            opportunity = {
                'title': post.get('title', ''),
                'description': post.get('body', '')[:300] + '...' if len(post.get('body', '')) > 300 else post.get('body', ''),
                'source_url': post.get('url', ''),
                'subreddit': post.get('subreddit', ''),
                'engagement_score': engagement_score,
                'pain_indicators': pain_indicators,
                'opportunity_score': round(opportunity_score, 2),
                'business_context': post.get('business_context', {}),
                'opportunity_type': 'llm_enhanced_discovery',
                
                # Phase 2 LLM Intelligence Data
                'llm_summary': phase2_data.get('llm_summary', ''),
                'confidence_score': llm_confidence,
                'viability_score': llm_viability,
                'business_category': phase2_data.get('business_category', 'other'),
                'target_customer': phase2_data.get('target_customer', ''),
                'solution_summary': phase2_data.get('solution_summary', ''),
                'key_insights': phase2_data.get('key_insights', ''),
                'confidence_level': phase2_data.get('confidence_level', 'medium'),
                
                # Detailed LLM Analysis
                'problem_severity': llm_analysis.get('problem_severity', 5),
                'solution_viability': llm_analysis.get('solution_viability', 5),
                'market_potential': llm_analysis.get('market_potential', 5),
                'revenue_potential': llm_analysis.get('revenue_potential', 5),
                'competitive_advantage': llm_analysis.get('competitive_advantage', 5),
                'confidence_indicators': llm_analysis.get('confidence_indicators', []),
                'risk_factors': llm_analysis.get('risk_factors', []),
                
                # Validation Results
                'validation_summary': confidence_validation.get('validation_summary', ''),
                'validation_scores': confidence_validation.get('validation_scores', {}),
                
                # Enhanced Metadata
                'analysis_timestamp': llm_analysis.get('analysis_timestamp', ''),
                'llm_version': llm_analysis.get('llm_version', 'unknown'),
                'enhancement_level': 'phase_2_llm_intelligence'
            }
            enhanced_opportunities.append(opportunity)
        
        # Sort by composite opportunity score (LLM-enhanced)
        enhanced_opportunities.sort(key=lambda x: x['opportunity_score'], reverse=True)
        
        # Generate enhanced concepts from top LLM-analyzed opportunities
        generated_concepts = []
        for opp in enhanced_opportunities[:5]:  # Top 5 opportunities
            concept = {
                'concept_title': f"{opp['business_category'].replace('_', ' ').title()} Solution: {opp['title'][:50]}...",
                'concept_description': opp['solution_summary'],
                'target_market': opp['target_customer'],
                'business_category': opp['business_category'],
                'revenue_model': 'subscription' if opp['revenue_potential'] >= 6 else 'one-time',
                'confidence': opp['confidence_score'],
                'viability': opp['viability_score'],
                'market_potential_score': opp['market_potential'],
                'problem_severity_score': opp['problem_severity'],
                'key_insights': opp['key_insights'],
                'risk_factors': opp['risk_factors'],
                'llm_summary': opp['llm_summary']
            }
            generated_concepts.append(concept)
        
        # Save enhanced discovery session
        conn = sqlite3.connect(DATABASE)
        cursor = conn.cursor()
        
        session_data = {
            "subreddit": request.subreddit,
            "pain_points": llm_enhanced_posts[:request.limit],
            "ranked_opportunities": enhanced_opportunities,
            "generated_concepts": generated_concepts,
            "scraper_type": "enhanced_reddit_scraper_v2.1_with_llm",
            "enhancement_level": "phase_2_llm_intelligence",
            "llm_analysis_stats": {
                "posts_analyzed": len(llm_enhanced_posts),
                "average_confidence": sum(p.get('phase_2_enhancements', {}).get('confidence_score', 0) for p in llm_enhanced_posts) / max(len(llm_enhanced_posts), 1),
                "average_viability": sum(p.get('phase_2_enhancements', {}).get('viability_score', 0) for p in llm_enhanced_posts) / max(len(llm_enhanced_posts), 1),
                "business_categories": list(set(p.get('phase_2_enhancements', {}).get('business_category', 'other') for p in llm_enhanced_posts))
            },
            "deduplication_stats": {
                "initial_processed": initial_processed_count,
                "final_processed": len(processed_posts),
                "new_posts_found": len(new_pain_points),
                "duplicates_skipped": len(discovered_posts) - len(new_pain_points)
            },
            "quality_metrics": scraper_result.get('quality_metrics', {}),
            "performance_stats": scraper_result.get('performance_stats', {})
        }
        
        cursor.execute("""
            INSERT INTO discovery_sessions (user_id, subreddit, posts_analyzed, pain_points_found, session_data)
            VALUES (?, ?, ?, ?, ?)
        """, (
            current_user['id'],
            request.subreddit,
            len(llm_enhanced_posts),
            len([p for p in llm_enhanced_posts if p.get('pain_point_indicators')]),
            json.dumps(session_data)
        ))
        
        conn.commit()
        conn.close()
        
        # Increment metrics counter
        app_metrics["discovery_sessions"] += 1
        
        print(f"✅ DISCOVERY: Enhanced session complete - {len(enhanced_opportunities)} LLM-analyzed opportunities found")
        
        return {
            "success": True,
            "subreddit": request.subreddit,
            "posts_analyzed": len(llm_enhanced_posts),
            "pain_points_found": len([p for p in llm_enhanced_posts if p.get('pain_point_indicators')]),
            "pain_points": llm_enhanced_posts[:request.limit],
            "ranked_opportunities": enhanced_opportunities,
            "generated_concepts": generated_concepts,
            "scraper_type": "enhanced_reddit_scraper_v2.1_with_llm",
            "enhancement_level": "phase_2_llm_intelligence",
            "llm_analysis_stats": session_data["llm_analysis_stats"],
            "deduplication_stats": session_data["deduplication_stats"],
            "quality_metrics": session_data["quality_metrics"],
            "performance_stats": session_data["performance_stats"],
            "timestamp": datetime.now().isoformat()
        }
        
    except Exception as e:
        print(f"❌ DISCOVERY ERROR: {str(e)}")
        raise HTTPException(status_code=500, detail=f"Enhanced discovery failed: {str(e)}")

@app.post("/api/save-idea")
async def save_idea(
    request: SaveIdeaRequest,
    current_user: dict = Depends(get_current_user)
):
    """Save a SaaS idea to user's idea bank"""
    conn = sqlite3.connect(DATABASE)
    cursor = conn.cursor()
    
    cursor.execute("""
        INSERT INTO saved_ideas (user_id, idea_title, idea_description, pain_point_source, market_potential, concept_data)
        VALUES (?, ?, ?, ?, ?, ?)
    """, (
        current_user['id'],
        request.idea_title,
        request.idea_description,
        request.pain_point_source,
        request.market_potential,
        json.dumps(request.concept_data) if request.concept_data else None
    ))
    
    conn.commit()
    idea_id = cursor.lastrowid
    conn.close()
    
    # Increment metrics counter
    app_metrics["ideas_saved"] += 1
    
    return {"success": True, "idea_id": idea_id, "message": "Idea saved to your idea bank"}

@app.get("/api/my-ideas")
async def get_my_ideas(current_user: dict = Depends(get_current_user)):
    """Get user's saved ideas"""
    conn = sqlite3.connect(DATABASE)
    cursor = conn.cursor()
    
    cursor.execute("""
        SELECT id, idea_title, idea_description, pain_point_source, market_potential, concept_data, saved_at
        FROM saved_ideas 
        WHERE user_id = ? 
        ORDER BY saved_at DESC
    """, (current_user['id'],))
    
    ideas = []
    for row in cursor.fetchall():
        concept_data = None
        if row[5]:
            try:
                concept_data = json.loads(row[5])
            except:
                pass
        
        ideas.append({
            "id": row[0],
            "idea_title": row[1],
            "idea_description": row[2],
            "pain_point_source": row[3],
            "market_potential": row[4],
            "concept_data": concept_data,
            "saved_at": row[6]
        })
    
    conn.close()
    
    return {"ideas": ideas, "total": len(ideas)}

@app.delete("/api/ideas/{idea_id}")
async def delete_idea(idea_id: int, current_user: dict = Depends(get_current_user)):
    """Delete a saved idea"""
    conn = sqlite3.connect(DATABASE)
    cursor = conn.cursor()
    
    cursor.execute("DELETE FROM saved_ideas WHERE id = ? AND user_id = ?", (idea_id, current_user['id']))
    
    if cursor.rowcount == 0:
        conn.close()
        raise HTTPException(status_code=404, detail="Idea not found")
    
    conn.commit()
    conn.close()
    
    return {"success": True, "message": "Idea deleted"}

@app.get("/api/discovery-history")
async def get_discovery_history(current_user: dict = Depends(get_current_user)):
    """Get user's discovery session history"""
    conn = sqlite3.connect(DATABASE)
    cursor = conn.cursor()
    
    cursor.execute("""
        SELECT id, subreddit, posts_analyzed, pain_points_found, created_at
        FROM discovery_sessions 
        WHERE user_id = ? 
        ORDER BY created_at DESC
        LIMIT 10
    """, (current_user['id'],))
    
    sessions = []
    for row in cursor.fetchall():
        sessions.append({
            "id": row[0],
            "subreddit": row[1],
            "posts_analyzed": row[2],
            "pain_points_found": row[3],
            "created_at": row[4]
        })
    
    conn.close()
    
    return {"sessions": sessions}

@app.get("/api/trends")
async def get_trend_analysis(
    limit_sessions: Optional[int] = 50,
    include_predictions: Optional[bool] = True,
    include_alerts: Optional[bool] = True,
    current_user: dict = Depends(get_current_user)
):
    """Get comprehensive trend analysis and signal detection from recent discovery sessions"""
    try:
        print(f"🔍 TRENDS: Running trend analysis for {limit_sessions} sessions")
        
        # Run comprehensive trend analysis
        trend_report = run_trend_analysis(limit_sessions)
        
        if not trend_report or trend_report.get('status') == 'fallback_analysis':
            raise HTTPException(status_code=500, detail="Trend analysis failed - insufficient data")
        
        # Filter response based on parameters
        response_data = {
            'success': True,
            'analysis_timestamp': trend_report.get('analysis_timestamp'),
            'analysis_duration': trend_report.get('analysis_duration'),
            'data_points_analyzed': trend_report.get('data_points_analyzed'),
            'trend_window_hours': trend_report.get('trend_window_hours'),
            
            # Core trend data
            'trending_keywords': trend_report.get('trending_keywords', []),
            'emerging_categories': trend_report.get('emerging_categories', []),
            'high_signal_opportunities': trend_report.get('high_signal_opportunities', []),
            'market_insights': trend_report.get('market_insights', []),
            
            # Anomaly detection
            'anomaly_detection': trend_report.get('anomaly_detection', {}),
            
            # Performance stats
            'trend_detection_stats': trend_report.get('trend_detection_stats', {}),
            'monitoring_status': trend_report.get('monitoring_status', {}),
            
            # Enhancement level
            'enhancement_level': 'phase_3_live_trend_detection'
        }
        
        # Include predictions if requested
        if include_predictions:
            response_data['predictions'] = trend_report.get('predictions', {})
        
        # Include alerts if requested
        if include_alerts:
            response_data['alerts'] = trend_report.get('alerts', [])
            response_data['alert_count'] = trend_report.get('alert_count', 0)
        
        print(f"✅ TRENDS: Analysis complete - {response_data['data_points_analyzed']} sessions, {len(response_data['trending_keywords'])} trending keywords")
        
        # Increment metrics counter
        app_metrics["trend_analyses"] += 1
        
        return response_data
        
    except Exception as e:
        print(f"❌ TRENDS ERROR: {str(e)}")
        raise HTTPException(status_code=500, detail=f"Trend analysis failed: {str(e)}")

@app.get("/api/trends/keywords")
async def get_trending_keywords(
    limit: Optional[int] = 10,
    current_user: dict = Depends(get_current_user)
):
    """Get top trending keywords with velocity analysis"""
    try:
        trend_report = run_trend_analysis(limit_sessions=30)
        trending_keywords = trend_report.get('trending_keywords', [])
        
        return {
            'success': True,
            'trending_keywords': trending_keywords[:limit],
            'total_keywords': len(trending_keywords),
            'analysis_timestamp': trend_report.get('analysis_timestamp'),
            'trend_window_hours': trend_report.get('trend_window_hours', 24)
        }
        
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Keyword trend analysis failed: {str(e)}")

@app.get("/api/trends/categories")
async def get_emerging_categories(
    limit: Optional[int] = 5,
    current_user: dict = Depends(get_current_user)
):
    """Get emerging business categories with growth analysis"""
    try:
        trend_report = run_trend_analysis(limit_sessions=30)
        emerging_categories = trend_report.get('emerging_categories', [])
        
        return {
            'success': True,
            'emerging_categories': emerging_categories[:limit],
            'total_categories': len(emerging_categories),
            'analysis_timestamp': trend_report.get('analysis_timestamp'),
            'trend_window_hours': trend_report.get('trend_window_hours', 24)
        }
        
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Category trend analysis failed: {str(e)}")

@app.get("/api/trends/signals")
async def get_high_signal_opportunities(
    limit: Optional[int] = 10,
    current_user: dict = Depends(get_current_user)
):
    """Get high signal strength opportunities with trend boost analysis"""
    try:
        trend_report = run_trend_analysis(limit_sessions=50)
        high_signals = trend_report.get('high_signal_opportunities', [])
        
        return {
            'success': True,
            'high_signal_opportunities': high_signals[:limit],
            'total_signals': len(high_signals),
            'analysis_timestamp': trend_report.get('analysis_timestamp'),
            'signal_threshold': 1.2,  # High signal threshold
            'enhancement_level': 'phase_3_signal_detection'
        }
        
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Signal analysis failed: {str(e)}")

@app.get("/api/trends/alerts")
async def get_trend_alerts(
    severity: Optional[str] = None,  # 'high', 'medium', 'low'
    current_user: dict = Depends(get_current_user)
):
    """Get real-time trend alerts and anomaly detection"""
    try:
        trend_report = run_trend_analysis(limit_sessions=30)
        alerts = trend_report.get('alerts', [])
        
        # Filter by severity if specified
        if severity:
            alerts = [alert for alert in alerts if alert.get('severity') == severity]
        
        return {
            'success': True,
            'alerts': alerts,
            'alert_count': len(alerts),
            'total_alerts': trend_report.get('alert_count', 0),
            'analysis_timestamp': trend_report.get('analysis_timestamp'),
            'monitoring_status': trend_report.get('monitoring_status', {}),
            'enhancement_level': 'phase_3_real_time_monitoring'
        }
        
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Alert analysis failed: {str(e)}")

@app.get("/api/trends/predictions")
async def get_trend_predictions(
    prediction_type: Optional[str] = None,  # 'keywords', 'categories', 'timing'
    current_user: dict = Depends(get_current_user)
):
    """Get predictive trend analysis and market timing insights"""
    try:
        trend_report = run_trend_analysis(limit_sessions=50)
        predictions = trend_report.get('predictions', {})
        
        if prediction_type:
            if prediction_type == 'keywords':
                filtered_predictions = {'trending_keywords_24h': predictions.get('trending_keywords_24h', [])}
            elif prediction_type == 'categories':
                filtered_predictions = {'emerging_categories': predictions.get('emerging_categories', [])}
            elif prediction_type == 'timing':
                filtered_predictions = {'market_timing_insights': predictions.get('market_timing_insights', [])}
            else:
                filtered_predictions = predictions
        else:
            filtered_predictions = predictions
        
        return {
            'success': True,
            'predictions': filtered_predictions,
            'prediction_confidence': predictions.get('prediction_confidence', 'medium'),
            'next_update_recommended': predictions.get('next_update_recommended'),
            'analysis_timestamp': trend_report.get('analysis_timestamp'),
            'enhancement_level': 'phase_3_predictive_analytics'
        }
        
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Prediction analysis failed: {str(e)}")

if __name__ == "__main__":
    import uvicorn
    print("🚀 Starting SaaSpype Discovery API...")
    print("📊 Reddit Scraper + LLM Analysis Engine")
    print("🔗 API: http://localhost:8000")
    print("📚 Docs: http://localhost:8000/docs")
    uvicorn.run(app, host="0.0.0.0", port=8000)
