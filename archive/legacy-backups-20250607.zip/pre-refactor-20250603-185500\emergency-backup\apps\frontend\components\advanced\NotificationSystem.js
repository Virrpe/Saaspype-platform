/**
 * SaaSpype V2 Advanced Notification System
 * Real-time notifications with priority levels, actions, and persistence
 */

class NotificationSystem {
  constructor(options = {}) {
    this.container = options.container || document.body;
    this.position = options.position || 'top-right'; // top-right, top-left, bottom-right, bottom-left
    this.maxNotifications = options.maxNotifications || 5;
    this.defaultDuration = options.defaultDuration || 5000;
    this.enableSound = options.enableSound || false;
    this.enablePersistence = options.enablePersistence || true;
    
    this.notifications = new Map();
    this.notificationQueue = [];
    this.isInitialized = false;
    
    this.init();
  }

  init() {
    if (this.isInitialized) return;
    
    // Create notification container
    this.notificationContainer = document.createElement('div');
    this.notificationContainer.className = this.getContainerClasses();
    this.notificationContainer.setAttribute('aria-live', 'polite');
    this.notificationContainer.setAttribute('aria-label', 'Notifications');
    this.container.appendChild(this.notificationContainer);
    
    // Load persisted notifications
    if (this.enablePersistence) {
      this.loadPersistedNotifications();
    }
    
    this.isInitialized = true;
  }

  getContainerClasses() {
    const baseClasses = 'fixed z-50 flex flex-col space-y-3 pointer-events-none';
    const positionClasses = {
      'top-right': 'top-4 right-4',
      'top-left': 'top-4 left-4',
      'bottom-right': 'bottom-4 right-4',
      'bottom-left': 'bottom-4 left-4'
    };
    
    return `${baseClasses} ${positionClasses[this.position]}`;
  }

  // Main notification creation method
  notify(options) {
    const notification = this.createNotification(options);
    this.addNotification(notification);
    return notification.id;
  }

  // Convenience methods for different notification types
  success(message, options = {}) {
    return this.notify({
      ...options,
      message,
      type: 'success',
      icon: options.icon || `
        <svg class="w-5 h-5" fill="currentColor" viewBox="0 0 20 20">
          <path fill-rule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zm3.707-9.293a1 1 0 00-1.414-1.414L9 10.586 7.707 9.293a1 1 0 00-1.414 1.414l2 2a1 1 0 001.414 0l4-4z" clip-rule="evenodd"/>
        </svg>
      `
    });
  }

  error(message, options = {}) {
    return this.notify({
      ...options,
      message,
      type: 'error',
      persistent: true,
      icon: options.icon || `
        <svg class="w-5 h-5" fill="currentColor" viewBox="0 0 20 20">
          <path fill-rule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zM8.707 7.293a1 1 0 00-1.414 1.414L8.586 10l-1.293 1.293a1 1 0 101.414 1.414L10 11.414l1.293 1.293a1 1 0 001.414-1.414L11.414 10l1.293-1.293a1 1 0 00-1.414-1.414L10 8.586 8.707 7.293z" clip-rule="evenodd"/>
        </svg>
      `
    });
  }

  warning(message, options = {}) {
    return this.notify({
      ...options,
      message,
      type: 'warning',
      icon: options.icon || `
        <svg class="w-5 h-5" fill="currentColor" viewBox="0 0 20 20">
          <path fill-rule="evenodd" d="M8.257 3.099c.765-1.36 2.722-1.36 3.486 0l5.58 9.92c.75 1.334-.213 2.98-1.742 2.98H4.42c-1.53 0-2.493-1.646-1.743-2.98l5.58-9.92zM11 13a1 1 0 11-2 0 1 1 0 012 0zm-1-8a1 1 0 00-1 1v3a1 1 0 002 0V6a1 1 0 00-1-1z" clip-rule="evenodd"/>
        </svg>
      `
    });
  }

  info(message, options = {}) {
    return this.notify({
      ...options,
      message,
      type: 'info',
      icon: options.icon || `
        <svg class="w-5 h-5" fill="currentColor" viewBox="0 0 20 20">
          <path fill-rule="evenodd" d="M18 10a8 8 0 11-16 0 8 8 0 0116 0zm-7-4a1 1 0 11-2 0 1 1 0 012 0zM9 9a1 1 0 000 2v3a1 1 0 001 1h1a1 1 0 100-2v-3a1 1 0 00-1-1H9z" clip-rule="evenodd"/>
        </svg>
      `
    });
  }

  // Real-time system notifications
  systemAlert(message, priority = 'medium', options = {}) {
    const priorityConfig = {
      low: { type: 'info', duration: 3000 },
      medium: { type: 'warning', duration: 5000 },
      high: { type: 'error', persistent: true, sound: true },
      critical: { type: 'error', persistent: true, sound: true, actions: [
        { label: 'Acknowledge', action: () => this.acknowledgeAlert(options.alertId) }
      ]}
    };

    return this.notify({
      ...options,
      ...priorityConfig[priority],
      message,
      title: options.title || 'System Alert',
      category: 'system'
    });
  }

  createNotification(options) {
    const id = options.id || this.generateId();
    const notification = {
      id,
      type: options.type || 'info',
      title: options.title,
      message: options.message,
      icon: options.icon,
      actions: options.actions || [],
      persistent: options.persistent || false,
      duration: options.duration || this.defaultDuration,
      category: options.category || 'general',
      timestamp: new Date(),
      dismissed: false,
      element: null
    };

    notification.element = this.renderNotification(notification);
    return notification;
  }

  renderNotification(notification) {
    const element = document.createElement('div');
    element.className = this.getNotificationClasses(notification);
    element.setAttribute('role', 'alert');
    element.setAttribute('aria-live', 'assertive');
    
    const typeColors = {
      success: 'bg-success-50 border-success-200 text-success-800',
      error: 'bg-error-50 border-error-200 text-error-800',
      warning: 'bg-warning-50 border-warning-200 text-warning-800',
      info: 'bg-primary-50 border-primary-200 text-primary-800'
    };

    const iconColors = {
      success: 'text-success-600',
      error: 'text-error-600',
      warning: 'text-warning-600',
      info: 'text-primary-600'
    };

    element.innerHTML = `
      <div class="flex items-start space-x-3">
        ${notification.icon ? `
          <div class="flex-shrink-0 ${iconColors[notification.type]}">
            ${notification.icon}
          </div>
        ` : ''}
        
        <div class="flex-1 min-w-0">
          ${notification.title ? `
            <h4 class="font-semibold text-sm mb-1">${notification.title}</h4>
          ` : ''}
          <p class="text-sm">${notification.message}</p>
          
          ${notification.actions.length > 0 ? `
            <div class="mt-3 flex space-x-2">
              ${notification.actions.map(action => `
                <button 
                  class="text-xs font-medium px-3 py-1 rounded-md bg-white border border-current hover:bg-gray-50 transition-colors"
                  onclick="window.notificationSystem.handleAction('${notification.id}', '${action.label}')"
                >
                  ${action.label}
                </button>
              `).join('')}
            </div>
          ` : ''}
        </div>
        
        <button 
          class="flex-shrink-0 text-gray-400 hover:text-gray-600 transition-colors"
          onclick="window.notificationSystem.dismiss('${notification.id}')"
          aria-label="Dismiss notification"
        >
          <svg class="w-4 h-4" fill="currentColor" viewBox="0 0 20 20">
            <path fill-rule="evenodd" d="M4.293 4.293a1 1 0 011.414 0L10 8.586l4.293-4.293a1 1 0 111.414 1.414L11.414 10l4.293 4.293a1 1 0 01-1.414 1.414L10 11.414l-4.293 4.293a1 1 0 01-1.414-1.414L8.586 10 4.293 5.707a1 1 0 010-1.414z" clip-rule="evenodd"/>
          </svg>
        </button>
      </div>
    `;

    // Store action handlers
    notification.actions.forEach(action => {
      element.setAttribute(`data-action-${action.label}`, action.action.toString());
    });

    return element;
  }

  getNotificationClasses(notification) {
    const baseClasses = 'pointer-events-auto max-w-sm w-full bg-white border rounded-lg shadow-lg p-4 transform transition-all duration-300 ease-in-out';
    const typeColors = {
      success: 'bg-success-50 border-success-200',
      error: 'bg-error-50 border-error-200',
      warning: 'bg-warning-50 border-warning-200',
      info: 'bg-primary-50 border-primary-200'
    };
    
    return `${baseClasses} ${typeColors[notification.type]}`;
  }

  addNotification(notification) {
    // Check if we're at max capacity
    if (this.notifications.size >= this.maxNotifications) {
      this.removeOldestNotification();
    }

    this.notifications.set(notification.id, notification);
    
    // Add to DOM with animation
    this.notificationContainer.appendChild(notification.element);
    
    // Trigger entrance animation
    requestAnimationFrame(() => {
      notification.element.style.transform = 'translateX(0) scale(1)';
      notification.element.style.opacity = '1';
    });

    // Set auto-dismiss timer if not persistent
    if (!notification.persistent) {
      setTimeout(() => {
        this.dismiss(notification.id);
      }, notification.duration);
    }

    // Play sound if enabled
    if (this.enableSound && (notification.type === 'error' || notification.type === 'warning')) {
      this.playNotificationSound(notification.type);
    }

    // Persist if enabled
    if (this.enablePersistence) {
      this.persistNotification(notification);
    }

    // Emit event
    this.emitEvent('notification:added', notification);
  }

  dismiss(notificationId) {
    const notification = this.notifications.get(notificationId);
    if (!notification || notification.dismissed) return;

    notification.dismissed = true;
    
    // Animate out
    notification.element.style.transform = 'translateX(100%) scale(0.95)';
    notification.element.style.opacity = '0';
    
    setTimeout(() => {
      if (notification.element.parentNode) {
        notification.element.parentNode.removeChild(notification.element);
      }
      this.notifications.delete(notificationId);
      
      if (this.enablePersistence) {
        this.removePersistedNotification(notificationId);
      }
      
      this.emitEvent('notification:dismissed', notification);
    }, 300);
  }

  dismissAll() {
    Array.from(this.notifications.keys()).forEach(id => {
      this.dismiss(id);
    });
  }

  handleAction(notificationId, actionLabel) {
    const notification = this.notifications.get(notificationId);
    if (!notification) return;

    const action = notification.actions.find(a => a.label === actionLabel);
    if (action && typeof action.action === 'function') {
      action.action(notification);
    }

    // Auto-dismiss after action unless persistent
    if (!notification.persistent) {
      this.dismiss(notificationId);
    }
  }

  // Real-time connection methods
  connectWebSocket(wsUrl) {
    this.ws = new WebSocket(wsUrl);
    
    this.ws.onmessage = (event) => {
      try {
        const data = JSON.parse(event.data);
        this.handleRealtimeNotification(data);
      } catch (error) {
        console.error('Failed to parse WebSocket message:', error);
      }
    };

    this.ws.onopen = () => {
      this.info('Connected to real-time notifications');
    };

    this.ws.onclose = () => {
      this.warning('Real-time notifications disconnected. Attempting to reconnect...');
      setTimeout(() => this.connectWebSocket(wsUrl), 5000);
    };
  }

  handleRealtimeNotification(data) {
    const { type, message, title, priority, category } = data;
    
    switch (category) {
      case 'system':
        this.systemAlert(message, priority, { title });
        break;
      case 'user_action':
        this.info(message, { title });
        break;
      case 'revenue':
        this.success(message, { title });
        break;
      case 'churn_risk':
        this.warning(message, { title, persistent: true });
        break;
      default:
        this.notify({ type, message, title });
    }
  }

  // Utility methods
  generateId() {
    return `notification_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
  }

  removeOldestNotification() {
    const oldestId = Array.from(this.notifications.keys())[0];
    if (oldestId) {
      this.dismiss(oldestId);
    }
  }

  playNotificationSound(type) {
    // Simple beep sound for different notification types
    const audioContext = new (window.AudioContext || window.webkitAudioContext)();
    const oscillator = audioContext.createOscillator();
    const gainNode = audioContext.createGain();
    
    oscillator.connect(gainNode);
    gainNode.connect(audioContext.destination);
    
    const frequencies = {
      success: 800,
      error: 400,
      warning: 600,
      info: 700
    };
    
    oscillator.frequency.setValueAtTime(frequencies[type], audioContext.currentTime);
    oscillator.type = 'sine';
    
    gainNode.gain.setValueAtTime(0.1, audioContext.currentTime);
    gainNode.gain.exponentialRampToValueAtTime(0.01, audioContext.currentTime + 0.3);
    
    oscillator.start(audioContext.currentTime);
    oscillator.stop(audioContext.currentTime + 0.3);
  }

  persistNotification(notification) {
    const persisted = JSON.parse(localStorage.getItem('saaspype_notifications') || '[]');
    persisted.push({
      id: notification.id,
      type: notification.type,
      title: notification.title,
      message: notification.message,
      timestamp: notification.timestamp,
      category: notification.category
    });
    
    // Keep only last 50 notifications
    if (persisted.length > 50) {
      persisted.splice(0, persisted.length - 50);
    }
    
    localStorage.setItem('saaspype_notifications', JSON.stringify(persisted));
  }

  loadPersistedNotifications() {
    const persisted = JSON.parse(localStorage.getItem('saaspype_notifications') || '[]');
    // Only show recent critical notifications on load
    const recent = persisted.filter(n => 
      Date.now() - new Date(n.timestamp).getTime() < 3600000 && // Last hour
      (n.type === 'error' || n.category === 'system')
    );
    
    recent.forEach(n => {
      this.notify({
        ...n,
        persistent: true,
        title: `${n.title} (Earlier)`
      });
    });
  }

  removePersistedNotification(notificationId) {
    const persisted = JSON.parse(localStorage.getItem('saaspype_notifications') || '[]');
    const filtered = persisted.filter(n => n.id !== notificationId);
    localStorage.setItem('saaspype_notifications', JSON.stringify(filtered));
  }

  emitEvent(eventName, data) {
    const event = new CustomEvent(eventName, { detail: data });
    window.dispatchEvent(event);
  }

  acknowledgeAlert(alertId) {
    // Mark system alert as acknowledged
    this.dismiss(alertId);
    // Could send acknowledgment to backend
    console.log(`Alert ${alertId} acknowledged`);
  }

  // Public API methods
  getNotificationHistory() {
    return JSON.parse(localStorage.getItem('saaspype_notifications') || '[]');
  }

  clearHistory() {
    localStorage.removeItem('saaspype_notifications');
  }

  updateSettings(settings) {
    Object.assign(this, settings);
  }
}

// Global instance
window.SaaSpypeNotificationSystem = NotificationSystem;

// Auto-initialize if container exists
if (typeof window !== 'undefined') {
  window.addEventListener('DOMContentLoaded', () => {
    if (!window.notificationSystem) {
      window.notificationSystem = new NotificationSystem();
    }
  });
}

// Export for module systems
if (typeof module !== 'undefined' && module.exports) {
  module.exports = NotificationSystem;
} 