/**
 * SaaSpype V2 Input Component
 * Foundation form input component with validation and accessibility
 */

class Input {
  constructor(options = {}) {
    this.type = options.type || 'text';
    this.label = options.label || '';
    this.placeholder = options.placeholder || '';
    this.value = options.value || '';
    this.required = options.required || false;
    this.disabled = options.disabled || false;
    this.error = options.error || '';
    this.helpText = options.helpText || '';
    this.size = options.size || 'md';
    this.icon = options.icon || null;
    this.iconPosition = options.iconPosition || 'left';
    this.onChange = options.onChange || (() => {});
    this.onBlur = options.onBlur || (() => {});
    this.onFocus = options.onFocus || (() => {});
    this.validation = options.validation || null;
    this.id = options.id || `input-${Math.random().toString(36).substr(2, 9)}`;
    this.element = null;
    this.inputElement = null;
  }

  getBaseInputClasses() {
    return [
      'block',
      'w-full',
      'border',
      'rounded-lg',
      'transition-all',
      'duration-200',
      'focus:outline-none',
      'focus:ring-2',
      'focus:ring-offset-1',
      'disabled:opacity-50',
      'disabled:cursor-not-allowed',
      'disabled:bg-gray-50'
    ];
  }

  getStateClasses() {
    if (this.error) {
      return [
        'border-error-500',
        'text-error-900',
        'placeholder-error-400',
        'focus:ring-error-500',
        'focus:border-error-500'
      ];
    }
    
    return [
      'border-gray-300',
      'text-gray-900',
      'placeholder-gray-400',
      'focus:ring-primary-500',
      'focus:border-primary-500'
    ];
  }

  getSizeClasses() {
    const sizes = {
      sm: ['px-3', 'py-2', 'text-sm'],
      md: ['px-4', 'py-3', 'text-base'],
      lg: ['px-5', 'py-4', 'text-lg']
    };
    return sizes[this.size] || sizes.md;
  }

  getIconClasses() {
    if (!this.icon) return [];
    
    const iconSizes = {
      sm: this.iconPosition === 'left' ? ['pl-10'] : ['pr-10'],
      md: this.iconPosition === 'left' ? ['pl-12'] : ['pr-12'],
      lg: this.iconPosition === 'left' ? ['pl-14'] : ['pr-14']
    };
    
    return iconSizes[this.size] || iconSizes.md;
  }

  renderLabel() {
    if (!this.label) return '';
    
    return `
      <label for="${this.id}" class="block text-sm font-medium text-gray-700 mb-2">
        ${this.label}
        ${this.required ? '<span class="text-error-500 ml-1">*</span>' : ''}
      </label>
    `;
  }

  renderIcon() {
    if (!this.icon) return '';
    
    const positionClasses = this.iconPosition === 'left' ? 'left-3' : 'right-3';
    const iconSizeClasses = {
      sm: 'w-4 h-4',
      md: 'w-5 h-5',
      lg: 'w-6 h-6'
    };
    
    return `
      <div class="absolute inset-y-0 ${positionClasses} flex items-center pointer-events-none">
        <span class="${iconSizeClasses[this.size]} text-gray-400">
          ${this.icon}
        </span>
      </div>
    `;
  }

  renderInput() {
    const allClasses = [
      ...this.getBaseInputClasses(),
      ...this.getStateClasses(),
      ...this.getSizeClasses(),
      ...this.getIconClasses()
    ];

    return `
      <input
        type="${this.type}"
        id="${this.id}"
        class="${allClasses.join(' ')}"
        placeholder="${this.placeholder}"
        value="${this.value}"
        ${this.required ? 'required' : ''}
        ${this.disabled ? 'disabled' : ''}
        aria-describedby="${this.error ? `${this.id}-error` : ''} ${this.helpText ? `${this.id}-help` : ''}"
        aria-invalid="${this.error ? 'true' : 'false'}"
      />
    `;
  }

  renderError() {
    if (!this.error) return '';
    
    return `
      <p id="${this.id}-error" class="mt-2 text-sm text-error-600 flex items-center">
        <svg class="w-4 h-4 mr-1" fill="currentColor" viewBox="0 0 20 20">
          <path fill-rule="evenodd" d="M18 10a8 8 0 11-16 0 8 8 0 0116 0zm-7 4a1 1 0 11-2 0 1 1 0 012 0zm-1-9a1 1 0 00-1 1v4a1 1 0 102 0V6a1 1 0 00-1-1z" clip-rule="evenodd"></path>
        </svg>
        ${this.error}
      </p>
    `;
  }

  renderHelpText() {
    if (!this.helpText || this.error) return '';
    
    return `
      <p id="${this.id}-help" class="mt-2 text-sm text-gray-500">
        ${this.helpText}
      </p>
    `;
  }

  validate() {
    if (!this.validation) return true;
    
    const value = this.inputElement ? this.inputElement.value : this.value;
    
    if (typeof this.validation === 'function') {
      const result = this.validation(value);
      if (typeof result === 'string') {
        this.setError(result);
        return false;
      } else if (result === false) {
        this.setError('Invalid input');
        return false;
      }
    } else if (this.validation instanceof RegExp) {
      if (!this.validation.test(value)) {
        this.setError('Invalid format');
        return false;
      }
    }
    
    this.clearError();
    return true;
  }

  render() {
    const containerClasses = ['relative'];
    
    const html = `
      <div class="${containerClasses.join(' ')}">
        ${this.renderLabel()}
        <div class="relative">
          ${this.renderInput()}
          ${this.renderIcon()}
        </div>
        ${this.renderError()}
        ${this.renderHelpText()}
      </div>
    `;

    this.element = document.createElement('div');
    this.element.innerHTML = html;
    
    // Get reference to the actual input element
    this.inputElement = this.element.querySelector('input');
    
    // Add event listeners
    this.inputElement.addEventListener('input', (e) => {
      this.value = e.target.value;
      this.onChange(e.target.value, e);
    });
    
    this.inputElement.addEventListener('blur', (e) => {
      this.validate();
      this.onBlur(e.target.value, e);
    });
    
    this.inputElement.addEventListener('focus', (e) => {
      this.onFocus(e.target.value, e);
    });

    return this.element;
  }

  // Public methods for dynamic updates
  setValue(value) {
    this.value = value;
    if (this.inputElement) {
      this.inputElement.value = value;
    }
  }

  getValue() {
    return this.inputElement ? this.inputElement.value : this.value;
  }

  setError(error) {
    this.error = error;
    if (this.element) {
      // Re-render error section
      const errorElement = this.element.querySelector(`#${this.id}-error`);
      const helpElement = this.element.querySelector(`#${this.id}-help`);
      
      if (errorElement) {
        errorElement.remove();
      }
      if (helpElement) {
        helpElement.remove();
      }
      
      const inputContainer = this.element.querySelector('.relative').parentNode;
      inputContainer.insertAdjacentHTML('beforeend', this.renderError());
      
      // Update input classes
      this.inputElement.className = [
        ...this.getBaseInputClasses(),
        ...this.getStateClasses(),
        ...this.getSizeClasses(),
        ...this.getIconClasses()
      ].join(' ');
    }
  }

  clearError() {
    this.setError('');
    if (this.element && this.helpText) {
      const inputContainer = this.element.querySelector('.relative').parentNode;
      inputContainer.insertAdjacentHTML('beforeend', this.renderHelpText());
    }
  }

  setDisabled(disabled) {
    this.disabled = disabled;
    if (this.inputElement) {
      this.inputElement.disabled = disabled;
    }
  }

  focus() {
    if (this.inputElement) {
      this.inputElement.focus();
    }
  }

  blur() {
    if (this.inputElement) {
      this.inputElement.blur();
    }
  }

  // Static factory methods for common input types
  static email(options = {}) {
    return new Input({
      ...options,
      type: 'email',
      validation: /^[^\s@]+@[^\s@]+\.[^\s@]+$/
    }).render();
  }

  static password(options = {}) {
    return new Input({
      ...options,
      type: 'password'
    }).render();
  }

  static number(options = {}) {
    return new Input({
      ...options,
      type: 'number'
    }).render();
  }

  static tel(options = {}) {
    return new Input({
      ...options,
      type: 'tel',
      validation: /^[\+]?[1-9][\d]{0,15}$/
    }).render();
  }
}

// Export for module usage
if (typeof module !== 'undefined' && module.exports) {
  module.exports = Input;
}

// Global registration for direct HTML usage
if (typeof window !== 'undefined') {
  window.SaaSpypeInput = Input;
} 