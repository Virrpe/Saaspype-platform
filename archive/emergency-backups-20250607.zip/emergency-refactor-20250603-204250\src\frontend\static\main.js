// SaaSpype Frontend JavaScript - Performance Optimized
const API_BASE_URL = 'http://localhost:8001';

// Performance monitoring integration
const performanceMetrics = {
    startTime: performance.now(),
    interactions: 0,
    apiCalls: 0
};

// Debounce utility for performance optimization
function debounce(func, wait) {
    let timeout;
    return function executedFunction(...args) {
        const later = () => {
            clearTimeout(timeout);
            func(...args);
        };
        clearTimeout(timeout);
        timeout = setTimeout(later, wait);
    };
}

// Lazy loading utility
function lazyLoad(selector, callback) {
    const observer = new IntersectionObserver((entries) => {
        entries.forEach(entry => {
            if (entry.isIntersecting) {
                callback(entry.target);
                observer.unobserve(entry.target);
            }
        });
    }, { threshold: 0.1 });
    
    document.querySelectorAll(selector).forEach(el => observer.observe(el));
}

// Performance-optimized notification system
function showNotification(message, type = 'success') {
    // Reuse existing notification if present
    let notification = document.querySelector('.notification-toast');
    
    if (!notification) {
        notification = document.createElement('div');
        notification.className = 'notification-toast fixed top-4 right-4 p-4 rounded-lg text-white z-50 transition-all duration-300 transform translate-x-full';
        document.body.appendChild(notification);
    }
    
    // Update notification content and style
    notification.className = `notification-toast fixed top-4 right-4 p-4 rounded-lg text-white z-50 transition-all duration-300 ${
        type === 'success' ? 'bg-green-500' : 'bg-red-500'
    }`;
    notification.textContent = message;
    
    // Animate in
    requestAnimationFrame(() => {
        notification.style.transform = 'translateX(0)';
    });
    
    // Auto-hide with cleanup
    setTimeout(() => {
        notification.style.transform = 'translateX(100%)';
        setTimeout(() => {
            if (notification.parentNode) {
                notification.remove();
            }
        }, 300);
    }, 3000);
}

// Optimized smooth scrolling with performance tracking
function scrollToSection(sectionId) {
    performanceMetrics.interactions++;
    
    const element = document.getElementById(sectionId);
    if (element) {
        element.scrollIntoView({
            behavior: 'smooth',
            block: 'start'
        });
        
        // Track scroll interaction
        try {
            apiCall('/api/analytics/scroll-interaction', 'POST', { 
                section: sectionId,
                timestamp: new Date().toISOString()
            });
        } catch (error) {
            console.log('Scroll tracking failed:', error);
        }
    }
}

// Enhanced product demo with performance optimization
function showProductDemo() {
    performanceMetrics.interactions++;
    
    // Check if modal already exists to avoid recreation
    let demoModal = document.getElementById('demo-modal');
    
    if (!demoModal) {
        demoModal = document.createElement('div');
        demoModal.id = 'demo-modal';
        demoModal.className = 'fixed inset-0 bg-black bg-opacity-75 z-50 flex items-center justify-center p-4 opacity-0 transition-opacity duration-300';
        demoModal.innerHTML = `
            <div class="bg-white rounded-lg max-w-4xl w-full max-h-[90vh] overflow-hidden transform scale-95 transition-transform duration-300">
                <div class="flex justify-between items-center p-6 border-b">
                    <h3 class="text-2xl font-semibold">SaaSpype Platform Demo</h3>
                    <button onclick="closeDemoModal()" class="text-gray-400 hover:text-gray-600 text-2xl transition-colors duration-200">
                        <i class="fas fa-times"></i>
                    </button>
                </div>
                <div class="p-6">
                    <div class="aspect-video bg-gradient-to-br from-indigo-500 to-purple-600 rounded-lg flex items-center justify-center text-white mb-6">
                        <div class="text-center">
                            <i class="fas fa-play-circle text-6xl mb-4 opacity-80 hover:opacity-100 transition-opacity duration-200 cursor-pointer"></i>
                            <p class="text-xl">Interactive Demo</p>
                            <p class="text-sm opacity-80 mt-2">See how SaaSpype helps you scale from $0 to $1M ARR</p>
                        </div>
                    </div>
                    <div class="grid grid-cols-1 md:grid-cols-3 gap-4 text-sm">
                        <div class="bg-gray-50 p-4 rounded-lg hover:bg-gray-100 transition-colors duration-200">
                            <h4 class="font-semibold text-indigo-600 mb-2">📊 Analytics Dashboard</h4>
                            <p class="text-gray-600">Real-time MRR, churn, and growth metrics</p>
                        </div>
                        <div class="bg-gray-50 p-4 rounded-lg hover:bg-gray-100 transition-colors duration-200">
                            <h4 class="font-semibold text-indigo-600 mb-2">💰 Pricing Optimizer</h4>
                            <p class="text-gray-600">AI-powered pricing recommendations</p>
                        </div>
                        <div class="bg-gray-50 p-4 rounded-lg hover:bg-gray-100 transition-colors duration-200">
                            <h4 class="font-semibold text-indigo-600 mb-2">🚀 Growth Tools</h4>
                            <p class="text-gray-600">Automated onboarding and retention</p>
                        </div>
                    </div>
                    <div class="mt-6 text-center">
                        <button onclick="closeDemoModal(); openSignupModal();" class="bg-indigo-600 text-white px-6 py-3 rounded-lg font-semibold hover:bg-indigo-700 transition-all duration-300 transform hover:scale-105">
                            Start Your Free Trial Now
                        </button>
                    </div>
                </div>
            </div>
        `;
        
        document.body.appendChild(demoModal);
    }
    
    // Animate modal in
    requestAnimationFrame(() => {
        demoModal.style.opacity = '1';
        demoModal.querySelector('.bg-white').style.transform = 'scale(1)';
    });
    
    // Track demo view with performance data
    try {
        apiCall('/api/analytics/demo-view', 'POST', { 
            timestamp: new Date().toISOString(),
            loadTime: performance.now() - performanceMetrics.startTime
        });
    } catch (error) {
        console.log('Demo tracking failed:', error);
    }
}

function closeDemoModal() {
    const demoModal = document.getElementById('demo-modal');
    if (demoModal) {
        demoModal.style.opacity = '0';
        demoModal.querySelector('.bg-white').style.transform = 'scale(0.95)';
        setTimeout(() => {
            if (demoModal.parentNode) {
                demoModal.remove();
            }
        }, 300);
    }
}

// Optimized real-time activity with performance considerations
function showRealtimeActivity() {
    const activities = [
        "Sarah from NYC just signed up",
        "Mike upgraded to Pro plan", 
        "Alex launched their SaaS",
        "Emma increased MRR by 40%",
        "David from SF started free trial",
        "Lisa optimized her pricing",
        "Tom from London went live",
        "Maria scaled to $50K MRR"
    ];
    
    let activityCount = 0;
    const maxActivities = 3; // Limit concurrent activities for performance
    
    function showActivity() {
        if (activityCount >= maxActivities) return;
        
        const activity = activities[Math.floor(Math.random() * activities.length)];
        const notification = document.createElement('div');
        notification.className = 'fixed bottom-4 left-4 bg-white border border-gray-200 rounded-lg p-3 shadow-lg z-40 max-w-xs transform translate-y-full transition-all duration-300';
        notification.innerHTML = `
            <div class="flex items-center">
                <div class="w-2 h-2 bg-green-500 rounded-full mr-3 animate-pulse"></div>
                <div class="text-sm text-gray-700">${activity}</div>
            </div>
        `;
        
        document.body.appendChild(notification);
        activityCount++;
        
        // Animate in
        requestAnimationFrame(() => {
            notification.style.transform = 'translateY(0)';
        });
        
        // Auto-hide with cleanup
        setTimeout(() => {
            notification.style.transform = 'translateY(100%)';
            setTimeout(() => {
                if (notification.parentNode) {
                    notification.remove();
                    activityCount--;
                }
            }, 300);
        }, 4000);
    }
    
    // Show first activity after page load
    setTimeout(showActivity, 3000);
    
    // Show activities with random intervals
    setInterval(() => {
        if (Math.random() > 0.3 && document.visibilityState === 'visible') {
            showActivity();
        }
    }, 20000);
}

// Performance-optimized modal functions
function openSignupModal() {
    performanceMetrics.interactions++;
    const modal = document.getElementById('signup-modal');
    if (modal) {
        modal.classList.remove('hidden');
        // Focus first input for accessibility
        const firstInput = modal.querySelector('input');
        if (firstInput) {
            setTimeout(() => firstInput.focus(), 100);
        }
    }
}

function closeSignupModal() {
    const modal = document.getElementById('signup-modal');
    if (modal) {
        modal.classList.add('hidden');
        document.getElementById('signup-form')?.reset();
    }
}

// Enhanced API functions with performance monitoring
async function apiCall(endpoint, method = 'GET', data = null) {
    const startTime = performance.now();
    performanceMetrics.apiCalls++;
    
    const config = {
        method,
        headers: {
            'Content-Type': 'application/json',
        },
    };
    
    if (data) {
        config.body = JSON.stringify(data);
    }
    
    try {
        const response = await fetch(`${API_BASE_URL}${endpoint}`, config);
        const result = await response.json();
        
        // Track API performance
        const duration = performance.now() - startTime;
        console.log(`API ${method} ${endpoint}: ${duration.toFixed(2)}ms`);
        
        if (!response.ok) {
            throw new Error(result.detail || 'API request failed');
        }
        
        return result;
    } catch (error) {
        console.error('API Error:', error);
        throw error;
    }
}

// Optimized pricing plans loading with caching
let pricingCache = null;
async function loadPricingPlans() {
    // Use cached data if available and recent
    if (pricingCache && (Date.now() - pricingCache.timestamp) < 300000) { // 5 minutes
        renderPricingPlans(pricingCache.data);
        return;
    }
    
    try {
        const response = await apiCall('/api/pricing');
        pricingCache = {
            data: response,
            timestamp: Date.now()
        };
        renderPricingPlans(response);
    } catch (error) {
        console.error('Failed to load pricing plans:', error);
        showNotification('Failed to load pricing plans', 'error');
    }
}

function renderPricingPlans(response) {
    const pricingContainer = document.getElementById('pricing-plans');
    if (!pricingContainer) return;
    
    pricingContainer.innerHTML = response.plans.map(plan => `
        <div class="card-hover bg-white p-8 rounded-xl shadow-lg ${plan.popular ? 'ring-2 ring-indigo-500 relative' : ''}">
            ${plan.popular ? '<div class="absolute -top-3 left-1/2 transform -translate-x-1/2 bg-indigo-500 text-white px-4 py-1 rounded-full text-sm font-semibold">Most Popular</div>' : ''}
            <div class="text-center">
                <h3 class="text-2xl font-bold text-gray-900 mb-4">${plan.name}</h3>
                <div class="text-4xl font-bold text-indigo-600 mb-6">
                    $${plan.price}<span class="text-lg text-gray-500">/month</span>
                </div>
                <ul class="text-gray-600 mb-8 space-y-3">
                    ${plan.features.map(feature => `
                        <li class="flex items-center">
                            <i class="fas fa-check text-green-500 mr-3"></i>
                            ${feature}
                        </li>
                    `).join('')}
                </ul>
                <button onclick="selectPlan('${plan.name}', ${plan.price})" class="w-full ${plan.popular ? 'bg-indigo-600 hover:bg-indigo-700' : 'bg-gray-600 hover:bg-gray-700'} text-white py-3 px-6 rounded-lg font-semibold transition-all duration-300 transform hover:scale-105">
                    Choose ${plan.name}
                </button>
            </div>
        </div>
    `).join('');
}

function selectPlan(planName, price) {
    // Store selected plan and open signup modal
    sessionStorage.setItem('selectedPlan', JSON.stringify({ name: planName, price }));
    openSignupModal();
}

// Form handlers
async function handleContactForm(event) {
    event.preventDefault();
    
    const formData = new FormData(event.target);
    const contactData = {
        name: formData.get('name'),
        email: formData.get('email'),
        company: formData.get('company') || null,
        message: formData.get('message')
    };
    
    try {
        await apiCall('/api/contact', 'POST', contactData);
        showNotification('Thank you! Your message has been sent successfully.');
        event.target.reset();
    } catch (error) {
        showNotification('Failed to send message. Please try again.', 'error');
    }
}

async function handleSignupForm(event) {
    event.preventDefault();
    
    const formData = new FormData(event.target);
    const userData = {
        name: formData.get('name'),
        email: formData.get('email'),
        company: formData.get('company') || null
    };
    
    try {
        await apiCall('/api/signup', 'POST', userData);
        
        const selectedPlan = JSON.parse(sessionStorage.getItem('selectedPlan') || '{}');
        if (selectedPlan.name) {
            showNotification(`Welcome! You've signed up for the ${selectedPlan.name} plan.`);
            sessionStorage.removeItem('selectedPlan');
        } else {
            showNotification('Welcome! Your account has been created successfully.');
        }
        
        closeSignupModal();
    } catch (error) {
        showNotification('Failed to create account. Please try again.', 'error');
    }
}

// Initialize page
document.addEventListener('DOMContentLoaded', function() {
    // Load pricing plans
    loadPricingPlans();
    
    // Start real-time activity simulation
    showRealtimeActivity();
    
    // Set up form handlers
    const contactForm = document.getElementById('contact-form');
    if (contactForm) {
        contactForm.addEventListener('submit', handleContactForm);
    }
    
    const signupForm = document.getElementById('signup-form');
    if (signupForm) {
        signupForm.addEventListener('submit', handleSignupForm);
    }
    
    // Close modal when clicking outside
    const signupModal = document.getElementById('signup-modal');
    if (signupModal) {
        signupModal.addEventListener('click', function(event) {
            if (event.target === signupModal) {
                closeSignupModal();
            }
        });
    }
    
    // Smooth scrolling for navigation links
    document.querySelectorAll('a[href^="#"]').forEach(anchor => {
        anchor.addEventListener('click', function (e) {
            e.preventDefault();
            const target = document.querySelector(this.getAttribute('href'));
            if (target) {
                target.scrollIntoView({
                    behavior: 'smooth'
                });
            }
        });
    });
});

// Make functions globally available
window.openSignupModal = openSignupModal;
window.closeSignupModal = closeSignupModal;
window.scrollToSection = scrollToSection;
window.selectPlan = selectPlan;
window.showProductDemo = showProductDemo;
window.closeDemoModal = closeDemoModal;

// Multi-step signup form functions
let currentSignupStep = 1;

function nextSignupStep(step) {
    // Validate current step
    if (!validateSignupStep(currentSignupStep)) {
        return;
    }
    
    // Hide current step
    document.getElementById(`signup-step-${currentSignupStep}`).classList.add('hidden');
    document.getElementById(`step-${currentSignupStep}-indicator`).classList.remove('bg-indigo-600');
    document.getElementById(`step-${currentSignupStep}-indicator`).classList.add('bg-green-500');
    
    // Show next step
    currentSignupStep = step;
    document.getElementById(`signup-step-${currentSignupStep}`).classList.remove('hidden');
    document.getElementById(`step-${currentSignupStep}-indicator`).classList.remove('bg-gray-300');
    document.getElementById(`step-${currentSignupStep}-indicator`).classList.add('bg-indigo-600');
    
    // Focus first input in new step
    const firstInput = document.querySelector(`#signup-step-${currentSignupStep} input, #signup-step-${currentSignupStep} select`);
    if (firstInput) {
        setTimeout(() => firstInput.focus(), 100);
    }
    
    // Track step progression
    try {
        apiCall('/api/analytics/signup-step', 'POST', { 
            step: currentSignupStep,
            timestamp: new Date().toISOString()
        });
    } catch (error) {
        console.log('Signup step tracking failed:', error);
    }
}

function prevSignupStep(step) {
    // Hide current step
    document.getElementById(`signup-step-${currentSignupStep}`).classList.add('hidden');
    document.getElementById(`step-${currentSignupStep}-indicator`).classList.remove('bg-indigo-600');
    document.getElementById(`step-${currentSignupStep}-indicator`).classList.add('bg-gray-300');
    
    // Show previous step
    currentSignupStep = step;
    document.getElementById(`signup-step-${currentSignupStep}`).classList.remove('hidden');
    document.getElementById(`step-${currentSignupStep}-indicator`).classList.remove('bg-green-500');
    document.getElementById(`step-${currentSignupStep}-indicator`).classList.add('bg-indigo-600');
}

function validateSignupStep(step) {
    switch(step) {
        case 1:
            const email = document.getElementById('signup-email').value;
            if (!email || !isValidEmail(email)) {
                showNotification('Please enter a valid email address', 'error');
                return false;
            }
            break;
        case 2:
            const name = document.getElementById('signup-name').value;
            const company = document.getElementById('signup-company').value;
            if (!name.trim()) {
                showNotification('Please enter your full name', 'error');
                return false;
            }
            if (!company.trim()) {
                showNotification('Please enter your company name', 'error');
                return false;
            }
            break;
        case 3:
            const goal = document.getElementById('signup-goal').value;
            const terms = document.getElementById('signup-terms').checked;
            if (!goal) {
                showNotification('Please select your main goal', 'error');
                return false;
            }
            if (!terms) {
                showNotification('Please agree to the terms of service', 'error');
                return false;
            }
            break;
    }
    return true;
}

function isValidEmail(email) {
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    return emailRegex.test(email);
}

// Exit-intent modal functions
function showExitIntentModal() {
    const modal = document.getElementById('exit-intent-modal');
    if (modal) {
        modal.classList.remove('hidden');
        // Animate in
        requestAnimationFrame(() => {
            modal.querySelector('.bg-white').style.transform = 'scale(1)';
        });
        
        // Track exit-intent trigger
        try {
            apiCall('/api/analytics/exit-intent', 'POST', { 
                timestamp: new Date().toISOString()
            });
        } catch (error) {
            console.log('Exit intent tracking failed:', error);
        }
    }
}

function closeExitIntentModal() {
    const modal = document.getElementById('exit-intent-modal');
    if (modal) {
        modal.querySelector('.bg-white').style.transform = 'scale(0.95)';
        setTimeout(() => {
            modal.classList.add('hidden');
        }, 300);
    }
}

// Lead magnet form handler
async function handleLeadMagnetForm(event) {
    event.preventDefault();
    
    const email = document.getElementById('lead-email').value;
    
    if (!isValidEmail(email)) {
        showNotification('Please enter a valid email address', 'error');
        return;
    }
    
    try {
        const response = await apiCall('/api/lead-magnet', 'POST', {
            email: email,
            source: 'exit-intent',
            timestamp: new Date().toISOString()
        });
        
        showNotification('Success! Check your email for the download link.', 'success');
        closeExitIntentModal();
        
        // Show thank you message
        setTimeout(() => {
            showNotification('🎉 Welcome to the SaaSpype community!', 'success');
        }, 2000);
        
    } catch (error) {
        console.error('Lead magnet signup failed:', error);
        showNotification('Something went wrong. Please try again.', 'error');
    }
}

// Social login functions
async function signupWithGoogle() {
    performanceMetrics.interactions++;
    
    try {
        // Track social signup attempt
        apiCall('/api/analytics/social-signup', 'POST', { 
            provider: 'google',
            timestamp: new Date().toISOString()
        });
        
        // Simulate Google OAuth (replace with actual implementation)
        showNotification('Google signup coming soon! Use email signup for now.', 'error');
        
    } catch (error) {
        console.error('Google signup failed:', error);
        showNotification('Google signup temporarily unavailable', 'error');
    }
}

async function signupWithLinkedIn() {
    performanceMetrics.interactions++;
    
    try {
        // Track social signup attempt
        apiCall('/api/analytics/social-signup', 'POST', { 
            provider: 'linkedin',
            timestamp: new Date().toISOString()
        });
        
        // Simulate LinkedIn OAuth (replace with actual implementation)
        showNotification('LinkedIn signup coming soon! Use email signup for now.', 'error');
        
    } catch (error) {
        console.error('LinkedIn signup failed:', error);
        showNotification('LinkedIn signup temporarily unavailable', 'error');
    }
}

// Enhanced form handlers
async function handleSignupForm(event) {
    event.preventDefault();
    
    if (!validateSignupStep(3)) {
        return;
    }
    
    const formData = {
        email: document.getElementById('signup-email').value,
        name: document.getElementById('signup-name').value,
        company: document.getElementById('signup-company').value,
        goal: document.getElementById('signup-goal').value,
        timestamp: new Date().toISOString(),
        source: 'multi-step-form'
    };
    
    try {
        const response = await apiCall('/api/signup', 'POST', formData);
        
        showNotification('🎉 Welcome to SaaSpype! Check your email to get started.', 'success');
        closeSignupModal();
        
        // Reset form
        currentSignupStep = 1;
        document.querySelectorAll('.signup-step').forEach(step => step.classList.add('hidden'));
        document.getElementById('signup-step-1').classList.remove('hidden');
        document.querySelectorAll('[id$="-indicator"]').forEach(indicator => {
            indicator.classList.remove('bg-indigo-600', 'bg-green-500');
            indicator.classList.add('bg-gray-300');
        });
        document.getElementById('step-1-indicator').classList.remove('bg-gray-300');
        document.getElementById('step-1-indicator').classList.add('bg-indigo-600');
        
        // Track successful signup
        apiCall('/api/analytics/signup-complete', 'POST', { 
            source: 'multi-step-form',
            timestamp: new Date().toISOString()
        });
        
    } catch (error) {
        console.error('Signup failed:', error);
        showNotification('Signup failed. Please try again.', 'error');
    }
}

// Plan selection with A/B testing
async function selectPlan(planName, price) {
    performanceMetrics.interactions++;
    
    try {
        // Track plan selection
        await apiCall('/api/analytics/plan-selected', 'POST', { 
            plan: planName,
            price: price,
            timestamp: new Date().toISOString()
        });
        
        // Open signup modal with plan pre-selected
        openSignupModal();
        
        // Add plan info to form
        const planInfo = document.createElement('div');
        planInfo.className = 'bg-indigo-50 p-3 rounded-lg mb-4';
        planInfo.innerHTML = `
            <div class="flex items-center justify-between">
                <span class="text-sm text-indigo-700">Selected Plan: <strong>${planName}</strong></span>
                <span class="text-sm font-semibold text-indigo-900">$${price}/month</span>
            </div>
        `;
        
        const firstStep = document.getElementById('signup-step-1');
        firstStep.insertBefore(planInfo, firstStep.firstChild);
        
    } catch (error) {
        console.error('Plan selection failed:', error);
        showNotification('Plan selection failed. Please try again.', 'error');
    }
}

// Enhanced contact form with validation
async function handleContactForm(event) {
    event.preventDefault();
    
    const name = document.getElementById('contact-name').value.trim();
    const email = document.getElementById('contact-email').value.trim();
    const message = document.getElementById('contact-message').value.trim();
    
    // Validation
    if (!name) {
        showNotification('Please enter your name', 'error');
        return;
    }
    
    if (!isValidEmail(email)) {
        showNotification('Please enter a valid email address', 'error');
        return;
    }
    
    if (!message || message.length < 10) {
        showNotification('Please enter a message (at least 10 characters)', 'error');
        return;
    }
    
    try {
        const response = await apiCall('/api/contact', 'POST', {
            name: name,
            email: email,
            message: message,
            timestamp: new Date().toISOString()
        });
        
        showNotification('Thank you! We\'ll get back to you within 24 hours.', 'success');
        document.getElementById('contact-form').reset();
        
    } catch (error) {
        console.error('Contact form submission failed:', error);
        showNotification('Message failed to send. Please try again.', 'error');
    }
}

// Performance monitoring and reporting
function reportPerformanceMetrics() {
    const metrics = {
        ...performanceMetrics,
        currentTime: performance.now(),
        userAgent: navigator.userAgent,
        viewport: {
            width: window.innerWidth,
            height: window.innerHeight
        },
        connection: navigator.connection ? {
            effectiveType: navigator.connection.effectiveType,
            downlink: navigator.connection.downlink
        } : null
    };
    
    try {
        apiCall('/api/analytics/performance', 'POST', metrics);
    } catch (error) {
        console.log('Performance reporting failed:', error);
    }
}

// Initialize event listeners
document.addEventListener('DOMContentLoaded', function() {
    // Lead magnet form
    const leadMagnetForm = document.getElementById('lead-magnet-form');
    if (leadMagnetForm) {
        leadMagnetForm.addEventListener('submit', handleLeadMagnetForm);
    }
    
    // Enhanced signup form
    const signupForm = document.getElementById('signup-form');
    if (signupForm) {
        signupForm.addEventListener('submit', handleSignupForm);
    }
    
    // Contact form
    const contactForm = document.getElementById('contact-form');
    if (contactForm) {
        contactForm.addEventListener('submit', handleContactForm);
    }
    
    // Report performance metrics every 30 seconds
    setInterval(reportPerformanceMetrics, 30000);
    
    // Report final metrics on page unload
    window.addEventListener('beforeunload', reportPerformanceMetrics);
}); 