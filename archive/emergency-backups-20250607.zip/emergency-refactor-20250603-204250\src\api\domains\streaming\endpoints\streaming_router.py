#!/usr/bin/env python3
"""
Streaming Router - Real-time Data Processing Endpoints
Handles all streaming, real-time processing, and multi-modal fusion endpoints
"""

from fastapi import APIRouter, Depends, HTTPException, Query, BackgroundTasks, WebSocket, WebSocketDisconnect
from typing import Optional, Dict, Any
import logging
import asyncio
import json
import numpy as np
from datetime import datetime

from src.api.endpoints.auth import get_current_user
from src.api.services.streaming_trend_pipeline import GroundbreakingStreamingPipeline, EventType
from src.api.services.multimodal_fusion_engine import fusion_engine, MultiModalSignal, SignalType
from src.api.services.websocket_broadcaster import websocket_broadcaster

logger = logging.getLogger(__name__)

# Create router with streaming prefix
router = APIRouter(prefix="/api", tags=["Real-time Streaming"])

# Global instances (lazy-loaded)
_streaming_pipeline = None

def get_streaming_pipeline():
    """Get or create streaming pipeline instance"""
    global _streaming_pipeline
    if _streaming_pipeline is None:
        _streaming_pipeline = GroundbreakingStreamingPipeline()
    return _streaming_pipeline

@router.post("/streaming/start", tags=["Real-time Streaming"])
async def start_streaming_pipeline(
    background_tasks: BackgroundTasks,
    current_user: dict = Depends(get_current_user)
):
    """Start the real-time streaming pipeline"""
    try:
        pipeline = get_streaming_pipeline()
        
        # Start streaming in background
        background_tasks.add_task(pipeline.start_streaming)
        
        logger.info(f"Streaming pipeline started by user {current_user.get('email')}")
        
        return {
            "success": True,
            "message": "Streaming pipeline started",
            "user_id": current_user["user_id"],
            "timestamp": datetime.now().isoformat()
        }
        
    except Exception as e:
        logger.error(f"Failed to start streaming pipeline: {str(e)}")
        raise HTTPException(status_code=500, detail=f"Failed to start streaming: {str(e)}")

@router.post("/streaming/stop", tags=["Real-time Streaming"])
async def stop_streaming_pipeline(current_user: dict = Depends(get_current_user)):
    """Stop the real-time streaming pipeline"""
    try:
        pipeline = get_streaming_pipeline()
        
        # Stop streaming
        await pipeline.stop_streaming()
        
        logger.info(f"Streaming pipeline stopped by user {current_user.get('email')}")
        
        return {
            "success": True,
            "message": "Streaming pipeline stopped",
            "user_id": current_user["user_id"],
            "timestamp": datetime.now().isoformat()
        }
        
    except Exception as e:
        logger.error(f"Failed to stop streaming pipeline: {str(e)}")
        raise HTTPException(status_code=500, detail=f"Failed to stop streaming: {str(e)}")

@router.get("/streaming/status", tags=["Real-time Streaming"])
async def get_streaming_status(current_user: dict = Depends(get_current_user)):
    """Get current streaming pipeline status"""
    try:
        pipeline = get_streaming_pipeline()
        
        # Get comprehensive status
        status = await pipeline.get_status()
        
        return {
            "status": status,
            "user_id": current_user["user_id"],
            "timestamp": datetime.now().isoformat()
        }
        
    except Exception as e:
        logger.error(f"Failed to get streaming status: {str(e)}")
        raise HTTPException(status_code=500, detail=f"Status check failed: {str(e)}")

@router.get("/streaming/events", tags=["Real-time Streaming"])
async def get_real_time_events(
    event_type: Optional[str] = Query(None, description="Filter by event type"),
    limit: int = Query(100, description="Maximum events to return", ge=1, le=1000),
    current_user: dict = Depends(get_current_user)
):
    """Get real-time events from the streaming pipeline"""
    try:
        pipeline = get_streaming_pipeline()
        
        # Get recent events
        events = await pipeline.get_recent_events(
            event_type=event_type,
            limit=limit
        )
        
        return {
            "events": events,
            "event_type": event_type,
            "limit": limit,
            "count": len(events),
            "user_id": current_user["user_id"]
        }
        
    except Exception as e:
        logger.error(f"Failed to get streaming events: {str(e)}")
        raise HTTPException(status_code=500, detail=f"Event retrieval failed: {str(e)}")

@router.post("/streaming/simulate", tags=["Real-time Streaming"])
async def simulate_signal_stream(
    background_tasks: BackgroundTasks,
    signal_count: int = Query(100, description="Number of signals to simulate", ge=10, le=1000),
    signals_per_second: float = Query(10.0, description="Signals per second rate", ge=1.0, le=100.0),
    current_user: dict = Depends(get_current_user)
):
    """Simulate high-throughput signal stream for testing"""
    try:
        pipeline = get_streaming_pipeline()
        
        async def simulate_signals():
            """Background task to simulate signal stream"""
            import random
            
            class MockSignal:
                def __init__(self):
                    self.source = random.choice(["reddit", "twitter", "github", "news"])
                    self.content = f"Test signal {random.randint(1000, 9999)}"
                    self.timestamp = datetime.now().isoformat()
                    self.engagement_score = random.uniform(0.1, 1.0)
                    self.keywords = random.sample(["AI", "SaaS", "automation", "API", "cloud"], 2)
            
            async def mock_stream():
                """Generate mock signal stream"""
                for i in range(signal_count):
                    signal = MockSignal()
                    await pipeline.process_signal(signal)
                    
                    if i % 10 == 0:
                        logger.info(f"Simulated {i+1}/{signal_count} signals")
                    
                    # Control rate
                    await asyncio.sleep(1.0 / signals_per_second)
                
                logger.info(f"Signal simulation completed: {signal_count} signals processed")
            
            await mock_stream()
        
        # Start simulation in background
        background_tasks.add_task(simulate_signals)
        
        return {
            "success": True,
            "message": "Signal simulation started",
            "signal_count": signal_count,
            "signals_per_second": signals_per_second,
            "user_id": current_user["user_id"]
        }
        
    except Exception as e:
        logger.error(f"Signal simulation failed: {str(e)}")
        raise HTTPException(status_code=500, detail=f"Simulation failed: {str(e)}")

@router.get("/streaming/analytics", tags=["Real-time Streaming"])
async def get_streaming_analytics(
    window: str = Query("all", description="Window to analyze: micro, short, medium, long, macro, or all"),
    current_user: dict = Depends(get_current_user)
):
    """Get comprehensive streaming analytics"""
    try:
        pipeline = get_streaming_pipeline()
        
        # Get analytics for specified window
        analytics = await pipeline.get_analytics(window=window)
        
        return {
            "analytics": analytics,
            "window": window,
            "user_id": current_user["user_id"],
            "timestamp": datetime.now().isoformat()
        }
        
    except Exception as e:
        logger.error(f"Failed to get streaming analytics: {str(e)}")
        raise HTTPException(status_code=500, detail=f"Analytics failed: {str(e)}")

# Multi-Modal Fusion Endpoints

@router.post("/fusion/process", tags=["Multi-Modal Fusion"])
async def process_multimodal_signal(
    signal_data: Dict[str, Any],
    current_user: dict = Depends(get_current_user)
):
    """Process multi-modal signal through fusion engine"""
    try:
        # Create MultiModalSignal from request data
        signal = MultiModalSignal(
            text_content=signal_data.get("text_content"),
            network_data=signal_data.get("network_data"),
            temporal_features=signal_data.get("temporal_features"),
            behavioral_patterns=signal_data.get("behavioral_patterns"),
            metadata=signal_data.get("metadata", {})
        )
        
        # Process through fusion engine
        result = await fusion_engine.process_signal(signal)
        
        logger.info(f"Multi-modal signal processed for user {current_user.get('email')}")
        
        return {
            "result": result,
            "user_id": current_user["user_id"],
            "timestamp": datetime.now().isoformat()
        }
        
    except Exception as e:
        logger.error(f"Multi-modal processing failed: {str(e)}")
        raise HTTPException(status_code=500, detail=f"Fusion processing failed: {str(e)}")

@router.get("/fusion/statistics", tags=["Multi-Modal Fusion"])
async def get_fusion_statistics(current_user: dict = Depends(get_current_user)):
    """Get fusion engine statistics"""
    try:
        stats = await fusion_engine.get_statistics()
        
        return {
            "statistics": stats,
            "user_id": current_user["user_id"],
            "timestamp": datetime.now().isoformat()
        }
        
    except Exception as e:
        logger.error(f"Failed to get fusion statistics: {str(e)}")
        raise HTTPException(status_code=500, detail=f"Statistics failed: {str(e)}")

@router.post("/fusion/simulate", tags=["Multi-Modal Fusion"])
async def simulate_multimodal_signals(
    background_tasks: BackgroundTasks,
    signal_count: int = Query(50, description="Number of signals to simulate", ge=10, le=500),
    signals_per_second: float = Query(5.0, description="Signals per second rate", ge=1.0, le=50.0),
    modality_mix: str = Query("balanced", description="Modality distribution: balanced, text_heavy, network_heavy, temporal_heavy, behavioral_heavy"),
    current_user: dict = Depends(get_current_user)
):
    """Simulate multi-modal signal stream"""
    try:
        async def simulate_multimodal_stream():
            """Background task for multi-modal simulation"""
            import random
            
            for i in range(signal_count):
                # Generate signal based on modality mix
                signal_data = {
                    "text_content": f"Multi-modal test signal {i+1}",
                    "network_data": {"connections": random.randint(10, 100)},
                    "temporal_features": {"trend_score": random.uniform(0.1, 1.0)},
                    "behavioral_patterns": {"engagement": random.uniform(0.1, 1.0)},
                    "metadata": {"simulation": True, "mix": modality_mix}
                }
                
                # Create and process signal
                signal = MultiModalSignal(**signal_data)
                await fusion_engine.process_signal(signal)
                
                if i % 10 == 0:
                    logger.info(f"Processed {i+1}/{signal_count} multi-modal signals")
                
                # Control rate
                await asyncio.sleep(1.0 / signals_per_second)
            
            logger.info(f"Multi-modal simulation completed: {signal_count} signals")
        
        # Start simulation in background
        background_tasks.add_task(simulate_multimodal_stream)
        
        return {
            "success": True,
            "message": "Multi-modal simulation started",
            "signal_count": signal_count,
            "signals_per_second": signals_per_second,
            "modality_mix": modality_mix,
            "user_id": current_user["user_id"]
        }
        
    except Exception as e:
        logger.error(f"Multi-modal simulation failed: {str(e)}")
        raise HTTPException(status_code=500, detail=f"Simulation failed: {str(e)}")

@router.get("/fusion/correlations", tags=["Multi-Modal Fusion"])
async def get_cross_modal_correlations(
    modality: Optional[str] = Query(None, description="Filter by specific modality"),
    time_window: int = Query(60, description="Time window in minutes", ge=5, le=1440),
    current_user: dict = Depends(get_current_user)
):
    """Get cross-modal correlations analysis"""
    try:
        correlations = await fusion_engine.get_cross_modal_correlations(
            modality=modality,
            time_window=time_window
        )
        
        return {
            "correlations": correlations,
            "modality": modality,
            "time_window": time_window,
            "user_id": current_user["user_id"],
            "timestamp": datetime.now().isoformat()
        }
        
    except Exception as e:
        logger.error(f"Failed to get correlations: {str(e)}")
        raise HTTPException(status_code=500, detail=f"Correlation analysis failed: {str(e)}")

# WebSocket endpoint for real-time fusion data
@router.websocket("/ws/fusion")
async def websocket_fusion_endpoint(websocket: WebSocket):
    """WebSocket endpoint for real-time fusion data"""
    await websocket.accept()
    
    try:
        # Register client with broadcaster
        client_id = await websocket_broadcaster.add_client(websocket)
        logger.info(f"WebSocket client connected: {client_id}")
        
        while True:
            # Keep connection alive and handle incoming messages
            try:
                data = await websocket.receive_text()
                message = json.loads(data)
                
                # Echo back with fusion data
                response = {
                    "type": "fusion_update",
                    "timestamp": datetime.now().isoformat(),
                    "client_id": client_id,
                    "message": message
                }
                
                await websocket.send_text(json.dumps(response))
                
            except Exception as e:
                logger.error(f"WebSocket message error: {str(e)}")
                break
                
    except WebSocketDisconnect:
        logger.info(f"WebSocket client disconnected: {client_id}")
        await websocket_broadcaster.remove_client(client_id)
    except Exception as e:
        logger.error(f"WebSocket error: {str(e)}")
        await websocket_broadcaster.remove_client(client_id) 