#!/usr/bin/env python3
"""
Discovery Router - SaaS Idea Discovery Endpoints
Handles all discovery-related API endpoints
"""

from fastapi import APIRouter, Depends, HTTPException, BackgroundTasks
from typing import Optional, Dict, Any
import logging

from src.api.endpoints.auth import get_current_user
from src.api.models.requests import DiscoveryRequest, SaveIdeaRequest
from src.api.services.discovery_service import discovery_service
from src.api.services.ideas_service import ideas_service

logger = logging.getLogger(__name__)

# Create router with discovery prefix
router = APIRouter(prefix="/api", tags=["Discovery"])

@router.post("/discover")
async def discover_opportunities(
    request: DiscoveryRequest,
    current_user: dict = Depends(get_current_user)
):
    """Main discovery endpoint - find SaaS opportunities from Reddit"""
    logger.info(f"Discovery request from user {current_user.get('email', 'Unknown')}")
    
    try:
        # Process discovery request
        result = await discovery_service.discover_opportunities(request)
        
        # Log successful discovery
        logger.info(f"Discovery completed: {len(result.get('opportunities', []))} opportunities found")
        
        return result
        
    except Exception as e:
        logger.error(f"Discovery failed: {str(e)}")
        raise HTTPException(status_code=500, detail=f"Discovery failed: {str(e)}")

@router.get("/discovery-history")
async def get_discovery_history(current_user: dict = Depends(get_current_user)):
    """Get user's discovery history"""
    try:
        history = await discovery_service.get_user_discovery_history(current_user["user_id"])
        return {"history": history}
    except Exception as e:
        logger.error(f"Failed to get discovery history: {str(e)}")
        raise HTTPException(status_code=500, detail="Failed to retrieve discovery history")

@router.get("/system-ideas")
async def get_system_ideas():
    """Get system-generated ideas (public endpoint)"""
    try:
        ideas = await ideas_service.get_system_ideas()
        return {"ideas": ideas}
    except Exception as e:
        logger.error(f"Failed to get system ideas: {str(e)}")
        raise HTTPException(status_code=500, detail="Failed to retrieve system ideas")

@router.post("/save-idea")
async def save_idea(
    request: SaveIdeaRequest,
    current_user: dict = Depends(get_current_user)
):
    """Save an idea to user's personal collection"""
    try:
        # Save idea with user association
        idea_id = await ideas_service.save_user_idea(
            user_id=current_user["user_id"],
            idea_data=request.dict()
        )
        
        logger.info(f"Idea saved by user {current_user.get('email')}: {idea_id}")
        
        return {
            "success": True,
            "message": "Idea saved successfully",
            "idea_id": idea_id
        }
        
    except Exception as e:
        logger.error(f"Failed to save idea: {str(e)}")
        raise HTTPException(status_code=500, detail=f"Failed to save idea: {str(e)}")

@router.get("/my-ideas")
async def get_my_ideas(current_user: dict = Depends(get_current_user)):
    """Get user's saved ideas"""
    try:
        ideas = await ideas_service.get_user_ideas(current_user["user_id"])
        return {"ideas": ideas}
    except Exception as e:
        logger.error(f"Failed to get user ideas: {str(e)}")
        raise HTTPException(status_code=500, detail="Failed to retrieve user ideas")

@router.post("/discover/enhanced")
async def enhanced_discovery(
    request: DiscoveryRequest,
    current_user: dict = Depends(get_current_user)
):
    """Enhanced discovery with advanced analysis"""
    logger.info(f"Enhanced discovery request from user {current_user.get('email', 'Unknown')}")
    
    try:
        # Use enhanced discovery service
        result = await discovery_service.enhanced_discovery(request)
        
        # Add performance metrics
        result["enhanced"] = True
        result["user_id"] = current_user["user_id"]
        
        logger.info(f"Enhanced discovery completed: {len(result.get('opportunities', []))} opportunities")
        
        return result
        
    except Exception as e:
        logger.error(f"Enhanced discovery failed: {str(e)}")
        raise HTTPException(status_code=500, detail=f"Enhanced discovery failed: {str(e)}") 