/**
 * SaaSpype Trend Widget Component
 * Reusable trend visualization component for embedding in other pages
 */

class TrendWidget {
    constructor(containerId, options = {}) {
        this.containerId = containerId;
        this.container = document.getElementById(containerId);
        this.options = {
            apiBase: options.apiBase || 'http://localhost:8001',
            refreshInterval: options.refreshInterval || 300000, // 5 minutes
            showCharts: options.showCharts !== false,
            showAlerts: options.showAlerts !== false,
            showTopSignals: options.showTopSignals !== false,
            maxItems: options.maxItems || 5,
            height: options.height || 'auto',
            theme: options.theme || 'light',
            ...options
        };
        
        this.data = null;
        this.refreshTimer = null;
        this.charts = {};
        
        this.init();
    }
    
    async init() {
        this.render();
        await this.loadData();
        this.startAutoRefresh();
    }
    
    render() {
        const widgetHtml = `
            <div class="trend-widget ${this.options.theme}" style="height: ${this.options.height}">
                <div class="trend-widget-header">
                    <h3 class="trend-widget-title">
                        <i class="fas fa-fire"></i>
                        Live Market Trends
                    </h3>
                    <div class="trend-widget-controls">
                        <button class="trend-refresh-btn" onclick="trendWidgets['${this.containerId}'].refresh()">
                            <i class="fas fa-sync-alt"></i>
                        </button>
                        <div class="trend-status">
                            <div class="trend-status-indicator"></div>
                            <span class="trend-status-text">Live</span>
                        </div>
                    </div>
                </div>
                
                <div class="trend-widget-content">
                    ${this.options.showCharts ? this.renderChartsSection() : ''}
                    ${this.options.showTopSignals ? this.renderTopSignalsSection() : ''}
                    ${this.options.showAlerts ? this.renderAlertsSection() : ''}
                </div>
                
                <div class="trend-widget-loading hidden">
                    <div class="trend-loading-spinner"></div>
                    <span>Loading trends...</span>
                </div>
            </div>
        `;
        
        this.container.innerHTML = widgetHtml;
        this.addStyles();
    }
    
    renderChartsSection() {
        return `
            <div class="trend-section trend-charts">
                <h4 class="trend-section-title">Trending Keywords</h4>
                <div class="trend-chart-container">
                    <canvas id="${this.containerId}-chart" class="trend-chart"></canvas>
                </div>
            </div>
        `;
    }
    
    renderTopSignalsSection() {
        return `
            <div class="trend-section trend-signals">
                <h4 class="trend-section-title">Top Signals</h4>
                <div id="${this.containerId}-signals" class="trend-signals-list">
                    <!-- Signals will be populated here -->
                </div>
            </div>
        `;
    }
    
    renderAlertsSection() {
        return `
            <div class="trend-section trend-alerts">
                <h4 class="trend-section-title">Recent Alerts</h4>
                <div id="${this.containerId}-alerts" class="trend-alerts-list">
                    <!-- Alerts will be populated here -->
                </div>
            </div>
        `;
    }
    
    addStyles() {
        if (document.getElementById('trend-widget-styles')) return;
        
        const styles = `
            <style id="trend-widget-styles">
                .trend-widget {
                    background: white;
                    border-radius: 8px;
                    box-shadow: 0 2px 8px rgba(0,0,0,0.1);
                    overflow: hidden;
                    font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
                }
                
                .trend-widget-header {
                    display: flex;
                    justify-content: space-between;
                    align-items: center;
                    padding: 16px 20px;
                    border-bottom: 1px solid #e5e7eb;
                    background: #f9fafb;
                }
                
                .trend-widget-title {
                    margin: 0;
                    font-size: 16px;
                    font-weight: 600;
                    color: #111827;
                    display: flex;
                    align-items: center;
                    gap: 8px;
                }
                
                .trend-widget-title i {
                    color: #ef4444;
                }
                
                .trend-widget-controls {
                    display: flex;
                    align-items: center;
                    gap: 12px;
                }
                
                .trend-refresh-btn {
                    background: none;
                    border: 1px solid #d1d5db;
                    border-radius: 4px;
                    padding: 6px 8px;
                    cursor: pointer;
                    color: #6b7280;
                    transition: all 0.2s;
                }
                
                .trend-refresh-btn:hover {
                    background: #f3f4f6;
                    color: #374151;
                }
                
                .trend-status {
                    display: flex;
                    align-items: center;
                    gap: 6px;
                    font-size: 12px;
                    color: #6b7280;
                }
                
                .trend-status-indicator {
                    width: 8px;
                    height: 8px;
                    background: #10b981;
                    border-radius: 50%;
                    animation: pulse 2s infinite;
                }
                
                @keyframes pulse {
                    0%, 100% { opacity: 1; }
                    50% { opacity: 0.5; }
                }
                
                .trend-widget-content {
                    padding: 20px;
                }
                
                .trend-section {
                    margin-bottom: 24px;
                }
                
                .trend-section:last-child {
                    margin-bottom: 0;
                }
                
                .trend-section-title {
                    margin: 0 0 12px 0;
                    font-size: 14px;
                    font-weight: 600;
                    color: #374151;
                }
                
                .trend-chart-container {
                    height: 200px;
                    position: relative;
                }
                
                .trend-chart {
                    max-height: 200px;
                }
                
                .trend-signals-list, .trend-alerts-list {
                    space-y: 8px;
                }
                
                .trend-signal-item {
                    display: flex;
                    justify-content: space-between;
                    align-items: center;
                    padding: 8px 12px;
                    background: #f9fafb;
                    border-radius: 6px;
                    margin-bottom: 8px;
                }
                
                .trend-signal-name {
                    font-weight: 500;
                    color: #111827;
                    font-size: 13px;
                }
                
                .trend-signal-score {
                    font-size: 11px;
                    padding: 2px 6px;
                    border-radius: 10px;
                    font-weight: 500;
                }
                
                .trend-signal-score.high {
                    background: #dcfce7;
                    color: #166534;
                }
                
                .trend-signal-score.medium {
                    background: #fef3c7;
                    color: #92400e;
                }
                
                .trend-signal-score.low {
                    background: #f3f4f6;
                    color: #374151;
                }
                
                .trend-alert-item {
                    padding: 8px 12px;
                    border-left: 3px solid #3b82f6;
                    background: #eff6ff;
                    border-radius: 0 6px 6px 0;
                    margin-bottom: 8px;
                }
                
                .trend-alert-item.high {
                    border-left-color: #ef4444;
                    background: #fef2f2;
                }
                
                .trend-alert-item.medium {
                    border-left-color: #f59e0b;
                    background: #fffbeb;
                }
                
                .trend-alert-title {
                    font-weight: 500;
                    color: #111827;
                    font-size: 12px;
                    margin-bottom: 2px;
                }
                
                .trend-alert-message {
                    font-size: 11px;
                    color: #6b7280;
                    line-height: 1.4;
                }
                
                .trend-widget-loading {
                    position: absolute;
                    top: 0;
                    left: 0;
                    right: 0;
                    bottom: 0;
                    background: rgba(255,255,255,0.9);
                    display: flex;
                    flex-direction: column;
                    align-items: center;
                    justify-content: center;
                    gap: 12px;
                    font-size: 14px;
                    color: #6b7280;
                }
                
                .trend-loading-spinner {
                    width: 24px;
                    height: 24px;
                    border: 2px solid #f3f4f6;
                    border-top: 2px solid #3b82f6;
                    border-radius: 50%;
                    animation: spin 1s linear infinite;
                }
                
                @keyframes spin {
                    0% { transform: rotate(0deg); }
                    100% { transform: rotate(360deg); }
                }
                
                .hidden {
                    display: none !important;
                }
                
                /* Dark theme */
                .trend-widget.dark {
                    background: #1f2937;
                    color: #f9fafb;
                }
                
                .trend-widget.dark .trend-widget-header {
                    background: #111827;
                    border-bottom-color: #374151;
                }
                
                .trend-widget.dark .trend-widget-title {
                    color: #f9fafb;
                }
                
                .trend-widget.dark .trend-signal-item {
                    background: #374151;
                }
                
                .trend-widget.dark .trend-signal-name {
                    color: #f9fafb;
                }
            </style>
        `;
        
        document.head.insertAdjacentHTML('beforeend', styles);
    }
    
    async loadData() {
        this.showLoading(true);
        
        try {
            const token = localStorage.getItem('token');
            const response = await fetch(`${this.options.apiBase}/api/trends?limit_sessions=25&include_predictions=true&include_alerts=true`, {
                headers: { 'Authorization': `Bearer ${token}` }
            });
            
            if (!response.ok) {
                throw new Error('Failed to load trend data');
            }
            
            this.data = await response.json();
            this.updateDisplay();
            
        } catch (error) {
            console.error('Error loading trend data:', error);
            this.showError(error.message);
        } finally {
            this.showLoading(false);
        }
    }
    
    updateDisplay() {
        if (!this.data) return;
        
        if (this.options.showCharts) {
            this.updateChart();
        }
        
        if (this.options.showTopSignals) {
            this.updateTopSignals();
        }
        
        if (this.options.showAlerts) {
            this.updateAlerts();
        }
    }
    
    updateChart() {
        const chartCanvas = document.getElementById(`${this.containerId}-chart`);
        if (!chartCanvas) return;
        
        const ctx = chartCanvas.getContext('2d');
        
        // Destroy existing chart
        if (this.charts.main) {
            this.charts.main.destroy();
        }
        
        const keywordTrends = this.data.keyword_trends || [];
        const topKeywords = keywordTrends.slice(0, this.options.maxItems);
        
        this.charts.main = new Chart(ctx, {
            type: 'bar',
            data: {
                labels: topKeywords.map(k => k.keyword),
                datasets: [{
                    label: 'Frequency',
                    data: topKeywords.map(k => k.frequency),
                    backgroundColor: 'rgba(59, 130, 246, 0.6)',
                    borderColor: 'rgba(59, 130, 246, 1)',
                    borderWidth: 1
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    legend: {
                        display: false
                    }
                },
                scales: {
                    y: {
                        beginAtZero: true,
                        grid: {
                            color: 'rgba(0,0,0,0.1)'
                        }
                    },
                    x: {
                        grid: {
                            display: false
                        }
                    }
                }
            }
        });
    }
    
    updateTopSignals() {
        const container = document.getElementById(`${this.containerId}-signals`);
        if (!container) return;
        
        const signals = this.data.top_signals || [];
        const topSignals = signals.slice(0, this.options.maxItems);
        
        const signalsHtml = topSignals.map(signal => `
            <div class="trend-signal-item">
                <span class="trend-signal-name">${signal.keyword || signal.category}</span>
                <span class="trend-signal-score ${this.getScoreClass(signal.signal_score)}">${signal.signal_score.toFixed(2)}</span>
            </div>
        `).join('');
        
        container.innerHTML = signalsHtml || '<p style="text-align: center; color: #6b7280; font-size: 12px;">No signals detected</p>';
    }
    
    updateAlerts() {
        const container = document.getElementById(`${this.containerId}-alerts`);
        if (!container) return;
        
        const alerts = this.data.alerts || [];
        const recentAlerts = alerts.slice(0, this.options.maxItems);
        
        const alertsHtml = recentAlerts.map(alert => `
            <div class="trend-alert-item ${alert.severity}">
                <div class="trend-alert-title">${alert.title}</div>
                <div class="trend-alert-message">${alert.message}</div>
            </div>
        `).join('');
        
        container.innerHTML = alertsHtml || '<p style="text-align: center; color: #6b7280; font-size: 12px;">No recent alerts</p>';
    }
    
    getScoreClass(score) {
        if (score >= 0.7) return 'high';
        if (score >= 0.4) return 'medium';
        return 'low';
    }
    
    showLoading(show) {
        const loadingEl = this.container.querySelector('.trend-widget-loading');
        if (loadingEl) {
            loadingEl.classList.toggle('hidden', !show);
        }
    }
    
    showError(message) {
        const content = this.container.querySelector('.trend-widget-content');
        if (content) {
            content.innerHTML = `
                <div style="text-align: center; padding: 40px; color: #ef4444;">
                    <i class="fas fa-exclamation-triangle" style="font-size: 24px; margin-bottom: 12px;"></i>
                    <p>Error loading trends: ${message}</p>
                    <button onclick="trendWidgets['${this.containerId}'].refresh()" style="margin-top: 12px; padding: 8px 16px; background: #ef4444; color: white; border: none; border-radius: 4px; cursor: pointer;">
                        Retry
                    </button>
                </div>
            `;
        }
    }
    
    async refresh() {
        await this.loadData();
    }
    
    startAutoRefresh() {
        if (this.refreshTimer) {
            clearInterval(this.refreshTimer);
        }
        
        this.refreshTimer = setInterval(() => {
            this.refresh();
        }, this.options.refreshInterval);
    }
    
    stopAutoRefresh() {
        if (this.refreshTimer) {
            clearInterval(this.refreshTimer);
            this.refreshTimer = null;
        }
    }
    
    destroy() {
        this.stopAutoRefresh();
        
        // Destroy charts
        Object.values(this.charts).forEach(chart => {
            if (chart && chart.destroy) {
                chart.destroy();
            }
        });
        
        // Remove from global registry
        if (window.trendWidgets && window.trendWidgets[this.containerId]) {
            delete window.trendWidgets[this.containerId];
        }
        
        // Clear container
        this.container.innerHTML = '';
    }
}

// Global registry for widget instances
window.trendWidgets = window.trendWidgets || {};

// Factory function for easy widget creation
window.createTrendWidget = function(containerId, options = {}) {
    const widget = new TrendWidget(containerId, options);
    window.trendWidgets[containerId] = widget;
    return widget;
};

// Export for module systems
if (typeof module !== 'undefined' && module.exports) {
    module.exports = TrendWidget;
} 