/**
 * SaaSpype V2 MetricCard Component
 * Data display component for key metrics and KPIs
 */

class MetricCard {
  constructor(options = {}) {
    this.title = options.title || 'Metric';
    this.value = options.value || '0';
    this.previousValue = options.previousValue || null;
    this.unit = options.unit || '';
    this.icon = options.icon || null;
    this.trend = options.trend || null; // 'up', 'down', 'neutral'
    this.trendValue = options.trendValue || null;
    this.trendPeriod = options.trendPeriod || 'vs last period';
    this.size = options.size || 'md';
    this.variant = options.variant || 'default';
    this.loading = options.loading || false;
    this.onClick = options.onClick || null;
    this.element = null;
  }

  getBaseClasses() {
    return [
      'bg-white',
      'rounded-xl',
      'border',
      'border-gray-200',
      'transition-all',
      'duration-200',
      'hover:shadow-md'
    ];
  }

  getSizeClasses() {
    const sizes = {
      sm: ['p-4'],
      md: ['p-6'],
      lg: ['p-8']
    };
    return sizes[this.size] || sizes.md;
  }

  getVariantClasses() {
    const variants = {
      default: [],
      primary: ['border-primary-200', 'bg-primary-50'],
      success: ['border-success-200', 'bg-success-50'],
      warning: ['border-warning-200', 'bg-warning-50'],
      error: ['border-error-200', 'bg-error-50']
    };
    return variants[this.variant] || variants.default;
  }

  getClickableClasses() {
    if (this.onClick) {
      return ['cursor-pointer', 'hover:bg-gray-50'];
    }
    return [];
  }

  getTrendIcon() {
    const icons = {
      up: `
        <svg class="w-4 h-4 text-success-600" fill="currentColor" viewBox="0 0 20 20">
          <path fill-rule="evenodd" d="M3.293 9.707a1 1 0 010-1.414l6-6a1 1 0 011.414 0l6 6a1 1 0 01-1.414 1.414L11 5.414V17a1 1 0 11-2 0V5.414L4.707 9.707a1 1 0 01-1.414 0z" clip-rule="evenodd"></path>
        </svg>
      `,
      down: `
        <svg class="w-4 h-4 text-error-600" fill="currentColor" viewBox="0 0 20 20">
          <path fill-rule="evenodd" d="M16.707 10.293a1 1 0 010 1.414l-6 6a1 1 0 01-1.414 0l-6-6a1 1 0 111.414-1.414L9 14.586V3a1 1 0 012 0v11.586l4.293-4.293a1 1 0 011.414 0z" clip-rule="evenodd"></path>
        </svg>
      `,
      neutral: `
        <svg class="w-4 h-4 text-gray-600" fill="currentColor" viewBox="0 0 20 20">
          <path fill-rule="evenodd" d="M3 10a1 1 0 011-1h12a1 1 0 110 2H4a1 1 0 01-1-1z" clip-rule="evenodd"></path>
        </svg>
      `
    };
    return icons[this.trend] || '';
  }

  getTrendColorClass() {
    const colors = {
      up: 'text-success-600',
      down: 'text-error-600',
      neutral: 'text-gray-600'
    };
    return colors[this.trend] || 'text-gray-600';
  }

  formatValue(value) {
    if (typeof value === 'number') {
      // Format large numbers with appropriate suffixes
      if (value >= 1000000) {
        return (value / 1000000).toFixed(1) + 'M';
      } else if (value >= 1000) {
        return (value / 1000).toFixed(1) + 'K';
      }
      return value.toLocaleString();
    }
    return value;
  }

  calculateTrendPercentage() {
    if (!this.previousValue || !this.value) return null;
    
    const current = parseFloat(this.value);
    const previous = parseFloat(this.previousValue);
    
    if (previous === 0) return null;
    
    const percentage = ((current - previous) / previous) * 100;
    return Math.abs(percentage).toFixed(1);
  }

  renderIcon() {
    if (!this.icon) return '';
    
    const iconSizes = {
      sm: 'w-8 h-8',
      md: 'w-10 h-10',
      lg: 'w-12 h-12'
    };
    
    return `
      <div class="flex-shrink-0">
        <div class="flex items-center justify-center ${iconSizes[this.size]} bg-primary-100 rounded-lg">
          <span class="text-primary-600">
            ${this.icon}
          </span>
        </div>
      </div>
    `;
  }

  renderTrend() {
    if (!this.trend) return '';
    
    const trendPercentage = this.trendValue || this.calculateTrendPercentage();
    if (!trendPercentage) return '';
    
    return `
      <div class="flex items-center mt-2">
        ${this.getTrendIcon()}
        <span class="ml-1 text-sm font-medium ${this.getTrendColorClass()}">
          ${trendPercentage}%
        </span>
        <span class="ml-1 text-sm text-gray-500">
          ${this.trendPeriod}
        </span>
      </div>
    `;
  }

  renderLoadingState() {
    return `
      <div class="animate-pulse">
        <div class="flex items-start justify-between">
          <div class="flex-1">
            <div class="h-4 bg-gray-200 rounded w-3/4 mb-3"></div>
            <div class="h-8 bg-gray-200 rounded w-1/2 mb-2"></div>
            <div class="h-3 bg-gray-200 rounded w-2/3"></div>
          </div>
          <div class="w-10 h-10 bg-gray-200 rounded-lg"></div>
        </div>
      </div>
    `;
  }

  renderContent() {
    if (this.loading) {
      return this.renderLoadingState();
    }

    const titleSizes = {
      sm: 'text-sm',
      md: 'text-base',
      lg: 'text-lg'
    };

    const valueSizes = {
      sm: 'text-2xl',
      md: 'text-3xl',
      lg: 'text-4xl'
    };

    return `
      <div class="flex items-start justify-between">
        <div class="flex-1">
          <h3 class="font-medium text-gray-900 ${titleSizes[this.size]}">
            ${this.title}
          </h3>
          <div class="mt-2">
            <span class="font-bold text-gray-900 ${valueSizes[this.size]}">
              ${this.formatValue(this.value)}
            </span>
            ${this.unit ? `<span class="text-gray-500 ml-1">${this.unit}</span>` : ''}
          </div>
          ${this.renderTrend()}
        </div>
        ${this.renderIcon()}
      </div>
    `;
  }

  render() {
    const allClasses = [
      ...this.getBaseClasses(),
      ...this.getSizeClasses(),
      ...this.getVariantClasses(),
      ...this.getClickableClasses()
    ];

    this.element = document.createElement('div');
    this.element.className = allClasses.join(' ');
    this.element.innerHTML = this.renderContent();

    if (this.onClick) {
      this.element.addEventListener('click', this.onClick);
    }

    return this.element;
  }

  // Update methods for dynamic data changes
  updateValue(newValue, newPreviousValue = null) {
    this.value = newValue;
    if (newPreviousValue !== null) {
      this.previousValue = newPreviousValue;
    }
    
    // Determine trend automatically if previousValue exists
    if (this.previousValue !== null) {
      const current = parseFloat(this.value);
      const previous = parseFloat(this.previousValue);
      
      if (current > previous) {
        this.trend = 'up';
      } else if (current < previous) {
        this.trend = 'down';
      } else {
        this.trend = 'neutral';
      }
    }
    
    if (this.element) {
      this.element.innerHTML = this.renderContent();
    }
  }

  setLoading(loading) {
    this.loading = loading;
    if (this.element) {
      this.element.innerHTML = this.renderContent();
    }
  }

  setTrend(trend, trendValue = null) {
    this.trend = trend;
    this.trendValue = trendValue;
    if (this.element) {
      this.element.innerHTML = this.renderContent();
    }
  }

  // Static factory methods for common metric types
  static revenue(value, previousValue = null, options = {}) {
    return new MetricCard({
      ...options,
      title: 'Revenue',
      value,
      previousValue,
      unit: '$',
      icon: `
        <svg class="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
          <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 8c-1.657 0-3 .895-3 2s1.343 2 3 2 3 .895 3 2-1.343 2-3 2m0-8c1.11 0 2.08.402 2.599 1M12 8V7m0 1v8m0 0v1m0-1c-1.11 0-2.08-.402-2.599-1"></path>
        </svg>
      `,
      variant: 'success'
    }).render();
  }

  static users(value, previousValue = null, options = {}) {
    return new MetricCard({
      ...options,
      title: 'Active Users',
      value,
      previousValue,
      icon: `
        <svg class="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
          <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 4.354a4 4 0 110 5.292M15 21H3v-1a6 6 0 0112 0v1zm0 0h6v-1a6 6 0 00-9-5.197m13.5-9a2.5 2.5 0 11-5 0 2.5 2.5 0 015 0z"></path>
        </svg>
      `,
      variant: 'primary'
    }).render();
  }

  static conversion(value, previousValue = null, options = {}) {
    return new MetricCard({
      ...options,
      title: 'Conversion Rate',
      value,
      previousValue,
      unit: '%',
      icon: `
        <svg class="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
          <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 19v-6a2 2 0 00-2-2H5a2 2 0 00-2 2v6a2 2 0 002 2h2a2 2 0 002-2zm0 0V9a2 2 0 012-2h2a2 2 0 012 2v10m-6 0a2 2 0 002 2h2a2 2 0 002-2m0 0V5a2 2 0 012-2h2a2 2 0 012 2v14a2 2 0 01-2 2h-2a2 2 0 01-2-2z"></path>
        </svg>
      `,
      variant: 'warning'
    }).render();
  }
}

// Export for module usage
if (typeof module !== 'undefined' && module.exports) {
  module.exports = MetricCard;
}

// Global registration for direct HTML usage
if (typeof window !== 'undefined') {
  window.SaaSpypeMetricCard = MetricCard;
} 