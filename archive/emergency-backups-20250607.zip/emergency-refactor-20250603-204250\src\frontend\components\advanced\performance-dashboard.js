/**
 * Performance Dashboard Component
 * Real-time system health and performance monitoring
 */

class PerformanceDashboard {
    constructor(containerId) {
        this.container = document.getElementById(containerId);
        this.refreshInterval = 30000; // 30 seconds
        this.charts = {};
        this.isActive = false;
        
        this.init();
    }
    
    init() {
        this.createDashboardHTML();
        this.initializeCharts();
        this.startMonitoring();
    }
    
    createDashboardHTML() {
        this.container.innerHTML = `
            <div class="performance-dashboard bg-gray-900 text-white p-6 rounded-lg">
                <!-- Header -->
                <div class="flex justify-between items-center mb-6">
                    <h2 class="text-2xl font-bold text-blue-400">
                        <i class="fas fa-tachometer-alt mr-2"></i>
                        System Performance
                    </h2>
                    <div class="flex items-center space-x-4">
                        <div class="ux-score-badge px-4 py-2 rounded-lg bg-green-600">
                            <span class="text-sm">UX Score</span>
                            <div class="text-xl font-bold" id="ux-score">--</div>
                        </div>
                        <button id="refresh-performance" class="btn-secondary">
                            <i class="fas fa-sync-alt"></i> Refresh
                        </button>
                    </div>
                </div>
                
                <!-- System Health Cards -->
                <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 mb-6">
                    <div class="health-card bg-gray-800 p-4 rounded-lg">
                        <div class="flex items-center justify-between">
                            <div>
                                <p class="text-gray-400 text-sm">CPU Usage</p>
                                <p class="text-2xl font-bold" id="cpu-usage">--</p>
                            </div>
                            <div class="text-3xl text-blue-400">
                                <i class="fas fa-microchip"></i>
                            </div>
                        </div>
                        <div class="mt-2">
                            <div class="progress-bar bg-gray-700 rounded-full h-2">
                                <div id="cpu-progress" class="progress-fill bg-blue-500 h-2 rounded-full" style="width: 0%"></div>
                            </div>
                        </div>
                    </div>
                    
                    <div class="health-card bg-gray-800 p-4 rounded-lg">
                        <div class="flex items-center justify-between">
                            <div>
                                <p class="text-gray-400 text-sm">Memory Usage</p>
                                <p class="text-2xl font-bold" id="memory-usage">--</p>
                            </div>
                            <div class="text-3xl text-green-400">
                                <i class="fas fa-memory"></i>
                            </div>
                        </div>
                        <div class="mt-2">
                            <div class="progress-bar bg-gray-700 rounded-full h-2">
                                <div id="memory-progress" class="progress-fill bg-green-500 h-2 rounded-full" style="width: 0%"></div>
                            </div>
                        </div>
                    </div>
                    
                    <div class="health-card bg-gray-800 p-4 rounded-lg">
                        <div class="flex items-center justify-between">
                            <div>
                                <p class="text-gray-400 text-sm">Response Time</p>
                                <p class="text-2xl font-bold" id="response-time">--</p>
                            </div>
                            <div class="text-3xl text-yellow-400">
                                <i class="fas fa-clock"></i>
                            </div>
                        </div>
                        <div class="mt-2">
                            <div class="text-sm text-gray-400" id="response-status">Monitoring...</div>
                        </div>
                    </div>
                    
                    <div class="health-card bg-gray-800 p-4 rounded-lg">
                        <div class="flex items-center justify-between">
                            <div>
                                <p class="text-gray-400 text-sm">Error Rate</p>
                                <p class="text-2xl font-bold" id="error-rate">--</p>
                            </div>
                            <div class="text-3xl text-red-400">
                                <i class="fas fa-exclamation-triangle"></i>
                            </div>
                        </div>
                        <div class="mt-2">
                            <div class="text-sm" id="error-status">No errors</div>
                        </div>
                    </div>
                </div>
                
                <!-- Performance Charts -->
                <div class="grid grid-cols-1 lg:grid-cols-2 gap-6 mb-6">
                    <div class="chart-container bg-gray-800 p-4 rounded-lg">
                        <h3 class="text-lg font-semibold mb-4">Response Time Trend</h3>
                        <canvas id="response-time-chart" width="400" height="200"></canvas>
                    </div>
                    
                    <div class="chart-container bg-gray-800 p-4 rounded-lg">
                        <h3 class="text-lg font-semibold mb-4">System Resources</h3>
                        <canvas id="system-resources-chart" width="400" height="200"></canvas>
                    </div>
                </div>
                
                <!-- Alerts Section -->
                <div class="alerts-section bg-gray-800 p-4 rounded-lg mb-6">
                    <h3 class="text-lg font-semibold mb-4">
                        <i class="fas fa-bell mr-2"></i>
                        Performance Alerts
                    </h3>
                    <div id="alerts-container">
                        <p class="text-gray-400">No alerts</p>
                    </div>
                </div>
                
                <!-- Performance Summary -->
                <div class="performance-summary bg-gray-800 p-4 rounded-lg">
                    <h3 class="text-lg font-semibold mb-4">24-Hour Summary</h3>
                    <div class="grid grid-cols-1 md:grid-cols-3 gap-4">
                        <div class="summary-item">
                            <p class="text-gray-400 text-sm">Total Requests</p>
                            <p class="text-xl font-bold" id="total-requests">--</p>
                        </div>
                        <div class="summary-item">
                            <p class="text-gray-400 text-sm">Average Response Time</p>
                            <p class="text-xl font-bold" id="avg-response-time">--</p>
                        </div>
                        <div class="summary-item">
                            <p class="text-gray-400 text-sm">Uptime</p>
                            <p class="text-xl font-bold" id="system-uptime">--</p>
                        </div>
                    </div>
                </div>
            </div>
        `;
        
        // Add event listeners
        document.getElementById('refresh-performance').addEventListener('click', () => {
            this.refreshData();
        });
    }
    
    initializeCharts() {
        // Response Time Chart
        const responseTimeCtx = document.getElementById('response-time-chart').getContext('2d');
        this.charts.responseTime = new Chart(responseTimeCtx, {
            type: 'line',
            data: {
                labels: [],
                datasets: [{
                    label: 'Response Time (ms)',
                    data: [],
                    borderColor: '#3B82F6',
                    backgroundColor: 'rgba(59, 130, 246, 0.1)',
                    tension: 0.4,
                    fill: true
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    legend: {
                        labels: { color: '#E5E7EB' }
                    }
                },
                scales: {
                    x: {
                        ticks: { color: '#9CA3AF' },
                        grid: { color: '#374151' }
                    },
                    y: {
                        ticks: { color: '#9CA3AF' },
                        grid: { color: '#374151' }
                    }
                }
            }
        });
        
        // System Resources Chart
        const systemResourcesCtx = document.getElementById('system-resources-chart').getContext('2d');
        this.charts.systemResources = new Chart(systemResourcesCtx, {
            type: 'doughnut',
            data: {
                labels: ['CPU Usage', 'Memory Usage', 'Available'],
                datasets: [{
                    data: [0, 0, 100],
                    backgroundColor: ['#3B82F6', '#10B981', '#6B7280'],
                    borderWidth: 0
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    legend: {
                        labels: { color: '#E5E7EB' }
                    }
                }
            }
        });
    }
    
    async startMonitoring() {
        this.isActive = true;
        await this.refreshData();
        
        // Set up periodic refresh
        this.monitoringInterval = setInterval(() => {
            if (this.isActive) {
                this.refreshData();
            }
        }, this.refreshInterval);
    }
    
    stopMonitoring() {
        this.isActive = false;
        if (this.monitoringInterval) {
            clearInterval(this.monitoringInterval);
        }
    }
    
    async refreshData() {
        try {
            // Get system health
            const healthResponse = await fetch('/api/performance/health', {
                headers: {
                    'Authorization': `Bearer ${localStorage.getItem('token')}`
                }
            });
            
            if (!healthResponse.ok) {
                throw new Error('Failed to fetch health data');
            }
            
            const healthData = await healthResponse.json();
            this.updateHealthCards(healthData);
            this.updateCharts(healthData);
            this.updateAlerts(healthData.alerts);
            
            // Get performance summary
            const summaryResponse = await fetch('/api/performance/summary?hours=24', {
                headers: {
                    'Authorization': `Bearer ${localStorage.getItem('token')}`
                }
            });
            
            if (summaryResponse.ok) {
                const summaryData = await summaryResponse.json();
                this.updateSummary(summaryData);
            }
            
        } catch (error) {
            console.error('Error refreshing performance data:', error);
            this.showError('Failed to refresh performance data');
        }
    }
    
    updateHealthCards(data) {
        const health = data.health;
        
        // CPU Usage
        document.getElementById('cpu-usage').textContent = `${health.cpu_percent.toFixed(1)}%`;
        document.getElementById('cpu-progress').style.width = `${health.cpu_percent}%`;
        this.updateProgressColor('cpu-progress', health.cpu_percent);
        
        // Memory Usage
        document.getElementById('memory-usage').textContent = `${health.memory_percent.toFixed(1)}%`;
        document.getElementById('memory-progress').style.width = `${health.memory_percent}%`;
        this.updateProgressColor('memory-progress', health.memory_percent);
        
        // Response Time
        const responseTime = health.response_time_avg * 1000; // Convert to ms
        document.getElementById('response-time').textContent = `${responseTime.toFixed(0)}ms`;
        document.getElementById('response-status').textContent = this.getResponseTimeStatus(responseTime);
        
        // Error Rate
        document.getElementById('error-rate').textContent = `${health.error_rate.toFixed(1)}%`;
        document.getElementById('error-status').textContent = this.getErrorStatus(health.error_rate);
        
        // UX Score
        document.getElementById('ux-score').textContent = data.ux_score;
        this.updateUXScoreBadge(data.ux_score);
    }
    
    updateProgressColor(elementId, percentage) {
        const element = document.getElementById(elementId);
        if (percentage < 50) {
            element.className = 'progress-fill bg-green-500 h-2 rounded-full';
        } else if (percentage < 75) {
            element.className = 'progress-fill bg-yellow-500 h-2 rounded-full';
        } else {
            element.className = 'progress-fill bg-red-500 h-2 rounded-full';
        }
    }
    
    getResponseTimeStatus(responseTime) {
        if (responseTime < 500) return 'Excellent';
        if (responseTime < 1000) return 'Good';
        if (responseTime < 2000) return 'Fair';
        return 'Poor';
    }
    
    getErrorStatus(errorRate) {
        if (errorRate === 0) return 'No errors';
        if (errorRate < 1) return 'Low error rate';
        if (errorRate < 5) return 'Moderate error rate';
        return 'High error rate';
    }
    
    updateUXScoreBadge(score) {
        const badge = document.querySelector('.ux-score-badge');
        if (score >= 90) {
            badge.className = 'ux-score-badge px-4 py-2 rounded-lg bg-green-600';
        } else if (score >= 70) {
            badge.className = 'ux-score-badge px-4 py-2 rounded-lg bg-yellow-600';
        } else {
            badge.className = 'ux-score-badge px-4 py-2 rounded-lg bg-red-600';
        }
    }
    
    updateCharts(data) {
        const health = data.health;
        const now = new Date().toLocaleTimeString();
        
        // Update response time chart
        const responseChart = this.charts.responseTime;
        responseChart.data.labels.push(now);
        responseChart.data.datasets[0].data.push(health.response_time_avg * 1000);
        
        // Keep only last 20 data points
        if (responseChart.data.labels.length > 20) {
            responseChart.data.labels.shift();
            responseChart.data.datasets[0].data.shift();
        }
        
        responseChart.update('none');
        
        // Update system resources chart
        const resourcesChart = this.charts.systemResources;
        const available = 100 - health.cpu_percent - health.memory_percent;
        resourcesChart.data.datasets[0].data = [
            health.cpu_percent,
            health.memory_percent,
            Math.max(0, available)
        ];
        resourcesChart.update('none');
    }
    
    updateAlerts(alerts) {
        const container = document.getElementById('alerts-container');
        
        if (!alerts || alerts.length === 0) {
            container.innerHTML = '<p class="text-gray-400">No alerts</p>';
            return;
        }
        
        const alertsHTML = alerts.map(alert => `
            <div class="alert-item p-3 mb-2 rounded-lg ${this.getAlertClass(alert.level)}">
                <div class="flex items-center justify-between">
                    <div class="flex items-center">
                        <i class="fas ${this.getAlertIcon(alert.level)} mr-2"></i>
                        <span class="font-semibold">${alert.metric}</span>
                    </div>
                    <span class="text-sm">${alert.level}</span>
                </div>
                <p class="text-sm mt-1">${alert.message}</p>
            </div>
        `).join('');
        
        container.innerHTML = alertsHTML;
    }
    
    getAlertClass(level) {
        switch (level) {
            case 'CRITICAL': return 'bg-red-900 border border-red-600';
            case 'WARNING': return 'bg-yellow-900 border border-yellow-600';
            default: return 'bg-blue-900 border border-blue-600';
        }
    }
    
    getAlertIcon(level) {
        switch (level) {
            case 'CRITICAL': return 'fa-exclamation-circle';
            case 'WARNING': return 'fa-exclamation-triangle';
            default: return 'fa-info-circle';
        }
    }
    
    updateSummary(data) {
        document.getElementById('total-requests').textContent = data.total_requests.toLocaleString();
        
        const avgResponseTime = data.metrics?.api_response_time?.avg || 0;
        document.getElementById('avg-response-time').textContent = `${(avgResponseTime * 1000).toFixed(0)}ms`;
        
        const uptimeHours = data.uptime_hours;
        const uptimeText = uptimeHours < 24 
            ? `${uptimeHours.toFixed(1)}h`
            : `${Math.floor(uptimeHours / 24)}d ${(uptimeHours % 24).toFixed(1)}h`;
        document.getElementById('system-uptime').textContent = uptimeText;
    }
    
    showError(message) {
        // Create a temporary error notification
        const errorDiv = document.createElement('div');
        errorDiv.className = 'fixed top-4 right-4 bg-red-600 text-white p-4 rounded-lg shadow-lg z-50';
        errorDiv.innerHTML = `
            <div class="flex items-center">
                <i class="fas fa-exclamation-circle mr-2"></i>
                <span>${message}</span>
            </div>
        `;
        
        document.body.appendChild(errorDiv);
        
        setTimeout(() => {
            errorDiv.remove();
        }, 5000);
    }
}

// Export for use in other modules
window.PerformanceDashboard = PerformanceDashboard; 